﻿

[CmdletBinding()]
param (
    [Parameter(Mandatory = $true)] [String]$configXML = ".\ComplianceHubConfig.xml",
    [Parameter(Mandatory = $false)] [Switch]$RebuildDocs = $false
)

$swScript = [system.diagnostics.stopwatch]::StartNew()
Write-Verbose "Changing Directory to $PSScriptRoot"
#Set-Location $PSScriptRoot
Import-Module ".\CH-ServiceHealth.psm1"
[String]$configXML = ".\ComplianceHubConfig.xml"

function Write-Log {
    param(
        [Parameter(Mandatory = $true)] [string]$info
    )
    # verify the Log is setup and if not create the file
    if ($script:loginitialized -eq $false) {
        $script:FileHeader >> $script:logfile
        $script:loginitialized = $True
    }
    $info = $(Get-Date).ToString() + ": " + $info
    $info >> $script:logfile
}

if ([system.IO.path]::IsPathRooted($configXML) -eq $false) {
    #its not an absolute path. Find the absolute path
    $configXML = Resolve-Path $configXML
}
$config = LoadConfig $configXML



#Declare variables
[string]$APIKey = $config.APIkey
[string]$PageID = $config.PageID


[string]$rptName = $config.DashboardName
[int]$pageRefresh = $config.DashboardRefresh
[int]$IncidentDays = $config.DashboardHistory
#Prod Dashboard cards
[string[]]$dashCards = $config.DashboardCards.split(",")
$dashCards = $dashCards.Replace('"', '')
$dashCards = $dashCards.Trim()

#UAT Dashboard cards
[string[]]$UATdashCards = $config.UATCards.split(",")
$UATdashCards = $UATdashCards.Replace('"', '')
$UATdashCards = $UATdashCards.Trim()

#Cloud Capture Dashboard cards
[string[]]$CCdashCards = $config.CCCards.split(",")
$CCdashCards = $CCdashCards.Replace('"', '')
$CCdashCards = $CCdashCards.Trim()


[string]$pathLogs = $config.LogPath
[string]$pathHTML = $config.HTMLPath
[string]$pathWorking = $config.WorkingPath
[string]$HTMLFile = $config.DashboardHTML

[string]$proxyHost = $config.ProxyHost

[boolean]$rptOutage = $false

[string]$cssfile = "CH-Health.css"

#Check the various file paths, set default, create and make absolute reference if necessary
$pathLogs = CheckDirectory $pathLogs
$pathHTML = CheckDirectory $pathHTML
$pathWorking = CheckDirectory $pathWorking
$pathHTMLDocs = CheckDirectory "$($pathHTML)\Docs"




function BuildHTML {
    Param (
        [Parameter(Mandatory = $true)] $Title,
        [Parameter(Mandatory = $true)] $contentOne,
        [Parameter(Mandatory = $true)] $contentTwo,
        [Parameter(Mandatory = $true)] $contentLast,
        [Parameter(Mandatory = $true)] $HTMLOutput
    )
    [array]$htmlHeader = @()
    [array]$htmlBody = @()
    [array]$htmlFooter = @()

    $htmlHeader = @"
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="CH-Health.css">
<style>
</style>
<title>$($rptTitle)</title>
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
<meta http-equiv="Pragma" content="no-cache" />
<meta http-equiv="Expires" content="0" />
</head>
"@

    $htmlBody = @"

<body>
    <p>Page refreshed: <span id="datetime"></span><span>&nbsp;&nbsp;Data refresh: $(Get-Date -f 'dd-MMM-yyyy HH:mm:ss')</span></p>
	<div class="tab">
    <button class="tablinks" onclick="openTab(event,'Overview')" id="defaultOpen">Overview</button>
    <button class="tablinks" onclick="openTab(event,'History')" id="defaultOpen">History</button>
    </div>
<!-- Tab content -->
<div id="Overview" class="tabcontent">
    $($contentOne)
</div>
<div id="History" class="tabcontent">
    $($contentTwo)
</div>


"@
    $htmlFooter = @"
<script>
var dt = new Date();
document.getElementById("datetime").innerHTML = (("0"+dt.getDate()).slice(-2)) +"-"+ (("0"+(dt.getMonth()+1)).slice(-2)) +"-"+ (dt.getFullYear()) +" "+ (("0"+dt.getHours()).slice(-2)) +":"+ (("0"+dt.getMinutes()).slice(-2)) +":"+ (("0"+dt.getSeconds()).slice(-2));
</script>

<script>
function openTab(evt, tabName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }

    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active","");
    }
    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.className += " active";
}

document.getElementById("defaultOpen").click();
</script>
</body>
</html>
"@

    #Add in code to refresh page
    #Editing after file is generated increases the file size drastically
    $addJava = "<script language=""JavaScript"" type=""text/javascript"">"
    $addJava += "setTimeout(""location.href='$($HTMLOutput)'"",$($pageRefresh*60*1000));"
    $addjava += "</script>"

    $htmlReport = $htmlHeader + $addJava + $htmlBody + $htmlFooter
    $htmlReport | Out-File "$($pathHTML)\$($HTMLOutput)"
}

# StatusPage API URLs
$PageURI = “https://api.statuspage.io/v1/pages/$PageID”
$IncidentsURI = “https://api.statuspage.io/v1/pages/$PageID/incidents”
$ComponentGroupsURI = "https://api.statuspage.io/v1/pages/$PageID/component-groups" 
$ComponentsURI = "https://api.statuspage.io/v1/pages/$PageID/components"

# REST API header
$headers = @{
    Authorization="Bearer $apikey"
    }

# Get the data 
$PageData = Invoke-RestMethod -Method get -uri $PageURI -Headers $headers
start-sleep 1
$IncidentData = Invoke-RestMethod -Method get -uri $incidentsURI -Headers $headers
start-sleep 1
$ComponentGroupData = Invoke-RestMethod -Method get -uri $ComponentGroupsURI -Headers $headers
start-sleep 1
$ComponentData = Invoke-RestMethod -Method get -uri $ComponentsURI -Headers $headers

# Production Group Data
$ProductionGroup = $ComponentGroupData | Where-Object{$_.name -eq "Production"}
$ProductionComponents = $ComponentData | Where-Object{$_.Group_id -eq $productiongroup.id}

# Cloud Capture Group Data
$CCGroup = $ComponentGroupData | Where-Object{$_.name -like "Cloud*"}
$CCComponents = $ComponentData | Where-Object{$_.Group_id -eq $ccgroup.id}

# UAT group data
$UATgroup = $ComponentGroupData | Where-Object{$_.name -eq "UAT"}
$UATComponents = $ComponentData | Where-Object{$_.Group_id -eq $uatgroup.id}

# Incident Data
$incidents = $IncidentData | Where-Object{$_.impact -ne "maintenance"}

# Maintenance Data
$maintenance = $IncidentData | Where-Object{$_.impact -eq "maintenance"}

#Start Building the Pages
#Build Div1
#Build Summary Dashboard
# 6 cards
$HistoryIncidents = $incidents | Where-Object { ($_.status -eq "resolved") } | Sort-Object resolved_at -Descending
$rptSectionOneOne = "<div class='section'><div class='header'>Compliance Hub Production Status</div>`n"
$rptSectionOneOne += "<div class='content'>`n"
$rptSectionOneOne += "<div class='dash-outer'><div class='dash-inner'>`n"
$card = $null
foreach ($card in $dashCards) {
    [array]$item = @()
    [array]$hist = @()
    [int]$advisories = 0
    $cardClass = $null
    $cardText = $null
    $item = $ProductionComponents | Where-Object { $_.Name -like $card }

    $hist = $HistoryIncidents | Where-Object { $_.components.id -eq $item.id } | Sort-Object EndTime -Descending
    
    if ($hist.count -gt 0) {
        $days = "{0:N0}" -f (New-TimeSpan -Start (Get-Date $hist[0].resolved_at) -End $(Get-Date)).TotalDays
    }
    else {
        $days = "&gt;30"
    }
    try { $cardClass = Get-StatusDisplay $($item.status) "Class" }
    catch { Write-Log "No status available for $card - $($item.name)" }
    $cardText = cardbuilder $($item.name) $($Days) $($Hist.count) $cardClass
    $rptSectionOneOne += "$cardText`n"
}
$rptSectionOneOne += "</div></div></div></div>`n" #Close inner and outer divs

$divOne = $rptSectionOneOne


$HistoryIncidents = $incidents | Where-Object { ($_.status -eq "resolved") } | Sort-Object resolved_at -Descending
$rptSectionOneTwo = "<div class='section'><div class='header'>Cloud Capture Status</div>`n"
$rptSectionOneTwo += "<div class='content'>`n"
$rptSectionOneTwo += "<div class='dash-outer'><div class='dash-inner'>`n"
$card = $null
foreach ($card in $CCdashCards) {
    [array]$item = @()
    [array]$hist = @()
    [int]$advisories = 0
    $cardClass = $null
    $cardText = $null
    $item = $CCComponents | Where-Object { $_.Name -like $card }

    $hist = $HistoryIncidents | Where-Object { $_.components.id -eq $item.id } | Sort-Object EndTime -Descending
    
    if ($hist.count -gt 0) {
        $days = "{0:N0}" -f (New-TimeSpan -Start (Get-Date $hist[0].resolved_at) -End $(Get-Date)).TotalDays
    }
    else {
        $days = "&gt;30"
    }
    try { $cardClass = Get-StatusDisplay $($item.status) "Class" }
    catch { Write-Log "No status available for $card - $($item.name)" }
    $cardText = cardbuilder $($item.name) $($Days) $($Hist.count) $cardClass
    $rptSectionOneTwo += "$cardText`n"
}
$rptSectionOneTwo += "</div></div></div></div>`n" #Close inner and outer divs

$divOne += $rptSectionOneTwo

$HistoryIncidents = $incidents | Where-Object { ($_.status -eq "resolved") } | Sort-Object resolved_at -Descending
$rptSectionOneThree = "<div class='section'><div class='header'>UAT Status</div>`n"
$rptSectionOneThree += "<div class='content'>`n"
$rptSectionOneThree += "<div class='dash-outer'><div class='dash-inner'>`n"
$card = $null
foreach ($card in $UATdashCards) {
    [array]$item = @()
    [array]$hist = @()
    [int]$advisories = 0
    $cardClass = $null
    $cardText = $null
    $item = $UATComponents | Where-Object { $_.Name -like $card }

    $hist = $HistoryIncidents | Where-Object { $_.components.id -eq $item.id } | Sort-Object EndTime -Descending
    
    if ($hist.count -gt 0) {
        $days = "{0:N0}" -f (New-TimeSpan -Start (Get-Date $hist[0].resolved_at) -End $(Get-Date)).TotalDays
    }
    else {
        $days = "&gt;30"
    }
    try { $cardClass = Get-StatusDisplay $($item.status) "Class" }
    catch { Write-Log "No status available for $card - $($item.name)" }
    $cardText = cardbuilder $($item.name) $($Days) $($Hist.count) $cardClass
    $rptSectionOneThree += "$cardText`n"
}
$rptSectionOneThree += "</div></div></div></div>`n" #Close inner and outer divs

$divOne += $rptSectionOneThree

#Get current incidents
$rptSectionTwo = "<div class='section'><div class='header'>Active Incidents</div>`n"
$rptSectionTwo += "<div class='content'>`n"

[array]$CurrentMessagesOpen = @()
[array]$rptActiveTable = @()
$CurrentMessagesOpen = $Incidents | Where-Object { ($_.status -notlike 'Resolved' -and $_.resolved_at -eq $null) } | Sort-Object updated_at -Descending
$rptActiveTable = "<br/><div class='dash-outer'><div class='dash-inner'>`n"
if ($CurrentMessagesOpen.count -ge 1) {
    $rptActiveTable += "<div class='tableInc'>`r`n"
    $rptActiveTable += "<div class='tableInc-header'>`n`t<div class='tableInc-header-c'>Incident Title</div>`n`t<div class='tableInc-header-c'>Platform</div>`n`t<div class='tableInc-header-c'>Components</div>`n`t<div class='tableInc-header-c'>Start Time</div>`n`t<div class='tableInc-header-c'>Updated at</div>`n`t<div class='tableInc-header-c'>Last Update</div>`n`t<div class='tableInc-header-c'>Status at $(Get-Date -Format 'dd/MM/yy HH:mm')</div>`n</div>`n"

    foreach ($item in $CurrentMessagesOpen) {
        $rptOutage = $true

        #Build
        $LastUpdated = $(Get-Date $item.updated_at -f 'dd-MMM-yyyy HH:mm')
        
        if ($item.components.count -gt 1)
        {
            if (($item.components.group_id | sort -unique).count -gt 1)
            {
                $PlatformName = "Multiple Platforms"
            }
            else {
            $PlatformID = $item.components.Group_id | sort -Unique
            $PlatformName = $ComponentGroupData | Where-Object{$_.id -eq $PlatformID} | Select-Object -ExpandProperty name   
            }
            
            if (($item.components.name | sort -unique).count -gt 1)
            {
                $ComponentName = "Multiple Components"
            }
            else {
                $ComponentName = $item.components.name | sort -unique
            }
        }
        else {
            $PlatformID = $item.components.Group_id | sort -Unique
            $PlatformName = $ComponentGroupData | Where-Object{$_.id -eq $PlatformID} | Select-Object -ExpandProperty name  
            $ComponentName = $item.components.name | sort -unique
        }
    
        $rptActiveTable += "<div class='tableInc-row'><div class='tableInc-cell-c'>$($item.Name)</div>`r`n<div class='tableInc-cell-c'>$($PlatformName)</div>`r`n<div class='tableInc-cell-c'>$($ComponentName)</div>`r`n<div class='tableInc-cell-c'>$($item.created_at)</div>`r`n<div class='tableInc-cell-c'>$($item.updated_at)</div>`r`n<div class='tableInc-cell-c'>$($item.incident_updates | Sort-Object updated_at -Descending | Select-Object -first 1 | Select-Object -ExpandProperty body)</div>`r`n<div class='tableInc-cell-c'>$($item.Status)</div>`r`n<div class='tableInc-cell-l'>$($ID)</div>`r`n</div>`r`n"
    }
}
else {
    $rptActiveTable += "<div class='tableWrkld'>`r`n"
    $rptActiveTable += "<div class='tableWrkld-title'>No open incidents to display</div>`r`n"
}
$rptActiveTable += "</div><br/>`n"

$rptSectionTwo += $rptActiveTable
$rptSectionTwo += "</div></div></div></div>`r`n" #Close content and section
$divOne += $rptSectionTwo

#Get All workload status
[array]$rptMaintenanceTable = @()
$rptSectionOneThree = "<div class='section'><div class='header'>Active and Upcoming Maintenance Events</div>`n"
$rptSectionOneThree += "<div class='content'>`n"
$MaintenanceMessages = $Maintenance | where-object{$_.status -ne "Completed"} | Sort-Object scheduled_for -Descending | Select-Object -first 5
$rptMaintenanceTable = "<br/><div class='dash-outer'><div class='dash-inner'>`n"
if ($MaintenanceMessages.count -ge 1) {
    $rptMaintenanceTable += "<div class='tableWrkld'>`r`n"
    $rptMaintenanceTable += "<div class='tableWrkld-header'>`n`t<div class='tableWrkld-header-c'>Maintenance Item</div>`n`t<div class='tableWrkld-header-c'>Platform</div>`n`t<div class='tableWrkld-header-c'>Components</div>`n`t<div class='tableWrkld-header-c'>Scheduled Start</div>`n`t<div class='tableWrkld-header-c'>Scheduled End</div>`n`t<div class='tableWrkld-header-c'>Status at $(Get-Date -Format 'dd/MM/yy HH:mm')</div>`n</div>`n"

    foreach ($item in $MaintenanceMessages) {
        if ($item.components.count -gt 1)
        {
            if (($item.components.group_id | sort -unique).count -gt 1)
            {
                $PlatformName = "Multiple Platforms"
            }
            else {
            $PlatformID = $item.components.Group_id | sort -Unique
            $PlatformName = $ComponentGroupData | Where-Object{$_.id -eq $PlatformID} | Select-Object -ExpandProperty name   
            }
            
            if (($item.components.name | sort -unique).count -gt 1)
            {
                $ComponentName = "Multiple Components"
            }
            else {
                $ComponentName = $item.components.name | sort -unique
            }
        }
        else {
            $PlatformID = $item.components.Group_id | sort -Unique
            $PlatformName = $ComponentGroupData | Where-Object{$_.id -eq $PlatformID} | Select-Object -ExpandProperty name  
            $ComponentName = $item.components.name | sort -unique
        }
        $rptMaintenanceTable += "<div class='tableWrkld-row'>`n`t<div class='tableWrkld-cell-c'>$($item.Name)</div>`n`t<div class='tableWrkld-cell-c'>$($PlatformName)</div>`n`t<div class='tableWrkld-cell-c'>$($item.components.name)</div>`n`t<div class='tableWrkld-cell-c'>$($item.Scheduled_for)</div>`n`t<div class='tableWrkld-cell-c'>$($item.Scheduled_until)</div>`n`t<div class='tableWrkld-cell-c'>$($item.Status)</div>`n</div>"
    }
}
else {
    $rptMaintenanceTable += "<div class='tableWrkld'>`r`n"
    $rptMaintenanceTable += "<div class='tableWrkld-title'>No current or upcoming maintenance events</div>`r`n"
}
$rptMaintenanceTable += "</div></div></div>`n"
$rptSectionOneThree += $rptMaintenanceTable
$rptSectionOneThree += "</div></div></div></div>`r`n" #Close content and section
$divOne += $rptSectionOneThree

#Get historical incidents
$rptDivTwoSectionOne = "<div class='section'><div class='header'>Historical Incidents (Last 10)</div>`n"
$rptSectionTwo += "<div class='content'>`n"

[array]$OldIncidents = @()
[array]$rptInActiveTable = @()
$OldIncidents = $Incidents | Where-Object { ($_.status -eq 'Resolved') } | Sort-Object resolved_at -Descending | select -first 10
$rptInActiveTable = "<br/><div class='dash-outer'><div class='dash-inner'>`n"
if ($OldIncidents.count -ge 1) {
    $rptInActiveTable += "<div class='tableInc'>`r`n"
    $rptInActiveTable += "<div class='tableInc-header'>`n`t<div class='tableInc-header-c'>Incident Title</div>`n`t<div class='tableInc-header-c'>Platform</div>`n`t<div class='tableInc-header-c'>Components</div>`n`t<div class='tableInc-header-c'>Start Time</div>`n`t<div class='tableInc-header-c'>Updated at</div>`n`t<div class='tableInc-header-c'>Last Update</div>`n`t<div class='tableInc-header-c'>Status at $(Get-Date -Format 'dd/MM/yy HH:mm')</div>`n</div>`n"

    foreach ($item in $OldIncidents) {
        $rptOutage = $true
        $LastUpdated = $(Get-Date $item.updated_at -f 'dd-MMM-yyyy HH:mm')
        
        #Build
        if ($item.components.count -gt 1)
        {
            if (($item.components.group_id | sort -unique).count -gt 1)
            {
                $PlatformName = "Multiple Platforms"
            }
            else {
            $PlatformID = $item.components.Group_id | sort -Unique
            $PlatformName = $ComponentGroupData | Where-Object{$_.id -eq $PlatformID} | Select-Object -ExpandProperty name   
            }
            
            if (($item.components.name | sort -unique).count -gt 1)
            {
                $ComponentName = "Multiple Components"
            }
            else {
                $ComponentName = $item.components.name | sort -unique
            }
        }
        else {
            $PlatformID = $item.components.Group_id | sort -Unique
            $PlatformName = $ComponentGroupData | Where-Object{$_.id -eq $PlatformID} | Select-Object -ExpandProperty name  
            $ComponentName = $item.components.name | sort -unique
        }
        $rptInActiveTable += "<div class='tableInc-row'><div class='tableInc-cell-c'>$($item.Name)</div>`r`n<div class='tableInc-cell-c'>$($PlatformName)</div>`r`n<div class='tableInc-cell-c'>$($ComponentName)</div>`r`n<div class='tableInc-cell-c'>$($item.created_at)</div>`r`n<div class='tableInc-cell-c'>$($item.updated_at)</div>`r`n<div class='tableInc-cell-c'>$($item.incident_updates | Sort-Object updated_at -Descending | Select-Object -first 1 | Select-Object -ExpandProperty body)</div>`r`n<div class='tableInc-cell-c'>$($item.Status)</div>`r`n</div>`r`n"
    }
}
else {
    $rptInActiveTable += "<div class='tableWrkld'>`r`n"
    $rptInActiveTable += "<div class='tableWrkld-title'>No open incidents to display</div>`r`n"
}
$rptInActiveTable += "</div><br/>`n"

$rptDivTwoSectionOne += $rptInActiveTable
$rptDivTwoSectionOne += "</div><div></div></div></div>`r`n" #Close content and section
$divTwo += $rptDivTwoSectionOne

#Get All workload status
[array]$rptMaintenanceTable = @()
$rptDivTwoSectionTwo = "<div class='section'><div class='header'>Historical Maintenance Events (Last 10)</div>`n"
$rptDivTwoSectionTwo+= "<div class='content'>`n"
$OldMaintenanceMessages = $Maintenance | where-object{$_.status -eq "Completed"} | Sort-Object scheduled_for -Descending | select -first 10
$rptMaintenanceTable = "<br/><div class='dash-outer'><div class='dash-inner'>`n"
if ($OldMaintenanceMessages.count -ge 1) {
    $rptMaintenanceTable += "<div class='tableWrkld'>`r`n"
    $rptMaintenanceTable += "<div class='tableWrkld-header'>`n`t<div class='tableWrkld-header-r'>Maintenance Item</div>`n`t<div class='tableWrkld-header-c'>Platform</div>`n`t<div class='tableWrkld-header-c'>Components</div>`n`t<div class='tableWrkld-header-c'>Scheduled Start</div>`n`t<div class='tableWrkld-header-c'>Scheduled End</div>`n`t<div class='tableWrkld-header-l'>Status at $(Get-Date -Format 'dd/MM/yy HH:mm')</div>`n</div>`n"

    foreach ($item in $OldMaintenanceMessages) {
        if ($item.components.count -gt 1)
        {
            if (($item.components.group_id | sort -unique).count -gt 1)
            {
                $PlatformName = "Multiple Platforms"
            }
            else {
            $PlatformID = $item.components.Group_id | sort -Unique
            $PlatformName = $ComponentGroupData | Where-Object{$_.id -eq $PlatformID} | Select-Object -ExpandProperty name   
            }
            
            if (($item.components.name | sort -unique).count -gt 1)
            {
                $ComponentName = "Multiple Components"
            }
            else {
                $ComponentName = $item.components.name | sort -unique
            }
        }
        else {
            $PlatformID = $item.components.Group_id | sort -Unique
            $PlatformName = $ComponentGroupData | Where-Object{$_.id -eq $PlatformID} | Select-Object -ExpandProperty name  
            $ComponentName = $item.components.name | sort -unique
        }
        $rptMaintenanceTable += "<div class='tableWrkld-row'>`n`t<div class='tableWrkld-cell-r'>$($item.Name)</div>`n`t<div class='tableWrkld-cell-c'>$($PlatformName)</div>`n`t<div class='tableWrkld-cell-c'>$($item.components.name)</div>`n`t<div class='tableWrkld-cell-c'>$($item.Scheduled_for)</div>`n`t<div class='tableWrkld-cell-c'>$($item.Scheduled_until)</div>`n`t<div class='tableWrkld-cell-l'>$($item.Status)</div>`n</div>"
    }
}
else {
    $rptMaintenanceTable += "<div class='tableWrkld'>`r`n"
    $rptMaintenanceTable += "<div class='tableWrkld-title'>No current or upcoming maintenance events</div>`r`n"
}
$rptMaintenanceTable += "</div></div></div>`n"
$rptDivTwoSectionTwo += $rptMaintenanceTable
$rptDivTwoSectionTwo += "</div></div></div></div>`r`n" #Close content and section
$divTwo += $rptDivTwoSectionTwo

#Tab Last - Logs / Additional info
$rptSectionLastOne = "<div class='section'><div class='header'>Information</div>`n"
$rptSectionLastOne += "<div class='content'>`n"
$rptSectionLastOne += $rptO365Info
$rptSectionLastOne += "</div></div>`n"

$divLast = $rptSectionLastOne

$rptSectionLastTwo = "<div class='section'><div class='header'>Script Runtime</div>`n"
$rptSectionLastTwo += "<div class='content'>`n"

[string]$strTime = "$($swScript.Elapsed.Hours)H:$($swScript.Elapsed.Minutes)m:$($swScript.Elapsed.Seconds)s:$($swScript.Elapsed.Milliseconds)ms"
$rptSectionLastTwo += "Elapsed runtime $strTime"
$rptSectionLastTwo += "</div></div></div></div>`n"
$divLast += $rptSectionLastTwo

$rptHTMLName = $HTMLFile.Replace(" ", "")
$rptTitle = $rptTenantName + " " + $rptName
if ($rptOutage) { $rptTitle += " Outage detected" }
$evtMessage = "[$(Get-Date -f 'dd-MMM-yy HH:mm:ss')] Tenant: $($rptProfile) - Generating HTML to '$($pathHTML)\$($rptHTMLName)'`r`n"
$evtLogMessage += $evtMessage
Write-Verbose $evtMessage

BuildHTML $rptTitle $divOne $divtwo $divLast $rptHTMLName
#Check if .css file exists in HTML file destination
if (!(Test-Path "$($pathHTML)\$($cssfile)")) {
    Write-Log "Copying CH-Health.css to directory $($pathHTML)"
    Copy-Item "..\common\CH-Health.css" -Destination "$($pathHTML)"
}

#Remove-Module O365ServiceHealth