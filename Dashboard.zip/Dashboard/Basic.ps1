# API key
$apikey = "1cbb44a4-848f-42b3-bf7e-780fc99dc6ed"

# API URLs
$pageID = "cb52lbjw6mlb"
$PageURI = “https://api.statuspage.io/v1/pages/$PageID”
$IncidentsURI = “https://api.statuspage.io/v1/pages/$PageID/incidents”
$ComponentGroupsURI = "https://api.statuspage.io/v1/pages/$PageID/component-groups" 
$ComponentsURI = "https://api.statuspage.io/v1/pages/$PageID/components"

# REST API header
$headers = @{
    Authorization="Bearer $apikey"
    }

 
$PageData = Invoke-RestMethod -Method get -uri $PageURI -Headers $headers
start-sleep 1
$IncidentData = Invoke-RestMethod -Method get -uri $incidentsURI -Headers $headers
start-sleep 1
$ComponentGroupData = Invoke-RestMethod -Method get -uri $ComponentGroupsURI -Headers $headers
start-sleep 1
$ComponentData = Invoke-RestMethod -Method get -uri $ComponentsURI -Headers $headers

$ProductionGroup = $ComponentGroupData | Where-Object{$_.name -eq "Production"}
$ProductionComponents = $ComponentData | Where-Object{$_.Group_id -eq $productiongroup.id}

$CCGroup = $ComponentGroupData | Where-Object{$_.name -like "Cloud*"}
$CCComponents = $ComponentData | Where-Object{$_.Group_id -eq $ccgroup.id}

$UATgroup = $ComponentGroupData | Where-Object{$_.name -eq "UAT"}
$UATComponents = $ComponentData | Where-Object{$_.Group_id -eq $uatgroup.id}


$incidents = $IncidentData | Where-Object{$_.impact -ne "maintenance"}
$maintenance = $IncidentData | Where-Object{$_.impact -eq "maintenance"}