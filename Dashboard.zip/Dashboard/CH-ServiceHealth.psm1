function CheckDirectory {
    Param (
        [parameter(Mandatory = $false)] [string]$folder
    )
    #If no path has been specified, use the current script location
    if (!$folder) {
        if ($PSIse) {
            $folder = Split-Path $PSIse.CurrentFile.FullPath
        }
        else {
            $folder = $Global:PSScriptRoot
        }
    }

    #Check and trim the path
    $folder = $folder.TrimEnd("\")

    #If path doesnt exist then create
    if (!(Test-Path $($folder))) {
        New-Item -ItemType Directory -Path $folder
    }

    #If path is not absolute, then find it.
    if ([system.IO.path]::IsPathRooted($folder) -eq $false) {
        $folder = Resolve-Path $folder
    }
    return $folder
}

function LoadConfig {
    Param (
        [Parameter(Mandatory = $true)] [string]$configFile
    )
    $appSettings = @{ }
    if (!(Test-Path $configFile)) {
        Write-Output "Cannot find configuration file: $($configFile)"
        Exit
    }
    [xml]$configFile = Get-Content "$($configFile)"

    $appSettings = [PSCustomObject]@{
        APIKey              = $configFile.Settings.Connection.APIkey
        PageID              = $configFile.Settings.Connection.PageID
      
        LogPath             = $configFile.Settings.Output.LogPath
        HTMLPath            = $configFile.Settings.Output.HTMLPath
        WorkingPath         = $configFile.Settings.Output.WorkingPath
        
        DashboardName       = $configFile.Settings.Dashboard.Name
        DashboardHTML       = $configFile.Settings.Dashboard.HTMLFilename
        DashboardCards      = $configFile.Settings.Dashboard.ProdDashCards
        UATCards            = $configFile.Settings.Dashboard.UATDashCards
        CCCards             = $configFile.Settings.Dashboard.CCDashCards
        DashboardRefresh    = $configFile.Settings.Dashboard.Refresh
        DashboardHistory    = $configFile.Settings.Dashboard.History

        
        PACEnabled          = $configFile.Settings.PACFile.Enabled
        PACProxy            = $configFile.Settings.PACFile.Proxy
        PACType1Filename    = $configFile.Settings.PACFile.Type1Filename
        PACType2Filename    = $configFile.Settings.PACFile.Type2Filename

        UseProxy            = $configFile.Settings.Proxy.UseProxy
        ProxyHost           = $configFile.Settings.Proxy.ProxyHost
        ProxyIgnoreSSL      = $configFile.Settings.Proxy.IgnoreSSL
        
    }
    return $appSettings
}

function Get-StatusDisplay {
    Param(
        [Parameter(Mandatory = $true)] [string]$statusName,
        [Parameter(Mandatory = $true)] [string]$type
    )
    #Icon set
    #
    $icon1 = "<img src='images/1.jpg' alt='Error' style='width:20px;height:20px;border:0;'>"
    $icon2 = "<img src='images/2.jpg' alt='Warning' style='width:20px;height:20px;border:0;'>"
    $icon3 = "<img src='images/3.jpg' alt='OK' style='width:20px;height:20px;border:0;'>"
    $icon3 = "<img src='images/4.jpg' alt='Maintenance' style='width:20px;height:20px;border:0;'>"
    #Each service status that is available is mapped to one of the levels - maintenance (4), OK (3), warning (2) and error (1)
    
    switch ($type) {
        "icon" {
            switch ($statusName) {
                "major_outage" { $StatusDisplay = $icon1 }
                "partial_outage" { $StatusDisplay = $icon2 }
                "degraded_performance" { $StatusDisplay = $icon2 }
                "operational" { $StatusDisplay = $icon3 }
                "under_maintenance" { $StatusDisplay = $icon4 }
                #Set default error icon if the status is not listed
                default { $StatusDisplay = $icon1 }
            }
        }
        "class" {
            switch ($statusName) {
                "major_outage" { $StatusDisplay = "err" }
                "partial_outage" { $StatusDisplay = "warn" }
                "degraded_performance" { $StatusDisplay = "warn" }
                "operational" { $StatusDisplay = "ok" }
                "maintenance" { $StatusDisplay = "maintenance" }
                #Set default error colour if the status is not listed
                default { $StatusDisplay = "defcon" }
            }
        }
    }
    return $StatusDisplay
}

function Get-Severity {
    param (
        [parameter(mandatory = $true)] [string]$type,
        [parameter(mandatory = $true)] [string]$severity
    )
    [System.Net.Mail.MailPriority]$returnValue = "Normal"
    switch ($type) {
        "email" {
            #email can have the following priorities : High, Normal, Low
            switch ($severity) {
                "Sev0" { $returnValue = "High" }
                "Sev1" { $returnValue = "High" }
                "Sev2" { $returnValue = "Normal" }
                #Set default error icon if the status is not listed
                default { $returnValue = "Normal" }
            }
        }
    }
    return $returnValue
}


function IgnoreSSLWarnings {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    if (-not ([System.Management.Automation.PSTypeName]'ServerCertificateValidationCallback').Type) {
        $certCallback = @"
    using System;
    using System.Net;
    using System.Net.Security;
    using System.Security.Cryptography.X509Certificates;
    public class ServerCertificateValidationCallback
    {
        public static void Ignore()
        {
            if(ServicePointManager.ServerCertificateValidationCallback ==null)
            {
                ServicePointManager.ServerCertificateValidationCallback += 
                    delegate
                    (
                        Object obj, 
                        X509Certificate certificate, 
                        X509Chain chain, 
                        SslPolicyErrors errors
                    )
                    {
                        return true;
                    };
            }
        }
    }
"@
        Add-Type $certCallback
    }
    [ServerCertificateValidationCallback]::Ignore()	
}



function cardBuilder {
    Param (
        [Parameter(Mandatory = $true)] $strName,
        [Parameter(Mandatory = $true)] $strDays,
        [Parameter(Mandatory = $true)] $strMessages,
        [Parameter(Mandatory = $true)] $strPriority
    ) 
    [array]$rptCard = @()
    $tableClass = "class='card-type-$($strPriority)'"
    $rptCard = @"
    <div $tableClass>
    `t<div class='card-body'>
    `t`t<div class='card-row'>
    `t`t`t<div class='card-name'>$($strName)</div></div></div>
    `t`t`t<div class='card-body'>
    `t`t`t`t<div class='card-row'>
    `t`t`t`t`t<div class='card-number'>$($strDays)</div>
    `t`t`t`t`t<div class='card-text'>Days Since<br/>Last Incident</div>
    `t`t`t`t</div>
    `t`t`t`t<div class='card-row'>
    `t`t`t`t`t<div class='card-number'>$($strMessages)</div>
    `t`t`t`t`t<div class='card-text'>Recent<br/>Incidents</div>
    `t`t`t`t</div>
    `t`t`t</div>`n`t`t</div>
"@
    return $rptCard
}


function featureBuilder {
    Param (
        [Parameter(Mandatory = $true)] $strName,
        [Parameter(Mandatory = $true)] $strFeatures,
        [Parameter(Mandatory = $true)] $strPriority,
        [Parameter(Mandatory = $true)] $intFtCnt
    )
    [array]$rptCard = @()
    [decimal]$decSize = 0
    $decSize = (($intFtCnt * 0.5) + ([math]::ceiling(($strName.length) / 14) * .75) + 0.1) * 2
    [int]$intSize = $decSize
    $tableClass = "class='workload-card-$($strPriority)' style='grid-row: span $($intSize)'"
    $rptCard = @"
    <div $tableClass>
    `t<div class='wkld-name'>$($strName)</div>
    `t$($strFeatures)
    </div>
"@
    return $rptCard
}

function SkuCardBuilder {
    Param (
        [Parameter(Mandatory = $true)] $strName,
        [Parameter(Mandatory = $true)] $strFeatures,
        [Parameter(Mandatory = $true)] $strPriority,
        [Parameter(Mandatory = $true)] $intFtCnt
    ) 
    [array]$rptCard = @()
    [decimal]$decSize = 0
    $decSize = (($intFtCnt * 1) + ([math]::ceiling(($strName.length) / 20) * .75) + 0.1) * 2
    [int]$intSize = $decSize
    $tableClass = "class='sku-card-$($strPriority)' style='grid-row: span $($intSize)'"
    $rptCard = @"
    <div $tableClass>
    `t<div class='sku-name'>$($strName)</div>
    `t$($strFeatures)
    </div>
"@
    return $rptCard
}


function TeamsPost {
    param (
		[Parameter(Mandatory = $true)] $config,
        [Parameter(Mandatory = $true)] [array]$item
      )

# Target URI for the Teams channel (Messaging Operations\O365 Alerts)
#$uri = "https://rbsworkspace.webhook.office.com/webhookb2/723981f8-a910-4bbe-9953-73741fb486c2@7c917db0-71f2-438e-9554-388ffcab8764/IncomingWebhook/dd6583cf498c4b578e5a22d9b9a318fa/03941621-43b8-48b9-96bf-cc1ef7927e28"
$uri = "https://rbsworkspace.webhook.office.com/webhookb2/a9ecbc54-a99b-4566-a5ad-bede76854be1@7c917db0-71f2-438e-9554-388ffcab8764/IncomingWebhook/f2bab3c11cdf4a1497931cc8f06b7e76/03941621-43b8-48b9-96bf-cc1ef7927e28"

# create the JSON file with your message
$body = ConvertTo-Json -Depth 4 @{
    title = "Office 365 [$($config.tenantshortname)]: New $($item.Severity) $($item.Classification): $($item.WorkloadDisplayName) - $($item.Status) [$($item.ID)]"
    text = "Alert [$(Get-Date -f 'dd-MMM-yyy HH:mm:ss')]"
    themecolor = "FF0000" 
    sections = @(
         @{
            title = 'Incident Details'
            facts = @(
                @{
                name = 'ID:'
                value = $item.id
                },
                @{
                name = 'Tenant:'
                value = $config.tenantshortname
                },
                @{
                name = 'Feature:'
                value = $item.WorkloadDisplayName
                },
                @{
                name = 'Status:'
                value = $item.status
                },
                @{
                name = 'Severity:'
                value = $item.severity
                },
                @{
                name = 'Classification:'
                value = $item.classification
                },
                @{
                name = 'Start Time:'
                value = $(Get-Date $item.StartTime -f 'dd-MMM-yyyy HH:mm')
                },
                @{
                name = 'Last Updated:'
                value = $item.LastUpdatedTime
                },
                @{
                name = 'End Time:'
                value = $item.EndTime
                },
                @{
                name = 'Incident Title:'
                value = $item.title
                }
            )
        }
    )
    potentialAction = @(@{
            '@context' = 'http://schema.org'
            '@type' = 'ViewAction'
            name = 'Office 365 Incident Dashboard'
            target = @('https://gbmacmessops03.rbsres01.net/o365InfoProd/Office365Dashboard.html')
        })
}
# send message to Teams channel
Invoke-RestMethod -uri $uri -Method Post -body $body -ContentType 'application/json' -Proxy 'http://appproxy.rbsgrp.net:8080' #-ProxyCredential $creds
}