<#
//***********************************************************************
//
// Copyright (c) 2018 Microsoft Corporation. All rights reserved.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
//
//**********************************************************************​
#>
[void][System.Reflection.Assembly]::Load('System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a')
[void][System.Reflection.Assembly]::Load('System.Windows.Forms, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089')

function ShowEULAPopup($mode) {
    $EULA = New-Object -TypeName System.Windows.Forms.Form
    $richTextBox1 = New-Object System.Windows.Forms.RichTextBox
    $btnAcknowledge = New-Object System.Windows.Forms.Button
    $btnCancel = New-Object System.Windows.Forms.Button

    $EULA.SuspendLayout()
    $EULA.Name = "EULA"
    $EULA.Text = "Microsoft Diagnostic Tools End User License Agreement"

    $richTextBox1.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Bottom -bor [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right
    $richTextBox1.Location = New-Object System.Drawing.Point(12, 12)
    $richTextBox1.Name = "richTextBox1"
    $richTextBox1.ScrollBars = [System.Windows.Forms.RichTextBoxScrollBars]::Vertical
    $richTextBox1.Size = New-Object System.Drawing.Size(776, 397)
    $richTextBox1.TabIndex = 0
    $richTextBox1.ReadOnly = $True
    $richTextBox1.Add_LinkClicked({ Start-Process -FilePath $_.LinkText })
    $richTextBox1.Rtf = @"
{\rtf1\ansi\ansicpg1252\deff0\nouicompat{\fonttbl{\f0\fswiss\fprq2\fcharset0 Segoe UI;}{\f1\fnil\fcharset0 Calibri;}{\f2\fnil\fcharset0 Microsoft Sans Serif;}}
{\colortbl ;\red0\green0\blue255;}
{\*\generator Riched20 10.0.19041}{\*\mmathPr\mdispDef1\mwrapIndent1440 }\viewkind4\uc1 
\pard\widctlpar\f0\fs19\lang1033 MICROSOFT SOFTWARE LICENSE TERMS\par
Microsoft Diagnostic Scripts and Utilities\par
\par
{\pict{\*\picprop}\wmetafile8\picw26\pich26\picwgoal32000\pichgoal15 
0100090000035000000000002700000000000400000003010800050000000b0200000000050000
000c0202000200030000001e000400000007010400040000000701040027000000410b2000cc00
010001000000000001000100000000002800000001000000010000000100010000000000000000
000000000000000000000000000000000000000000ffffff00000000ff040000002701ffff0300
00000000
}These license terms are an agreement between you and Microsoft Corporation (or one of its affiliates). IF YOU COMPLY WITH THESE LICENSE TERMS, YOU HAVE THE RIGHTS BELOW. BY USING THE SOFTWARE, YOU ACCEPT THESE TERMS.\par
{\pict{\*\picprop}\wmetafile8\picw26\pich26\picwgoal32000\pichgoal15 
0100090000035000000000002700000000000400000003010800050000000b0200000000050000
000c0202000200030000001e000400000007010400040000000701040027000000410b2000cc00
010001000000000001000100000000002800000001000000010000000100010000000000000000
000000000000000000000000000000000000000000ffffff00000000ff040000002701ffff0300
00000000
}\par
\pard 
{\pntext\f0 1.\tab}{\*\pn\pnlvlbody\pnf0\pnindent0\pnstart1\pndec{\pntxta.}}
\fi-360\li360 INSTALLATION AND USE RIGHTS. Subject to the terms and restrictions set forth in this license, Microsoft Corporation (\ldblquote Microsoft\rdblquote ) grants you (\ldblquote Customer\rdblquote  or \ldblquote you\rdblquote ) a non-exclusive, non-assignable, fully paid-up license to use and reproduce the script or utility provided under this license (the "Software"), solely for Customer\rquote s internal business purposes, to help Microsoft troubleshoot issues with one or more Microsoft products, provided that such license to the Software does not include any rights to other Microsoft technologies (such as products or services). \ldblquote Use\rdblquote  means to copy, install, execute, access, display, run or otherwise interact with the Software. \par
\pard\widctlpar\par
\pard\widctlpar\li360 You may not sublicense the Software or any use of it through distribution, network access, or otherwise. Microsoft reserves all other rights not expressly granted herein, whether by implication, estoppel or otherwise. You may not reverse engineer, decompile or disassemble the Software, or otherwise attempt to derive the source code for the Software, except and to the extent required by third party licensing terms governing use of certain open source components that may be included in the Software, or remove, minimize, block, or modify any notices of Microsoft or its suppliers in the Software. Neither you nor your representatives may use the Software provided hereunder: (i) in a way prohibited by law, regulation, governmental order or decree; (ii) to violate the rights of others; (iii) to try to gain unauthorized access to or disrupt any service, device, data, account or network; (iv) to distribute spam or malware; (v) in a way that could harm Microsoft\rquote s IT systems or impair anyone else\rquote s use of them; (vi) in any application or situation where use of the Software could lead to the death or serious bodily injury of any person, or to physical or environmental damage; or (vii) to assist, encourage or enable anyone to do any of the above.\par
\par
\pard\widctlpar\fi-360\li360 2.\tab DATA. Customer owns all rights to data that it may elect to share with Microsoft through using the Software. You can learn more about data collection and use in the help documentation and the privacy statement at {{\field{\*\fldinst{HYPERLINK https://aka.ms/privacy }}{\fldrslt{https://aka.ms/privacy\ul0\cf0}}}}\f0\fs19 . Your use of the Software operates as your consent to these practices.\par
\pard\widctlpar\par
\pard\widctlpar\fi-360\li360 3.\tab FEEDBACK. If you give feedback about the Software to Microsoft, you grant to Microsoft, without charge, the right to use, share and commercialize your feedback in any way and for any purpose.\~ You will not provide any feedback that is subject to a license that would require Microsoft to license its software or documentation to third parties due to Microsoft including your feedback in such software or documentation. \par
\pard\widctlpar\par
\pard\widctlpar\fi-360\li360 4.\tab EXPORT RESTRICTIONS. Customer must comply with all domestic and international export laws and regulations that apply to the Software, which include restrictions on destinations, end users, and end use. For further information on export restrictions, visit {{\field{\*\fldinst{HYPERLINK https://aka.ms/exporting }}{\fldrslt{https://aka.ms/exporting\ul0\cf0}}}}\f0\fs19 .\par
\pard\widctlpar\par
\pard\widctlpar\fi-360\li360\qj 5.\tab REPRESENTATIONS AND WARRANTIES. Customer will comply with all applicable laws under this agreement, including in the delivery and use of all data. Customer or a designee agreeing to these terms on behalf of an entity represents and warrants that it (i) has the full power and authority to enter into and perform its obligations under this agreement, (ii) has full power and authority to bind its affiliates or organization to the terms of this agreement, and (iii) will secure the permission of the other party prior to providing any source code in a manner that would subject the other party\rquote s intellectual property to any other license terms or require the other party to distribute source code to any of its technologies.\par
\pard\widctlpar\par
\pard\widctlpar\fi-360\li360\qj 6.\tab DISCLAIMER OF WARRANTY. THE SOFTWARE IS PROVIDED \ldblquote AS IS,\rdblquote  WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL MICROSOFT OR ITS LICENSORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THE SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.\par
\pard\widctlpar\qj\par
\pard\widctlpar\fi-360\li360\qj 7.\tab LIMITATION ON AND EXCLUSION OF DAMAGES. IF YOU HAVE ANY BASIS FOR RECOVERING DAMAGES DESPITE THE PRECEDING DISCLAIMER OF WARRANTY, YOU CAN RECOVER FROM MICROSOFT AND ITS SUPPLIERS ONLY DIRECT DAMAGES UP TO U.S. $5.00. YOU CANNOT RECOVER ANY OTHER DAMAGES, INCLUDING CONSEQUENTIAL, LOST PROFITS, SPECIAL, INDIRECT, OR INCIDENTAL DAMAGES. This limitation applies to (i) anything related to the Software, services, content (including code) on third party Internet sites, or third party applications; and (ii) claims for breach of contract, warranty, guarantee, or condition; strict liability, negligence, or other tort; or any other claim; in each case to the extent permitted by applicable law. It also applies even if Microsoft knew or should have known about the possibility of the damages. The above limitation or exclusion may not apply to you because your state, province, or country may not allow the exclusion or limitation of incidental, consequential, or other damages.\par
\pard\widctlpar\par
\pard\widctlpar\fi-360\li360 8.\tab BINDING ARBITRATION AND CLASS ACTION WAIVER. This section applies if you live in (or, if a business, your principal place of business is in) the United States.  If you and Microsoft have a dispute, you and Microsoft agree to try for 60 days to resolve it informally. If you and Microsoft can\rquote t, you and Microsoft agree to binding individual arbitration before the American Arbitration Association under the Federal Arbitration Act (\ldblquote FAA\rdblquote ), and not to sue in court in front of a judge or jury. Instead, a neutral arbitrator will decide. Class action lawsuits, class-wide arbitrations, private attorney-general actions, and any other proceeding where someone acts in a representative capacity are not allowed; nor is combining individual proceedings without the consent of all parties. The complete Arbitration Agreement contains more terms and is at {{\field{\*\fldinst{HYPERLINK https://aka.ms/arb-agreement-4 }}{\fldrslt{https://aka.ms/arb-agreement-4\ul0\cf0}}}}\f0\fs19 . You and Microsoft agree to these terms. \par
\pard\widctlpar\par
\pard\widctlpar\fi-360\li360 9.\tab LAW AND VENUE. If U.S. federal jurisdiction exists, you and Microsoft consent to exclusive jurisdiction and venue in the federal court in King County, Washington for all disputes heard in court (excluding arbitration). If not, you and Microsoft consent to exclusive jurisdiction and venue in the Superior Court of King County, Washington for all disputes heard in court (excluding arbitration).\par
\pard\widctlpar\par
\pard\widctlpar\fi-360\li360 10.\tab ENTIRE AGREEMENT. This agreement, and any other terms Microsoft may provide for supplements, updates, or third-party applications, is the entire agreement for the software.\par
\pard\sa200\sl276\slmult1\f1\fs22\lang9\par
\pard\f2\fs17\lang2057\par
}
"@
    $richTextBox1.BackColor = [System.Drawing.Color]::White
    $btnAcknowledge.Anchor = [System.Windows.Forms.AnchorStyles]::Bottom -bor [System.Windows.Forms.AnchorStyles]::Right
    $btnAcknowledge.Location = New-Object System.Drawing.Point(544, 415)
    $btnAcknowledge.Name = "btnAcknowledge";
    $btnAcknowledge.Size = New-Object System.Drawing.Size(119, 23)
    $btnAcknowledge.TabIndex = 1
    $btnAcknowledge.Text = "Accept"
    $btnAcknowledge.UseVisualStyleBackColor = $True
    $btnAcknowledge.Add_Click({ $EULA.DialogResult = [System.Windows.Forms.DialogResult]::Yes })

    $btnCancel.Anchor = [System.Windows.Forms.AnchorStyles]::Bottom -bor [System.Windows.Forms.AnchorStyles]::Right
    $btnCancel.Location = New-Object System.Drawing.Point(669, 415)
    $btnCancel.Name = "btnCancel"
    $btnCancel.Size = New-Object System.Drawing.Size(119, 23)
    $btnCancel.TabIndex = 2
    if ($mode -ne 0) {
        $btnCancel.Text = "Close"
    }
    else {
        $btnCancel.Text = "Decline"
    }
    $btnCancel.UseVisualStyleBackColor = $True
    $btnCancel.Add_Click({ $EULA.DialogResult = [System.Windows.Forms.DialogResult]::No })

    $EULA.AutoScaleDimensions = New-Object System.Drawing.SizeF(6.0, 13.0)
    $EULA.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::Font
    $EULA.ClientSize = New-Object System.Drawing.Size(800, 450)
    $EULA.Controls.Add($btnCancel)
    $EULA.Controls.Add($richTextBox1)
    if ($mode -ne 0) {
        $EULA.AcceptButton = $btnCancel
    }
    else {
        $EULA.Controls.Add($btnAcknowledge)
        $EULA.AcceptButton = $btnAcknowledge
        $EULA.CancelButton = $btnCancel
    }
    $EULA.ResumeLayout($false)
    $EULA.Size = New-Object System.Drawing.Size(800, 650)

    Return ($EULA.ShowDialog())
}

function ShowEULAIfNeeded($toolName, $mode) {
    $eulaRegPath = "HKCU:Software\Microsoft\CESDiagnosticTools"
    $eulaAccepted = "No"
    $eulaValue = $toolName + " EULA Accepted"
    if (Test-Path $eulaRegPath) {
        $eulaRegKey = Get-Item $eulaRegPath
        $eulaAccepted = $eulaRegKey.GetValue($eulaValue, "No")
    }
    else {
        $eulaRegKey = New-Item $eulaRegPath
    }
    if ($mode -eq 2) {
        # silent accept
        $eulaAccepted = "Yes"
        $ignore = New-ItemProperty -Path $eulaRegPath -Name $eulaValue -Value $eulaAccepted -PropertyType String -Force
    }
    else {
        if ($eulaAccepted -eq "No") {
            $eulaAccepted = ShowEULAPopup($mode)
            if ($eulaAccepted -eq [System.Windows.Forms.DialogResult]::Yes) {
                $eulaAccepted = "Yes"
                $ignore = New-ItemProperty -Path $eulaRegPath -Name $eulaValue -Value $eulaAccepted -PropertyType String -Force
            }
        }
    }
    return $eulaAccepted
}

# Shared functions for Office 365 Info powershell
function saveCredentials {
    param (
        [Parameter(Mandatory = $true)] [string]$Password,
        [Parameter(Mandatory = $true)] [boolean]$CreateKey,
        [Parameter(Mandatory = $true)] [string]$KeyPath,
        [Parameter(Mandatory = $true)] [string]$CredsPath
    ) 
    #keypath is path and file name ie c:\credentials\user-tenant.key
    #credspath is path and file to password ie c:\credentials\user-tenant.pwd
    $AESKey = $null
    #Build a key if needed
    if ($CreateKey) {
        $AESKey = New-Object byte[] 32
        [Security.Cryptography.RNGCryptoServiceProvider]::Create().GetBytes($AESKey)
        #Store the AESKey into a file. Protect this file with permissions.
        Set-Content $KeyPath $AESKey
    }
    #Import key file if it hasnt been created
    if ($null -eq $AESKey) { $AESKey = Get-Content $KeyPath }
    $SecurePwd = $Password | ConvertTo-SecureString -AsPlainText -Force
    $SecurePwd | ConvertFrom-SecureString -Key $AESKey | Out-File $CredsPath
}

function getCreds {
    param (
        [Parameter(Mandatory = $true)] [string]$Username,
        [Parameter(Mandatory = $true)] [string]$CredsPath,
        [Parameter(Mandatory = $true)] [string]$KeyPath)

    $AESKey = Get-Content $KeyPath
    $Password = Get-Content $CredsPath | ConvertTo-SecureString -Key $AESKey
    $Credentials = New-Object -TypeName "System.Management.Automation.PSCredential" -ArgumentList $Username, $Password
    return $Credentials
}

function CheckDirectory {
    Param (
        [parameter(Mandatory = $false)] [string]$folder
    )
    #If no path has been specified, use the current script location
    if (!$folder) {
        if ($PSIse) {
            $folder = Split-Path $PSIse.CurrentFile.FullPath
        }
        else {
            $folder = $Global:PSScriptRoot
        }
    }

    #Check and trim the path
    $folder = $folder.TrimEnd("\")

    #If path doesnt exist then create
    if (!(Test-Path $($folder))) {
        $result = New-Item -ItemType Directory -Path $folder
    }

    #If path is not absolute, then find it.
    if ([system.IO.path]::IsPathRooted($folder) -eq $false) {
        $folder = Resolve-Path $folder
    }
    return $folder
}

function Write-ELog {
    Param (
        [parameter(Mandatory = $false)] [boolean]$useEventLog,
        [parameter(Mandatory = $false)] [string]$LogName,
        [parameter(Mandatory = $false)] [string]$Source,
        [parameter(Mandatory = $false)] [string]$Message,
        [parameter(Mandatory = $false)] [int]$EventId,
        [parameter(Mandatory = $false)] [string]$EntryType
    )
    if ($useEventLog) {
        Write-EventLog -LogName $LogName -Source $Source -Message $Message -EventId $EventId -EntryType $EntryType
    }
}

function ConnectAzureAD() {
    $modAzureAD = (Get-Module -Name "AzureAD" -ListAvailable | Sort-Object version -Descending)[-1]
    if ($null -eq $modAzureAD) {
        $evtMessage = "ERROR - Azure AD module not found. Install using command 'Install-Module AzureAD' from an elevated prompt`r`n"
        Write-Log $evtMessage
        Write-Verbose $evtMessage
        #If tracking exit reasons - use 5 for module not found
        Exit 5
    }
    #Load the latest authentication libraries
    $adal = Join-Path $modAzureAD.ModuleBase "Microsoft.IdentityModel.Clients.ActiveDirectory.dll"
    $adalforms = Join-Path $modAzureAD.ModuleBase "Microsoft.IdentityModel.Clients.ActiveDirectory.Platform.dll"
    [System.Reflection.Assembly]::LoadFrom($adal) | Out-Null
    [System.Reflection.Assembly]::LoadFrom($adalforms) | Out-Null

    #Force TLS 1.2 and ignore SSL Warnings
    IgnoreSSLWarnings
}

function LoadConfig {
    Param (
        [Parameter(Mandatory = $true)] [string]$configFile
    )
    $appSettings = @{ }
    if (!(Test-Path $configFile)) {
        Write-Output "Cannot find configuration file: $($configFile)"
        Exit
    }
    [xml]$configFile = Get-Content "$($configFile)"

    $appSettings = [PSCustomObject]@{
        TenantName          = $configFile.Settings.Tenant.Name
        TenantShortName     = $configFile.Settings.Tenant.ShortName
        TenantMSName        = $configFile.Settings.Tenant.MSName
        TenantDescription   = $configFile.Settings.Tenant.Description
    
        TenantID            = $configFile.Settings.Azure.TenantID
        AppID               = $configFile.Settings.Azure.AppID
        AppSecret           = $configFile.Settings.Azure.AppSecret
    
        LogPath             = $configFile.Settings.Output.LogPath
        HTMLPath            = $configFile.Settings.Output.HTMLPath
        WorkingPath         = $configFile.Settings.Output.WorkingPath
        UseEventLog         = $configFile.Settings.Output.UseEventLog
        EventLog            = $configFile.Settings.Output.EventLog
        HostURL             = $configFile.Settings.Output.HostURL

        EmailEnabled        = $configFile.Settings.Email.Enabled
        EmailHost           = $configFile.Settings.Email.SMTPServer
        EmailPort           = $configFile.Settings.Email.Port
        EmailUseSSL         = $configFile.Settings.Email.UseSSL
        EmailFrom           = $configFile.Settings.Email.From
        EmailUser           = $configFile.Settings.Email.Username
        EmailPassword       = $configFile.Settings.Email.PasswordFile
        EmailKey            = $configFile.Settings.Email.AESKeyFile

        MonitorAlertsTo     = [string[]]$configFile.Settings.Monitor.alertsTo
        MonitorEvtSource    = $configFile.Settings.Monitor.EventSource
        MonitorIgnoreSvc    = [string[]]$configFile.Settings.Monitor.IgnoreSvc
        MonitorIgnoreInc    = [string[]]$configFile.Settings.Monitor.IgnoreInc
  
        WallReportName      = $configFile.Settings.WallDashboard.Name
        WallHTML            = $configFile.Settings.WallDashboard.HTMLFilename
        WallDashCards       = $configFile.Settings.WallDashboard.DashCards
        WallPageRefresh     = $configFile.Settings.WallDashboard.Refresh
        WallEventSource     = $configFile.Settings.WallDashboard.EventSource

        KISSReportName      = $configFile.Settings.KISS.Name
        KISSHTML            = $configFile.Settings.KISS.HTMLFilename
        KISSLogo            = $configFile.Settings.KISS.Logo
        KISSDashCards       = $configFile.Settings.KISS.DashCards
        KISSPageRefresh     = $configFile.Settings.KISS.Refresh
        KISSEventSource     = $configFile.Settings.KISS.EventSource

        DashboardName       = $configFile.Settings.Dashboard.Name
        DashboardHTML       = $configFile.Settings.Dashboard.HTMLFilename
        DashboardCards      = $configFile.Settings.Dashboard.DashCards
        DashboardRefresh    = $configFile.Settings.Dashboard.Refresh
        DashboardAlertsTo   = $configFile.Settings.Dashboard.AlertsTo
        DashboardEvtSource  = $configFile.Settings.Dashboard.EventSource
        DashboardLogo       = $configFile.Settings.Dashboard.Logo
        DashboardAddLink    = $configFile.Settings.Dashboard.AddLink
        DashboardKISS       = $configFile.Settings.Dashboard.KISS
        DashboardShowInc    = $configFile.Settings.Dashboard.ShowIncidents
        DashboardShowMsgs   = $configFile.Settings.Dashboard.ShowMessages
        DashboardShowRdMap  = $configFile.Settings.Dashboard.ShowRoadmap
        DashboardShowLog    = $configFile.Settings.Dashboard.ShowLog
        DashboardHistory    = $configFile.Settings.Dashboard.History
        DashboardRecMsgs    = $configFile.Settings.Dashboard.RecentMsgs

        UsageReportsPath    = $configFile.Settings.UsageReports.Path
        UsageEventSource    = $configFile.Settings.UsageReports.EventSource

        ToolboxName         = $configFile.Settings.Toolbox.Name
        ToolboxHTML         = $configFile.Settings.Toolbox.HTMLFilename
        ToolboxNotes        = ($configFile.Settings.Toolbox.Notes).InnerXML
        ToolboxRefresh      = $configFile.Settings.Toolbox.Refresh

        DiagnosticsEnabled  = $configFile.Settings.Diagnostics.Enabled
        DiagnosticsURLs     = $configFile.Settings.Diagnostics.URLs
        DiagnosticsVerbose  = $configFile.Settings.Diagnostics.Verbose

        MiscDiagsEnabled    = $configFile.Settings.MiscDiagnostics.Enabled
        MiscDiagsWeb        = $configFile.Settings.MiscDiagnostics.Web
        MiscDiagsPorts      = $configFile.Settings.MiscDiagnostics.Ports

        RSS1Enabled         = $configFile.Settings.RSSFeeds.F1.Enabled
        RSS1Name            = $configFile.Settings.RSSFeeds.F1.Name
        RSS1Feed            = $configFile.Settings.RSSFeeds.F1.Feed
        RSS1URL             = $configFile.Settings.RSSFeeds.F1.URL
        RSS1Items           = $configFile.Settings.RSSFeeds.F1.Items

        RSS2Enabled         = $configFile.Settings.RSSFeeds.F2.Enabled
        RSS2Name            = $configFile.Settings.RSSFeeds.F2.Name
        RSS2Feed            = $configFile.Settings.RSSFeeds.F2.Feed
        RSS2URL             = $configFile.Settings.RSSFeeds.F2.URL
        RSS2Items           = $configFile.Settings.RSSFeeds.F2.Items

        IPURLsPath          = $configFile.Settings.IPURLs.Path
        IPURLsAlertsTo      = $configFile.Settings.IPURLs.AlertsTo
        IPURLsNotesFilename = $configFile.Settings.IPURLs.NotesFilename
        CustomNotesFilename = $configFile.Settings.IPURLs.CustomNotesFilename
        IPURLsHistory       = $configFile.Settings.IPURLs.History
        IPURLsTeamsEnabled  = $configFile.Settings.IPURLs.TeamsEnabled
        IPURLsTeamsWebhook  = $configFile.Settings.IPURLs.TeamsWebhook
    
        CnameEnabled        = $configFile.Settings.CNAME.Enabled
        CnameNotes          = ($configFile.Settings.CNAME.Notes).InnerXML
        CnameFilename       = $configFile.Settings.CNAME.Filename
        CnameAlertsTo       = $configFile.Settings.CNAME.AlertsTo
        CnameURLs           = $configFile.Settings.CNAME.URLs
        CnameResolvers      = [string[]]$configFile.Settings.CNAME.Resolvers
        CnameResolverDesc   = [string[]]$configFile.Settings.CNAME.ResolverDesc

        IPMonEnabled        = $configFile.Settings.IPMonitor.Enabled
        IPMonNotes          = ($configFile.Settings.IPMonitor.Notes).InnerXML
        IPMonFilename       = $configFile.Settings.IPMonitor.Filename
        IPMonAlertsTo       = $configFile.Settings.IPMonitor.AlertsTo
        IPMonURLs           = $configFile.Settings.IPMonitor.URLs
        IPMonResolvers      = [string[]]$configFile.Settings.IPMonitor.Resolvers
        IPMonResolverDesc   = [string[]]$configFile.Settings.IPMonitor.ResolverDesc

        PACEnabled          = $configFile.Settings.PACFile.Enabled
        PACProxy            = $configFile.Settings.PACFile.Proxy
        PACType1Filename    = $configFile.Settings.PACFile.Type1Filename
        PACType2Filename    = $configFile.Settings.PACFile.Type2Filename

        ProxyEnabled        = $configFile.Settings.Proxy.ProxyEnabled
        ProxyHost           = $configFile.Settings.Proxy.ProxyHost
        ProxyIgnoreSSL      = $configFile.Settings.Proxy.IgnoreSSL

        Blogs               = ($configFile.Settings.Blogs).InnerXML

    }
    return $appSettings
}

function Get-StatusDisplay {
    Param(
        [Parameter(Mandatory = $true)] [string]$statusName,
        [Parameter(Mandatory = $true)] [string]$type
    )
    #Icon set
    #
    $icon1 = "<img src='images/1.jpg' alt='Error' style='width:20px;height:20px;border:0;'>"
    $icon2 = "<img src='images/2.jpg' alt='Warning' style='width:20px;height:20px;border:0;'>"
    $icon3 = "<img src='images/3.jpg' alt='OK' style='width:20px;height:20px;border:0;'>"
    #Each service status that is available is mapped to one of the levels - OK (3), warning (2) and error (1)
    #Service status from: https://docs.microsoft.com/en-us/dotnet/api/microsoft.exchange.servicestatus.tenantcommunications.data.servicestatus?view=o365-service-communications
    switch ($type) {
        "icon" {
            switch ($statusName) {
                "ServiceInterruption" { $StatusDisplay = $icon1 }
                "ServiceDegradation" { $StatusDisplay = $icon1 }
                "RestoringService" { $StatusDisplay = $icon2 }
                "ExtendedRecovery" { $StatusDisplay = $icon1 }
                "Investigating" { $StatusDisplay = $icon2 }
                "ServiceRestored" { $StatusDisplay = $icon3 }
                "FalsePositive" { $StatusDisplay = $icon3 }
                "PIRPublished" { $StatusDisplay = $icon3 }
                "InformationUnavailable " { $StatusDisplay = $icon1 }
                "ServiceOperational" { $StatusDisplay = $icon3 }
                "PostIncidentReviewPublished" { $StatusDisplay = $icon3 }
                #Set default error icon if the status is not listed
                default { $StatusDisplay = $icon1 }
            }
        }
        "class" {
            switch ($statusName) {
                "ServiceInterruption" { $StatusDisplay = "err" }
                "ServiceDegradation" { $StatusDisplay = "err" }
                "RestoringService" { $StatusDisplay = "warn" }
                "ExtendedRecovery" { $StatusDisplay = "err" }
                "Investigating" { $StatusDisplay = "warn" }
                "ServiceRestored" { $StatusDisplay = "ok" }
                "FalsePositive" { $StatusDisplay = "ok" }
                "PIRPublished" { $StatusDisplay = "ok" }
                "InformationUnavailable" { $StatusDisplay = "err" }
                "ServiceOperational" { $StatusDisplay = "ok" }
                "PostIncidentReviewPublished" { $StatusDisplay = "ok" }
                #Set default error colour if the status is not listed
                default { $StatusDisplay = "defcon" }
            }
        }
        "description" {
            switch ($statusName) {
                "ServiceOperational" { $StatusDisplay = "Service is healthy." }
                "Investigating" { $StatusDisplay = "Service incident investigation is in progress." }
                "RestoringService" { $StatusDisplay = "Incident resolution is in progress." }
                "verifyingService" { $StatusDisplay = "Service verification is in progress." }
                "ServiceRestored" { $StatusDisplay = "The service incident is resolved and service is operational for all customers." }
                "PostIncidentReviewPublished" { $StatusDisplay = "The post-incident report has been published." }
                "ServiceDegradation" { $StatusDisplay = "Service operation is temporarily degraded for some customers." }
                "ServiceInterruption" { $StatusDisplay = "Service is temporarily not available for some customers." }
                "ExtendedRecovery" { $StatusDisplay = "Incident resolution is in progress and will take a while to be completed." }
                "FalsePositive" { $StatusDisplay = "Service investigation determined that a service incident did not occur." }
                "InvestigationSuspended" { $StatusDisplay = "Investigation has been suspended." }
                "Resolved" { $StatusDisplay = "Service incident has been resolved." }
                "MitigatedExternal" { $StatusDisplay = "Service Incident has been mitigated externally to Microsoft." }
                "Mitigated" { $StatusDisplay = "Service incident has been mitigated." }
                "ResolvedExternal" { $StatusDisplay = "Service incident has been resolved externally to Microsoft." }
                "Confirmed" { $StatusDisplay = "Service incident has been confirmed." }
                "Reported" { $StatusDisplay = "Service incident has been reported." }
                "unknownFutureValue" { $StatusDisplay = "unknownFutureValue." }
                #Set default error icon if the status is not listed
                default { $StatusDisplay = $statusName }
            }
        }
        "shortDescription" {
            switch ($statusName) {
                "ServiceOperational" { $StatusDisplay = "Service is healthy." }
                "Investigating" { $StatusDisplay = "Investigation is in progress." }
                "RestoringService" { $StatusDisplay = "Resolution is in progress." }
                "verifyingService" { $StatusDisplay = "Verification is in progress." }
                "ServiceRestored" { $StatusDisplay = "Resolved and service is operational." }
                "PostIncidentReviewPublished" { $StatusDisplay = "The post-incident report has been published." }
                "ServiceDegradation" { $StatusDisplay = "Temporarily degraded for some customers." }
                "ServiceInterruption" { $StatusDisplay = "Temporarily unavailable for some customers." }
                "ExtendedRecovery" { $StatusDisplay = "Resolution is in progress." }
                "FalsePositive" { $StatusDisplay = "A service incident did not occur." }
                "InvestigationSuspended" { $StatusDisplay = "Investigation has been suspended." }
                "Resolved" { $StatusDisplay = "Service incident has been resolved." }
                "MitigatedExternal" { $StatusDisplay = "Mitigated externally to Microsoft." }
                "Mitigated" { $StatusDisplay = "Service incident has been mitigated." }
                "ResolvedExternal" { $StatusDisplay = "Resolved externally to Microsoft." }
                "Confirmed" { $StatusDisplay = "Service incident has been confirmed." }
                "Reported" { $StatusDisplay = "Service incident has been reported." }

                "unknownFutureValue" { $StatusDisplay = "unknownFutureValue." }
                #Set default error icon if the status is not listed
                default { $StatusDisplay = $statusName }
            }
        }
        "kissDescription" {
            switch ($statusName) {
                "ServiceOperational" { $StatusDisplay = "Service is healthy." }
                "Investigating" { $StatusDisplay = "Checking." }
                "RestoringService" { $StatusDisplay = "Resolution is in progress." }
                "verifyingService" { $StatusDisplay = "Resolution is in progress." }
                "ServiceRestored" { $StatusDisplay = "Service is healthy." }
                "PostIncidentReviewPublished" { $StatusDisplay = "Report published." }
                "ServiceDegradation" { $StatusDisplay = "Impact to some users." }
                "ServiceInterruption" { $StatusDisplay = "Impact to some users." }
                "ExtendedRecovery" { $StatusDisplay = "Resolution is in progress." }
                "FalsePositive" { $StatusDisplay = "No fault found." }
                "InvestigationSuspended" { $StatusDisplay = "Investigation has been suspended." }
                "Resolved" { $StatusDisplay = "Resolved." }
                "MitigatedExternal" { $StatusDisplay = "Mitigated." }
                "Mitigated" { $StatusDisplay = "Mitigated." }
                "ResolvedExternal" { $StatusDisplay = "Resolved." }
                "Confirmed" { $StatusDisplay = "An incident has been confirmed." }
                "Reported" { $StatusDisplay = "An incident has been reported." }

                "unknownFutureValue" { $StatusDisplay = "unknownFutureValue." }
                #Set default error icon if the status is not listed
                default { $StatusDisplay = $statusName }
            }
        }
        "SkuCapabilityStatus" {
            switch ($statusName) {
                "Enabled" { $StatusDisplay = "ok" }
                "Suspended" { $StatusDisplay = "warn" }
                "LockedOut" { $StatusDisplay = "err" }
                default { $StatusDisplay = "warn" }
            }
        }
        "ServicePlanStatus" {
            switch ($statusName) {
                "Success" { $StatusDisplay = "ok" }
                "PendingActivation" { $StatusDisplay = "warn" }
                "PendingInput" { $StatusDisplay = "warn" }
                "PendingProvisioning" { $StatusDisplay = "warn" }
                "Disabled" { $StatusDisplay = "err" }
                default { $StatusDisplay = "warn" }
            }
        }
        "Category" {
            switch ($statusName) {
                "planforChange" { $StatusDisplay = "Plan For Change" }
                "stayInformed" { $StatusDisplay = "Stay Informed" }
                "preventOrFixIssue" { $StatusDisplay = "Prevent or Fix Issue" }
                default { $StatusDisplay = $statusName }
            }
        }

    }
    return $StatusDisplay
}


function featureBuilder {
    Param (
        [Parameter(Mandatory = $true)] $strName, 
        [Parameter(Mandatory = $true)] $strFeatures,
        [Parameter(Mandatory = $true)] $strPriority,
        [Parameter(Mandatory = $true)] $intFtCnt
    )
    [array]$rptCard = @()
    [decimal]$decSize = 0
    $decSize = (($intFtCnt * 0.5) + ([math]::ceiling(($strName.length) / 14) * .75) + 0.1) * 2
    [int]$intSize = $decSize
    $tableClass = "class='workload-card-$($strPriority)' style='grid-row: span $($intSize)'"
    $rptCard = @"
    <div $tableClass>
    `t<div class='wkld-name'>$($strName)</div>
    `t$($strFeatures)
    </div>
"@
    return $rptCard
}

function Get-htmlMessage ($msgText) {
    $htmlMessage = $null
    $htmlMessage = $msgText -replace ("`n", '<br>') -replace ([char]8217, "'") -replace ([char]8220, '"') -replace ([char]8221, '"') -replace ('\[', '<b><i>') -replace ('\]', '</i></b>')
    $htmlMessage = $htmlMessage -replace "Title:", "<b>Title</b>:"
    $htmlMessage = $htmlMessage -replace "User Impact:", "<b>User Impact</b>:"
    $htmlMessage = $htmlMessage -replace "More Info:", "<b>More Info</b>:"
    $htmlMessage = $htmlMessage -replace "Next Update By:", "<b>Next Update By</b>:"
    $htmlMessage = $htmlMessage -replace "Current Status:", "<b>Current Status</b>:"
    $htmlMessage = $htmlMessage -replace "Incident Start time:", "<b>Incident Start Time</b>:"
    $htmlMessage = $htmlMessage -replace "Start time:", "<b>Start Time</b>:"
    $htmlMessage = $htmlMessage -replace "Incident End time:", "<b>Incident End Time</b>:"
    $htmlMessage = $htmlMessage -replace "End time:", "<b>End Time</b>:"
    $htmlMessage = $htmlMessage -replace "Scope:", "<b>Scope</b>:"
    $htmlMessage = $htmlMessage -replace "Scope of impact:", "<b>Scope of Impact</b>:"
    $htmlMessage = $htmlMessage -replace "Estimated time to resolve:", "<b>Estimated time to resolve</b>:"
    $htmlMessage = $htmlMessage -replace "Final Status:", "<b>Final Status</b>:"
    $htmlMessage = $htmlMessage -replace "Preliminary Root Cause: ", "<b>Preliminary Root Cause</b>:"
    $htmlMessage = $htmlMessage -replace "Root Cause:", "<b>Root Cause</b>:"
    $htmlMessage = $htmlMessage -replace "Next Steps:", "<b>Next Steps</b>:"
    $htmlMessage = $htmlMessage -replace "Next Update:", "<b>Next Update</b>:"
    $htmlMessage = $htmlMessage -replace "This is the final update for the event.", "<b><u>This is the final update for the event.</u></b>"
    $htmlMessage = $htmlMessage -replace "This is the final update on this incident.", "<b><u>This is the final update on this incident.</u></b>"
    $htmlMessage = $htmlMessage -replace "`n", "<br/>"

    return $htmlMessage
}

function BuildIPURLChanges {
    Param(
        [Parameter(Mandatory = $true)] [array]$changesList,
        [Parameter(Mandatory = $true)] [array]$changesIDX,
        [Parameter(Mandatory = $true)] [array]$changesEPSIDX,
        [Parameter(Mandatory = $true)] [array]$changesFlat,
        [Parameter(Mandatory = $true)] [int]$expandCount,
        [Parameter(Mandatory = $true)] [array]$watchCats,
        [Parameter(Mandatory = $false)] [switch]$email
    )
    if ($email) { $html = $true } else { $html = $false }
    #Use DIVs to build HTML page
    $ipHistoryHTML = ""
    $ipHistoryCnt = 0
    foreach ($change in $changesList) {
        $ipHistoryCnt++
        $changesLast = @($changesIDX | Where-Object { $_.version -In $change.version })
        $inputID = "collapsible$($ipHistoryCnt)"
        if ($html) {
            $ipHistoryHTML += "<table>`r`n"
            $ipHistoryHTML += "<caption>Version: $(Get-Date $change.VersionDate -Format 'dd-MMM-yyyy') : $($changeslast.count) item(s)</caption>`r`n"
            $ipHistoryHTML += "<thead><tr>`r`n"
            $ipHistoryHTML += "<th>Service Area</th>`r`n"
            $ipHistoryHTML += "<th>Disposition</th>`r`n<th>Impact</th>`r`n"
            $ipHistoryHTML += "<th style='max-width:250px'>Add</th>`r`n<th style='max-width:250px'>Remove</th>`r`n"
            $ipHistoryHTML += "<th style='max-width:150px'>Current</th>`r`n`<th style='max-width:150px'>Previous</th>`r`n"
            $ipHistoryHTML += "</tr></thead>`r`n"
            $ipHistoryHTML += "<tbody>`r`n"		
        }
        else {
            $ipHistoryHTML += "<div class='wrap-collabsible'>`r`n"
            $ipHistoryHTML += "<input id='$($InputID)' class='toggle' type='checkbox'"
            if ($ipHistoryCnt -le $expandCount) { $ipHistoryHTML += " checked>" } else { $ipHistoryHTML += ">" }
            $ipHistoryHTML += "<label for='$($inputID)' class='lbl-toggle'>Version: $(Get-Date $change.VersionDate -Format 'dd-MMM-yyyy') : $($changeslast.count) item(s)</label>`r`n"
            $ipHistoryHTML += "<div class='collapsible-content'><div class='content-inner'>`r`n"
            $ipHistoryHTML += "<div class='tableInc'>`r`n"
            $ipHistoryHTML += "<div class='tableInc-header'>`r`n"
            $ipHistoryHTML += "<div class='tableInc-header-l'>Service Area</div>`r`n"
            $ipHistoryHTML += "<div class='tableInc-header-l'>Disposition</div>`r`n<div class='tableInc-header-l'>Impact</div>`r`n"
            $ipHistoryHTML += "<div class='tableInc-header-l' style='max-width:250px'>Add</div>`r`n<div class='tableInc-header-l' style='max-width:250px'>Remove</div>`r`n"
            $ipHistoryHTML += "<div class='tableInc-header-l' style='max-width:150px'>Current</div>`r`n`<div class='tableInc-header-l' style='max-width:150px'>Previous</div>`r`n"
            $ipHistoryHTML += "</div>`r`n"
        }
        $ipHistory = ""
        foreach ($item in $changesLast) {
            $cat = ""
            if ($html) { $ipHistory += "<tr>" } else { $ipHistory += "<div class='tableInc-row'>" }
            $serviceArea = ($changesEPSIDX | Where-Object { $item.endpointsetid -eq $_.id }).ServiceArea
            if ($item.endpointsetid -in ($watchCats.id)) {
                $cat = ($watchCats | where-Object { $_.id -eq $item.endpointsetid }).category
                if ($cat -like 'Optimize') { $suffix = "<font color='red'> ($($cat))</font>" }
                elseif ($cat -like 'Allow') { $suffix = "<font color='blue'> ($($cat))</font>" }
            }
            else { $suffix = "" }
            $serviceArea = "$($serviceArea)$($suffix)"
            if ($html) {
                $ipHistory += "<td>[$($item.endpointsetid)] $($serviceArea)</td>`n`t"
                $ipHistory += "<td>$($item.disposition)</td>`n`t"
            }
            else {
                $ipHistory += "<div class='tableInc-cell-l'>[$($item.endpointsetid)] $($serviceArea)</div>`n`t"
                $ipHistory += "<div class='tableInc-cell-l'>$($item.disposition)</div>`n`t"
            }
            $desc = $item.impact
            if ($null -ne $desc) {
                $desc = $desc.replace("RemovedIpOrUrl", "Removed IP or URL")
                $desc = $desc.replace("AddedIP", "Added IP")
                $desc = $desc.replace("AddedUrl", "Added URL")
                $desc = $desc.replace("RemovedDuplicateIpOrUrl", "Removed Duplicate IP or URL")
                $desc = $desc.replace("OtherNonPriorityChanges", "Non-Priority Change")
                $desc = $desc.replace("MovedIpOrUrl", "Moved IP or URL")
                $desc = $desc.replace(",", "<br/>")
            }
            if ($html) { $ipHistory += "<td>$($desc)</td>`n`t" }
            else { $ipHistory += "<div class='tableInc-cell-l'>$($desc)</div>`n`t" }
            #Get IP and URL changes
            $entry = @()
            $addED, $addIP, $addURL = $null
            $remIP, $remURL = $null
            $entry = @($changesFlat | Where-Object { $_.id -eq $item.id -and $_.action -like 'Add' })
            if ($null -ne ([string]$entry.effectivedate -as [datetime])) {
                if ((Get-Date $entry.effectivedate) -gt (Get-Date)) { $colour = "<font color='red'>" } else { $colour = "<font color='green'>" }
                $addED = "<b>Effective Date:</b> $($colour)<b>$($entry.effectivedate)</b></font><br/>"
            }
            if (!([string]::IsNullOrEmpty($entry.IPs))) { $addIP = "<b>Add IPs:</b> $($entry.ips)<br/>" }
            if (!([string]::IsNullOrEmpty($entry.urls))) { $addURL = "<b>Add URLs:</b> $($entry.urls)" }
            if ($html) { $ipHistory += "<td  style='max-width:250px'>$($addED)$($addIP)$($addURL)</td>`n`t" }
            else { $ipHistory += "<div class='tableInc-cell-l' style='max-width:250px'>$($addED)$($addIP)$($addURL)</div>`n`t" }
            $entry = @()
            $addED, $addIP, $addURL = $null
            $remIP, $remURL = $null
            $entry = @($changesFlat | Where-Object { $_.id -eq $item.id -and $_.action -like 'Remove' })
            if (!([string]::IsNullOrEmpty($entry.ips))) { $remIP = "<b>Remove IPs:</b> $($entry.ips)<br/>" }
            if (!([string]::IsNullOrEmpty($entry.urls))) { $remURL = "<b>Remove URLs:</b> $($entry.urls)" }
            if ($html) { $ipHistory += "<td  style='max-width:250px'>$($remIP)$($remURL)</td>`n`t" }
            else { $ipHistory += "<div class='tableInc-cell-l' style='max-width:250px'>$($remIP)$($remURL)</div>`n`t" }
            $itemEP, $itemSA, $itemCat, $itemRqd, $itemTCP, $itemUDP, $itemNotes = ""
            $itemCur = ($item.current -replace '@{' -replace '}').Split(";") | ConvertFrom-StringData
            if ($item.Current) {
                if ($null -ne $itemCur.expressroute) { $itemEP = "<b>Express Route:</b> $($itemCur.expressroute)<br/>" }
                if ($null -ne $itemCur.serviceArea) { $itemSA = "<b>Service Area:</b> $($itemCur.serviceArea)<br/>" }
                if ($null -ne $itemCur.category) { $itemCat = "<b>Category:</b> $($itemCur.category)<br/>" }
                if ($null -ne $itemCur.required) { $itemRqd = "<b>Required:</b> $($itemCur.required)<br/>" }
                if ($null -ne $itemCur.tcpPorts) { $itemTCP = "<b>TCP Ports:</b> $($itemCur.tcpPorts)<br/>" }
                if ($null -ne $itemCur.udpPorts) { $itemUDP = "<b>UDP Ports:</b> $($itemCur.udpPorts)<br/>" }
                if ($null -ne $itemCur.notes) { $itemNotes = "<b>Notes:</b> $($itemCur.Notes)<br/>" }
            }
            if ($html) { $ipHistory += "<td  style='max-width:150px'>$($itemEP)$($itemSA)$($itemCat)$($itemRqd)$($itemTCP)$($itemUDP)$($itemNotes)</td>`n`t" }
            else { $ipHistory += "<div class='tableInc-cell-l' style='max-width:150px'>$($itemEP)$($itemSA)$($itemCat)$($itemRqd)$($itemTCP)$($itemUDP)$($itemNotes)</div>`n`t" }
            $itemEP, $itemSA, $itemCat, $itemRqd, $itemTCP, $itemUDP, $itemNotes = ""
            $itemPre = ($item.Previous -replace '@{' -replace '}').Split(";") | ConvertFrom-StringData
            if ($item.Previous) {
                if ($null -ne $itemPre.expressroute) { $itemEP = "<b>Express Route:</b> $($itemPre.expressroute)<br/>" }
                if ($null -ne $itemPre.serviceArea) { $itemSA = "<b>Service Area:</b> $($itemPre.serviceArea)<br/>" }
                if ($null -ne $itemPre.category) { $itemCat = "<b>Category:</b> $($itemPre.category)<br/>" }
                if ($null -ne $itemPre.required) { $itemRqd = "<b>Required:</b> $($itemPre.required)<br/>" }
                if ($null -ne $itemPre.tcpPorts) { $itemTCP = "<b>TCP Ports:</b> $($itemPre.tcpPorts)<br/>" }
                if ($null -ne $itemPre.udpPorts) { $itemUDP = "<b>UDP Ports:</b> $($itemPre.udpPorts)<br/>" }
                if ($null -ne $itemPre.notes) { $itemNotes = "<b>Notes:</b> $($itemPre.Notes)<br/>" }
            }
            if ($html) {
                $ipHistory += "<td  style='max-width:150px'>$($itemEP)$($itemSA)$($itemCat)$($itemRqd)$($itemTCP)$($itemUDP)$($itemNotes)</td>`n`t"
                $ipHistory += "</tr>`n"
            }
            else {
                $ipHistory += "<div class='tableInc-cell-l' style='max-width:150px'>$($itemEP)$($itemSA)$($itemCat)$($itemRqd)$($itemTCP)$($itemUDP)$($itemNotes)</div>`n`t"
                $ipHistory += "</div>`n"
            }
        }
        $ipHistoryHTML += $ipHistory
        if ($html) { $ipHistoryHTML += "</tbody></table><br/>`r`n" }
        else { $ipHistoryHTML += "</div></div></div></div><br/>`r`n" }
    }
    return $ipHistoryHTML
}

function IgnoreSSLWarnings {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    if (-not ([System.Management.Automation.PSTypeName]'ServerCertificateValidationCallback').Type) {
        $certCallback = @"
    using System;
    using System.Net;
    using System.Net.Security;
    using System.Security.Cryptography.X509Certificates;
    public class ServerCertificateValidationCallback
    {
        public static void Ignore()
        {
            if(ServicePointManager.ServerCertificateValidationCallback ==null)
            {
                ServicePointManager.ServerCertificateValidationCallback += 
                    delegate
                    (
                        Object obj, 
                        X509Certificate certificate, 
                        X509Chain chain, 
                        SslPolicyErrors errors
                    )
                    {
                        return true;
                    };
            }
        }
    }
"@
        Add-Type $certCallback
    }
    [ServerCertificateValidationCallback]::Ignore()	
}


function SendEmail {
    param (
        [Parameter(Mandatory = $true)] [string]$strMessage,
        [Parameter(Mandatory = $false)][AllowNull()] [System.Management.Automation.PSCredential]$credEmail,
        [Parameter(Mandatory = $true)] $config,
        [Parameter(Mandatory = $false)] [string]$strPriority = "Normal",
        [Parameter(Mandatory = $false)] $subject,
        [Parameter(Mandatory = $false)] [string[]]$emailTo,
        [Parameter(Mandatory = $false)] $attachment = ""
    ) 

    [string]$strSubject = $null
    [string]$strHeader = $null
    [string]$strFooter = $null
    [string]$strSig = $null
    [string]$strBody = $null

    #Build and send email (with attachment)

    $strSubject = "M365 [$($config.tenantshortname)]"
    if ($subject) { $strSubject += ": $($subject)" }
    else { $strSubject += ": Alert [$(Get-Date -f 'dd-MMM-yyy HH:mm:ss')]" }
    $css = Get-Content ..\common\M365email.css

    $strHeader = "<!DOCTYPE html PUBLIC ""-//W3C/DTD XHTML 1.0 Transitional//EN"" ""http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd""><html xmlns=""http://www.w3.org/1999/xhtml"">"
    $strHeader += "<head>`n<style type=""text/css"">`n" + $css + "</style></head>`n"
    $strBody = "<body><b>Alert [$(Get-Date -f 'dd-MMM-yyy HH:mm:ss')]</b><br/>`r`n"
    $strBody += $strMessage
    $strSig = "<br/><br/>Kind regards<br/>Powershell scheduled task<br/><br/><b><i>(Automated report/email, do not respond)</i></b><br/>`n"
    $strSig += "<font: xx-small>Generated on: $env:computername by: $($env:userdomain)\$($env:username)</font></br>`n"

    $strFooter += "</body>`n"
    $strFooter += "</html>`n"
    $strHTMLBody = $strHeader + $strBody + $strSig + $strFooter
    [array]$strTo = $emailTo.Split(",")
    $strTo = $strTo.replace('"', '')
    if ($null -eq $config.EmailFrom) { break; }
    #Splat the parameters
    $params = @{ }
    $params += @{to = $strTo; subject = $strSubject; body = $strHTMLBody; BodyAsHTML = $true; priority = $strPriority; from = $config.emailfrom; smtpServer = $config.EmailHost; port = $config.emailport }
    If ($credemail -notlike '') {
        $params += @{Credential = $credEmail } 
    }
    If ($config.EmailUseSSL -eq 'True') {
        $params += @{UseSSL = $true } 
    }
    if ($attachment -ne "") {
        $params += @{attachments = $attachment } 
    }
    Send-MailMessage @params
}

function cardBuilder {
    Param (
        [Parameter(Mandatory = $true)] $strName,
        [Parameter(Mandatory = $true)] $strDays,
        [Parameter(Mandatory = $true)] $strMessages,
        [Parameter(Mandatory = $true)] $strAdvisories,
        [Parameter(Mandatory = $true)] $strPriority
    ) 
    [array]$rptCard = @()
    $tableClass = "class='card-type-$($strPriority)'"
    $rptCard = @"
    <div $tableClass>
    `t<div class='card-body'>
    `t`t<div class='card-row'>
    `t`t`t<div class='card-name'>$($strName)</div></div></div>
    `t`t`t<div class='card-body'>
    `t`t`t`t<div class='card-row'>
    `t`t`t`t`t<div class='card-number'>$($strDays)</div>
    `t`t`t`t`t<div class='card-text'>Days Since<br/>Last Incident</div>
    `t`t`t`t</div>
    `t`t`t`t<div class='card-row'>
    `t`t`t`t`t<div class='card-number'>$($strMessages)</div>
    `t`t`t`t`t<div class='card-text'>Recent<br/>Incidents</div>
    `t`t`t`t</div>
    `t`t`t`t<div class='card-row'>
    `t`t`t`t`t<div class='card-number'>$($strAdvisories)</div>
    `t`t`t`t`t<div class='card-text'>Listed Advisories</div>
    `t`t`t`t</div>
    `t`t`t</div>`n`t`t</div>
"@
    return $rptCard
}


function featureBuilder {
    Param (
        [Parameter(Mandatory = $true)] $strName,
        [Parameter(Mandatory = $true)] $strFeatures,
        [Parameter(Mandatory = $true)] $strPriority,
        [Parameter(Mandatory = $true)] $intFtCnt
    )
    [array]$rptCard = @()
    [decimal]$decSize = 0
    $decSize = (($intFtCnt * 0.5) + ([math]::ceiling(($strName.length) / 14) * .75) + 0.1) * 2
    [int]$intSize = $decSize
    $tableClass = "class='workload-card-$($strPriority)' style='grid-row: span $($intSize)'"
    $rptCard = @"
    <div $tableClass>
    `t<div class='wkld-name'>$($strName)</div>
    `t$($strFeatures)
    </div>
"@
    return $rptCard
}

function SkuCardBuilder {
    Param (
        [Parameter(Mandatory = $true)] $strName,
        [Parameter(Mandatory = $true)] $strFeatures,
        [Parameter(Mandatory = $true)] $strPriority,
        [Parameter(Mandatory = $true)] $intFtCnt
    ) 
    [array]$rptCard = @()
    [decimal]$decSize = 0
    $decSize = (($intFtCnt * 1) + ([math]::ceiling(($strName.length) / 20) * .75) + 0.1) * 2
    [int]$intSize = $decSize
    $tableClass = "class='sku-card-$($strPriority)' style='grid-row: span $($intSize)'"
    $rptCard = @"
    <div $tableClass>
    `t<div class='sku-name'>$($strName)</div>
    `t$($strFeatures)
    </div>
"@
    return $rptCard
}

function Get-IncidentInHTML {
    Param (
        [Parameter(Mandatory = $true)] $item,
        [Parameter(Mandatory = $true)] $RebuildDocs,
        [Parameter(Mandatory = $true)] $pathHTMLDocs
    )
    # Get the incident message text and change to something nice in HTML.
    # Message text in advisories has different formatting.
    #Get the latest published date
    #If published in the last 2 hours mins then re-build the html - really need to check the published date when it appears.
    [array]$subMessages = @()
    [string]$htmlBuild = ""
    [int]$pubWindow = 0

    #Main item data
    $url = "docs/$($item.ID).html"
    $htmlHead = "<title>$($item.ID) - $($item.service)</title>"
    $css = Get-Content ..\common\article.css
    $htmlHead += $css
    $htmlBody += "<table class='msg'>"
    $htmlBody += "<tr><th colspan=7 style='font-size:x-large;'>$($item.ImpactDescription)</th></tr>"
    $htmlBody += "<tr><th>ID</th><th>Workload<br/>Feature</th><th>Title</th><th>Classification</th><th>Severity</th><th>Start Time</th><th>Last Updated</th></tr>"
    $htmlBody += "<tr class='msgO'><td>$($item.ID)</td><td>$($item.service)<br/>$($item.FeatureGroup)<br/>$($item.Feature)</td><td>$($item.Title)</td><td>$($item.Classification)</td><td>$($item.highImpact)</td><td>$(Get-Date $item.StartDateTime -f 'dd-MMM-yyyy HH:mm')</td><td>$(Get-Date $item.LastModifiedDateTime -f 'dd-MMM-yyyy HH:mm')</td></tr>"
    $subMessages = $item | Select-Object -ExpandProperty posts
    $subMessages = $subMessages | Sort-Object createdDateTime -Descending
    $pubWindow = (New-TimeSpan -Start (Get-Date $submessages[0].createdDateTime) -End $(Get-Date)).TotalHours
    $updWindow = (New-TimeSpan -Start (Get-Date $item.LastModifiedDateTime) -End $(Get-Date)).TotalHours
    if ($pubWindow -le 18 -or $RebuildDocs -or $updWindow -le 72) {
        #Article was updated in the last 2 hours. Lets update it Or force rebuild of docs
        foreach ($message in $subMessages) {
            $htmlBuild = Get-htmlMessage $message.description.content
            $htmlBuild = "<br/><b>Update:</b> $(Get-Date $message.createdDateTime -f 'dd-MMM-yyyy HH:mm')<br/>" + $htmlBuild
            $htmlSub += $htmlBuild + "<hr><br/>"
        }
        $htmlBody += "<tr><td colspan=7>$($htmlSub)</td></tr>"
        $htmlBody += "</table>"
        ConvertTo-Html -Head $htmlHead -Body $htmlBody | Out-File "$($pathHTMLDocs)\$($item.ID).html"
    }
    #Return a link to the file
    return $url
}
function Get-AdvisoryInHTML {
    Param (
        [Parameter(Mandatory = $true)] $item,
        [Parameter(Mandatory = $true)] $RebuildDocs,
        [Parameter(Mandatory = $true)] $pathHTMLDocs
    )
    #Get the latest published date
    #If published in the last 60 mins then re-build the html - really need to check the published date when it appears.
    [string]$htmlBuild = ""
    [int]$pubWindow = 0
    #Main item data
    $url = "docs/$($item.ID).html"
    $htmlHead = "<title>$($item.ID) - $($item.Title)</title>"
    $css = Get-Content ..\common\article.css
    $htmlHead += $css
    $htmlBody += "<table class='msg'>"
    $htmlBody += "<tr><th colspan=7 style='font-size:x-large;'>$($item.Title)</th></tr>"
    $htmlBody += "<tr><th>ID</th><th>Workload</th><th>Category</th><th>Classification</th><th>Severity</th><th>Start Time</th><th>Last Updated</th></tr>"
    $htmlBody += "<tr class='msgO'><td>$($item.ID)</td><td>$($item.services)</td><td>$($item.category)</td><td>$($item.tags)</td><td>$($item.Severity)</td><td>$(Get-Date $item.StartdateTime -f 'dd-MMM-yyyy HH:mm')</td><td>$(Get-Date $item.lastModifiedDateTime -f 'dd-MMM-yyyy HH:mm')</td></tr>"
    $pubWindow = (New-TimeSpan -Start (Get-Date $item.lastModifiedDateTime) -End $(Get-Date)).TotalHours
    if ($RebuildDocs -or $pubWindow -le 2) {
        #Article has been updated in the last 2 hours, or force a rebuild of documents
        $htmlBuild = $item.body.content
        $htmlBuild = "<br/><b>Update:</b> $(Get-Date $item.lastModifiedDateTime -f 'dd-MMM-yyyy HH:mm')<br/>" + $htmlBuild
        $htmlBuild = $htmlBuild -replace "Title:", "<b>Title</b>:"
        $htmlBuild = $htmlBuild -replace "`n", "<br/>"
        $htmlBuild = $htmlBuild -replace ("`n", '<br>') -replace ([char]8217, "'") -replace ([char]8220, '"') -replace ([char]8221, '"') -replace ('\[', '<b><i>') -replace ('\]', '</i></b>')
        $htmlSub += $htmlBuild + "<br/>"
        $htmlBody += "<tr><td colspan=7>$($htmlSub)</td></tr>"
        $htmlBody += "</table>"
        ConvertTo-Html -Head $htmlHead -Body $htmlBody | Out-File "$($pathHTMLDocs)\$($item.ID).html"
    }
    #Return a link to the file
    return $url
}

function GetSchedEmailTo {
    Param (
        [Parameter(Mandatory = $true)] $nameScript
    )
    [string]$dow = (get-date).DayOfWeek.ToString().Substring(0, 3)
    [datetime]$dtmNow = Get-Date

    Write-Log "Checking scheduled recipients for $nameScript script."
    $filenameSched = ".\schedule.csv"
    $pathSched = resolve-path $filenameSched

    #Check if schedule file exists
    if (Test-Path $($pathSched)) {
        $schedule = import-csv $filenameSched
        write-log "Importing schedule from $pathSched"
    }
    else {
        write-log "No schedule file found to import at $pathSched"
    }
    $schedule = import-csv $filenameSched
    write-log "Importing schedule from $pathSched"

    [boolean]$chkScript = $false
    [boolean]$chkDay = $false
    [boolean]$chkTime = $false

    $strEmail = @()
    foreach ($entry in $schedule) {
        if (($entry.script -like '*') -or ($entry.script -like $nameScript)) { $chkScript = $true } else { $chkScript = $false }
        if (($entry.day -like '`*') -or ($entry.day -match $dow)) { $chkDay = $true } else { $chkDay = $false }
        if ($entry.starttime -like '`*') { $timeStart = "00:00:00" } else { $timeStart = Get-Date $entry.startTime -Format 'HH:mm:ss' }
        if ($entry.endtime -like '`*') { $timeEnd = "23:59:59" } else { $timeEnd = Get-Date $entry.endTime -Format 'HH:mm:ss' }
        if ($dtmnow -ge $timeStart -and $dtmNow -le $timeEnd) { $chkTime = $true } else { $chkTime = $false }
        If ($chkScript -and $chkDay -and $chkTime) { $strEmail += $entry.email }
    }

    Write-Log "It is $($dow) at $(Get-Date $dtmnow -Format HH:mm:ss)"
    [string]$strEmail2 = '"{0}"' -f ($strEmail -join '","')
    Write-Log "The following will be emailed: $($strEmail2)"

    return $strEmail
}


function Get-BearerToken {
    param (
        [Parameter(Mandatory = $TRue)] [string]$tenantID,
        [Parameter(Mandatory = $TRue)] [string]$uriResource,
        [Parameter(Mandatory = $false)] [string]$appID,
        [Parameter(Mandatory = $false)] [string]$appSecret,
        [Parameter(Mandatory = $false)] [boolean]$proxyServer,
        [Parameter(Mandatory = $false)] [string]$proxyHost

    )
    
    [uri]$authority = "https://login.microsoftonline.com/$($TenantID)/oauth2/v2.0/token"
    $reqTokenBody = @{
        Grant_Type    = "client_credentials"
        Scope         = $uriResource
        Client_ID     = $appID
        Client_Secret = $appSecret
    }
    
    if ($proxyServer) {
        $bearerToken = invoke-RestMethod -uri $authority -Method Post -Body $reqTokenBody -Proxy $proxyHost -ProxyUseDefaultCredentials
    }
    else {
        $bearerToken = Invoke-RestMethod -uri $authority -Method Post -Body $reqTokenBody
    }
    
    $authHeader = @{
        'Content-Type' = 'application/json'
        Authorization  = "$($bearerToken.token_type) $($bearerToken.access_token)"
    }
    
    if ($null -eq $bearerToken) {
        $evtMessage = "ERROR - No authentication result for Auzre AD App"
        Write-ELog -LogName $evtLogname -Source $evtSource -Message "$($rptProfile) : $evtMessage" -EventId 10 -EntryType Error
        Write-Log $evtMessage
    }
    return $authHeader
}

function Get-GraphListResults {
    param (
        [Parameter(Mandatory = $TRue)] [string]$uriResource,
        [Parameter(Mandatory = $false)] [hashtable]$authHeader,
        [Parameter(Mandatory = $false)] [boolean]$proxyServer,
        [Parameter(Mandatory = $false)] [string]$proxyHost
    )
    if ($proxyServer) {
        [array]$results = Invoke-RestMethod -Uri $uriResource -Headers $authHeader -Method Get -Proxy $proxyHost -ProxyUseDefaultCredentials
    }
    else {
        [array]$results = Invoke-RestMethod -Uri $uriResource -Headers $authHeader -Method Get
    }

    [array]$graphResponse = $()
    [array]$graphResponse = $results.value

    $pages = $results."@odata.nextlink"
    while ($null -ne $pages) {
        if ($proxyServer) {
            $additional = Invoke-RestMethod -Uri $pages -Headers $authHeader -Method Get -Proxy $proxyHost -ProxyUseDefaultCredentials
        }
        else {
            $additional = Invoke-RestMethod -Uri $pages -Headers $authHeader -Method Get
        }
        $graphResponse += $additional.value
        if ($pages) {
            $pages = $additional."@odata.nextlink"
        }
    }

    return $graphResponse
}

function Get-IncidentPIR {
    param (
        [Parameter(Mandatory = $true)] [string]$filepath,
        [Parameter(Mandatory = $true)] [string]$incidentID,
        [Parameter(Mandatory = $false)] [hashtable]$authHeader,
        [Parameter(Mandatory = $false)] [boolean]$proxyServer,
        [Parameter(Mandatory = $false)] [string]$proxyHost
    )
    $localPath = "$($filepath)\$($incidentID).docx"
    $uriResource = "https://graph.microsoft.com/v1.0/admin/serviceAnnouncement/issues/$($incidentID)/incidentReport"
    if ($proxyServer) {
        [array]$results = Invoke-RestMethod -Uri $uriResource -Headers $authHeader -Method Get -Proxy $proxyHost -ProxyUseDefaultCredentials -OutFile $localPath
    }
    else {
        [array]$results = Invoke-RestMethod -Uri $uriResource -Headers $authHeader -Method Get -OutFile $localPath
    }

    $pirLink = "docs/$($incidentID).docx"
    return $PIRLink
}
