﻿<#
//***********************************************************************
//
// Copyright (c) 2018 Microsoft Corporation. All rights reserved.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
//
//**********************************************************************​
#>

<#
.SYNOPSIS
    This script grabs the office 365 Usage reports in CSV format.

.DESCRIPTION
    This script is designed to run on a scheduled basis.
    Configuration file is required allowing script to be called for multiple tenants.

    Requirements:
    Azure AD powershell module (Install-Module AzureAD)
    Azure AD Application - Tenant ID, Application ID and Secret. (store in config file)

.EXAMPLE
    PS .\M365-Usage.ps1 -configXML '..\example.xml' -ReportTimeSpan D7 -ReportType All

    Uses the specific XML settings file to load tenant information. The file is specified relative to the location of this script, or absolute location
	All reports listed will be downloaded for a 7 day timespan

.NOTES
    Author:  Jonathan Christie
    PSVer:   2.0/3.0/4.0/5.0
    Version: 3.0.1
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)] [String]$configXML = "..\config\example.xml",
    [Parameter(Mandatory = $false)] [ValidateSet("D7", "D30", "D90", "D180")][String]$ReportTimeSpan = "D7",
    [Parameter(Mandatory = $false)] [ValidateSet("All", "UserDetail")][String]$ReportType = "UserDetail",
    [Parameter(Mandatory = $false)] [String]$ReportSet = "",
    [Parameter(Mandatory = $false)] [String]$ReportOutput = ""
)

function Write-Log {
    param (
        [Parameter(Mandatory = $true)] [string]$info
    )
    # verify the Log is setup and if not create the file
    if ($script:loginitialized -eq $false) {
        $script:FileHeader >> $script:logfile
        $script:loginitialized = $True
    }
    $info = $(Get-Date).ToString() + ": " + $info
    $info >> $script:logfile
}

Import-Module "..\common\M365ServiceHealth.psm1"
#Get the EULA
$eula = ShowEulaIfNeeded SfMC-M365ServiceHealth 0
if ($eula -ne "Yes") {
    Write-Output "You must accept the EULA to proceed"
}
else {
    $swScript = [system.diagnostics.stopwatch]::StartNew()
    Write-Verbose "Changing Directory to $PSScriptRoot"
    Set-Location $PSScriptRoot


    if ([system.IO.path]::IsPathRooted($configXML) -eq $false) {
        #its not an absolute path. Find the absolute path
        $configXML = Resolve-Path $configXML
    }
    $config = LoadConfig $configXML

    [string]$pathLogs = $config.LogPath
    [string]$pathUsageReports = $config.UsageReportsPath
    #check if path is passed via Parameter (override config)
    if ($ReportOutput) {
        #Param passed as input
        $pathUsageReports = $ReportOutput
    }

    [array]$allResults = @()

    #Configure local event log
    [string]$evtLogname = $config.EventLog
    #[string]$evtSource = $config.UsageEventSource
    [string]$evtSource = "UsageReports"
    if ($config.UseEventlog -like 'true') {
        [boolean]$UseEventLog = $true
        #check source and log exists
        $CheckLog = [System.Diagnostics.EventLog]::Exists("$($evtLogname)")
        $CheckSource = [System.Diagnostics.EventLog]::SourceExists("$($evtSource)")
        if ((! $CheckLog) -or (! $CheckSource)) {
            New-EventLog -LogName $evtLogname -Source $evtSource
        }
    }
    else { [boolean]$UseEventLog = $false }

    [string]$tenantID = $config.TenantID
    [string]$appID = $config.AppID
    [string]$clientSecret = $config.AppSecret

    [string]$rptProfile = $config.TenantShortName
    [string]$proxyHost = $config.ProxyHost

    #If no path has been specified, use the current script location
    if (!$pathLogs) {
        $pathLogs = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent
    }

    #Check for a reports set file if specified
    if ($ReportSet) {
        if ([system.IO.path]::IsPathRooted($ReportSet) -eq $false) {
            #its not an absolute path. Find the absolute path
            $ReportSet = Resolve-Path $ReportSet
        }
        $rptsAction = Get-Content $ReportSet | ConvertFrom-Json
    }

    #Check and trim the report path
    $pathLogs = $pathLogs.TrimEnd("\")
    $pathUsageReports = $pathUsageReports.TrimEnd("\")
    #Build and Check output directories
    #Base for logs
    if (!(Test-Path $($pathLogs))) {
        New-Item -ItemType Directory -Path $pathLogs
    }
    if ([system.IO.path]::IsPathRooted($pathLogs) -eq $false) {
        #its not an absolute path. Find the absolute path
        $pathLogs = Resolve-Path $pathLogs
    }
    #Check reports output folder
    if (!(Test-Path $($pathUsageReports))) {
        New-Item -ItemType Directory -Path $pathUsageReports
    }
    if ([system.IO.path]::IsPathRooted($pathUsageReports) -eq $false) {
        #its not an absolute path. Find the absolute path
        $pathUsageReports = Resolve-Path $pathUsageReports
    }

    # setup the logfile
    # If logfile exists, the set flag to keep logfile
    $script:DailyLogFile = "$($pathLogs)\M365Usage-$($rptprofile)-$(Get-Date -format yyMMdd).log"
    $script:LogFile = "$($pathLogs)\tmpM365Usage-$($rptprofile)-$(Get-Date -format yyMMddHHmmss).log"
    $script:LogInitialized = $false
    $script:FileHeader = "*** Application Information ***"

    $evtMessage = "Config File: $($configXML)"
    Write-Log $evtMessage
    $evtMessage = "Log Path: $($pathLogs)"
    Write-Log $evtMessage
    $evtMessage = "HTML Output: $($pathHTML)"
    Write-Log $evtMessage

    if ($config.ProxyEnabled -like 'true') {
        [boolean]$ProxyServer = $true
        $evtMessage = "Using proxy server $($proxyHost) for connectivity"
        Write-Log $evtMessage
    }
    else {
        [boolean]$ProxyServer = $false
        $evtMessage = "No proxy to be used."
        Write-Log $evtMessage
    }


    #Create event logs if set
    if ($UseEventLog) {
        $evtCheck = Get-EventLog -List -ErrorAction SilentlyContinue | Where-Object { $_.LogDisplayName -eq $evtLogname }
        if (!($evtCheck)) {
            New-EventLog -LogName $evtLogname -Source $evtSource
            Write-ELog -useEventLog $useEventLog -LogName $evtLogname -Source $evtSource -Message "Event log created." -EventId 1 -EntryType Information
        }
    }

    #Keep a list of known issues in CSV. This is useful if the event log is cleared, or not used.
    [string]$evtLogAll = $null

    #Report info
    #Connect to Graph API

    [uri]$urlResource = "https://graph.microsoft.com/.default"
    [uri]$authority = "https://login.microsoftonline.com/$($TenantID)/oauth2/V2.0/token"
    $reqTokenBody = @{
        Grant_Type    = "client_credentials"
        Scope         = $urlResource
        Client_ID     = $appID
        Client_Secret = $clientSecret
    }

    if ($proxyServer) {
        $bearerToken = invoke-RestMethod -uri $authority -Method Post -Body $reqTokenBody -Proxy $proxyHost -ProxyUseDefaultCredentials
    }
    else {
        $bearerToken = invoke-RestMethod -uri $authority -Method Post -Body $reqTokenBody
    }

    $authHeader = @{
        Authorization = "$($bearerToken.token_type) $($bearerToken.access_token)"
    }

    if ($null -eq $bearerToken) {
        $evtMessage = "ERROR - No authentication result for Auzre AD App"
        Write-ELog -useEventLog $useEventLog -LogName $evtLogname -Source $evtSource -Message "$($rptProfile) : $evtMessage" -EventId 10 -EntryType Error
        Write-Log $evtMessage
    }

    #M365 reports to generate from https://docs.microsoft.com/en-us/graph/api/resources/report?view=graph-rest-1.0
    $rptsAllUsage = @(
        'getTeamsDeviceUsageUserDetail';
        'getTeamsDeviceUsageUserCounts';
        'getTeamsDeviceUsageDistributionUserCounts';
        'getTeamsUserActivityUserDetail';
        'getTeamsUserActivityCounts';
        'getTeamsUserActivityUserCounts';
        'getEmailActivityUserDetail';
        'getEmailActivityCounts';
        'getEmailActivityUserCounts';
        'getEmailAppUsageUserDetail';
        'getEmailAppUsageAppsUserCounts';
        'getEmailAppUsageUserCounts';
        'getEmailAppUsageVersionsUserCounts';
        'getMailboxUsageDetail';
        'getMailboxUsageMailboxCounts';
        'getMailboxUsageQuotaStatusMailboxCounts';
        'getMailboxUsageStorage';
        'getOffice365ActivationsUserDetail';
        'getOffice365ActivationCounts';
        'getOffice365ActivationsUserCounts';
        'getOffice365ActiveUserDetail';
        'getOffice365ActiveUserCounts';
        'getOffice365ServicesUserCounts';
        'getOffice365GroupsActivityDetail';
        'getOffice365GroupsActivityCounts';
        'getOffice365GroupsActivityGroupCounts';
        'getOffice365GroupsActivityStorage';
        'getOffice365GroupsActivityFileCounts';
        'getOneDriveActivityUserDetail';
        'getOneDriveActivityUserCounts';
        'getOneDriveActivityFileCounts';
        'getOneDriveUsageAccountDetail';
        'getOneDriveUsageAccountCounts';
        'getOneDriveUsageFileCounts';
        'getOneDriveUsageStorage';
        'getSharePointActivityUserDetail';
        'getSharePointActivityFileCounts';
        'getSharePointActivityUserCounts';
        'getSharePointActivityPages';
        'getSharePointSiteUsageDetail';
        'getSharePointSiteUsageFileCounts';
        'getSharePointSiteUsageSiteCounts';
        'getSharePointSiteUsageStorage';
        'getSharePointSiteUsagePages';
        'getSkypeForBusinessActivityUserDetail';
        'getSkypeForBusinessActivityCounts';
        'getSkypeForBusinessActivityUserCounts';
        'getSkypeForBusinessDeviceUsageUserDetail';
        'getSkypeForBusinessDeviceUsageDistributionUserCounts';
        'getSkypeForBusinessDeviceUsageUserCounts';
        'getSkypeForBusinessOrganizerActivityCounts';
        'getSkypeForBusinessOrganizerActivityUserCounts';
        'getSkypeForBusinessOrganizerActivityMinuteCounts';
        'getSkypeForBusinessParticipantActivityCounts';
        'getSkypeForBusinessParticipantActivityUserCounts';
        'getSkypeForBusinessParticipantActivityMinuteCounts';
        'getSkypeForBusinessPeerToPeerActivityCounts';
        'getSkypeForBusinessPeerToPeerActivityUserCounts';
        'getSkypeForBusinessPeerToPeerActivityMinuteCounts';
        'getYammerActivityUserDetail';
        'getYammerActivityCounts';
        'getYammerActivityUserCounts';
        'getYammerDeviceUsageUserDetail';
        'getYammerDeviceUsageDistributionUserCounts';
        'getYammerDeviceUsageUserCounts';
        'getYammerGroupsActivityDetail';
        'getYammerGroupsActivityGroupCounts';
        'getYammerGroupsActivityCounts'
    )
    $rptsUserDetails = @(
        'getTeamsDeviceUsageUserDetail';
        'getTeamsUserActivityUserDetail';
        'getEmailActivityCounts';
        'getEmailActivityUserCounts';
        'getEmailActivityUserDetail';
        'getEmailAppUsageUserDetail';
        'getMailboxUsageDetail';
        'getOffice365ActivationsUserDetail';
        'getOffice365ActiveUserDetail';
        'getOffice365GroupsActivityDetail';
        'getOneDriveActivityUserDetail';
        'getOneDriveUsageAccountDetail';
        'getSharePointActivityUserDetail';
        'getSharePointSiteUsageDetail';
        'getSkypeForBusinessActivityUserDetail';
        'getSkypeForBusinessDeviceUsageUserDetail';
        'getYammerActivityUserDetail';
        'getYammerDeviceUsageUserDetail';
        'getYammerGroupsActivityDetail'
    )

    $Period = $ReportTimeSpan
    $evtMessage = $null
    $evtLogAll = $null
    $i = 0
    switch ($ReportType) {
        "All" { $UsageReports = $rptsAllUsage }
        "UserDetail" { $UsageReports = $rptsUserDetails }
    }
    if ($rptsAction) {
        $UsageReports = $rptsAction
    }


    foreach ($M365Report in $UsageReports) {
        $i++
        Write-Progress -Activity "Downloading data for $($M365Report)" -Status "Storing Office 365 Usage Report $i of $($UsageReports.count)" -PercentComplete (($i / $UsageReports.count) * 100)
        $allResults = $null
        $reportURI = $null
        # Activation reports dont take a time period, appending one causes an error. So dont.
        if ($M365Report -like "getOffice365Activation*") {
            $reportPeriod = ""
            $reportName = "$($M365Report)"
        }
        else {
            $reportPeriod = "(period='$($ReportTimeSpan)')"
            $reportName = "$($M365Report)-$($period)"
        }
        [uri]$reportURI = "https://graph.microsoft.com/v1.0/reports/$($M365Report)$($reportPeriod)"
        $evtMessage = "Working on report URI: $($reportURI)"
        Write-Log $evtMessage

        try {
            if ($proxyServer) {
                $allResults = Invoke-RestMethod -Uri $reportURI -Headers $authHeader -Method Get -Proxy $proxyHost -ProxyUseDefaultCredentials
            }
            else {
                $allResults = Invoke-RestMethod -Uri $reportURI -Headers $authHeader -Method Get
            }


            if ($null -eq $allResults) {
                $evtMessage = "No result returned for $($M365Report) : $($reportURI)"
                Write-Log $evtMessage
            }
            else {
                #Results are returned as string, comma seperated.
                #theres some characters at the start of the output to remove
                $allResults = $allResults.replace("ï»¿", "") | ConvertFrom-Csv
                if (!($null -eq $allResults)) {
                    $allResults | Export-Csv -Path "$($pathUsageReports)\$(Get-Date -f 'yyyyMMdd')-$($reportName).csv" -NoTypeInformation -Encoding UTF8
                    $evtMessage = "Exporting data for $($M365Report) : $($reportURI)"
                    Write-Log $evtMessage
                }
                else {
                    $evtMessage = "No data to export for $($M365Report) : $($reportURI)"
                    Write-Log $evtMessage
                }
            }
        }
        catch {
            $evtMessage = "Unable to download report for $($M365Report) : $($reportURI)`r`n"
            $evtMessage += "$($error[0].exception)"
            $evtLog = $evtMessage + "`r`n"
            Write-Log $evtMessage
            Write-ELog -useEventLog $useEventLog -LogName $evtLogname -Source $evtSource -Message $evtLog -EventId 15 -EntryType Error
        }
    }

    if ($evtLogAll.Length -gt 35000) { $evtLogAll = $evtLogAll.substring(0, 35000) }
    $swScript.Stop()
    $evtMessage = "Script runtime $($swScript.Elapsed.Minutes)m:$($swScript.Elapsed.Seconds)s:$($swScript.Elapsed.Milliseconds)ms on $env:COMPUTERNAME`r`n"
    $evtMessage += "*** Processing finished ***`r`n"
    Write-Log $evtMessage

    #Append to daily log file.
    Get-Content $script:logfile | Add-Content $script:Dailylogfile
    Remove-Item $script:logfile
}
Remove-Module M365ServiceHealth