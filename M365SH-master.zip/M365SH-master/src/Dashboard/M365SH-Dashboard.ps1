﻿<#
//***********************************************************************
//
// Copyright (c) 2018 Microsoft Corporation. All rights reserved.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
//
//**********************************************************************​
#>

<#
.SYNOPSIS
    Gets the Microsoft 365 Health Center messages and incidents
    Displays on several tabs with the summary providing a dashbord overview

.DESCRIPTION
    This script is designed to run on a scheduled basis.
    It requires and Azure AD Application for your tenant.
    The script will build an HTML page displaying information and links to tenant messages and articles.
    Several tenants configurations can be held.
    Microsoft 365 service health incidents generate email alerts as well as logging to the event log.
    Alternative links can be added (ie to an external dashboard) should data retrieval fail

    Requires Azure AD powershell module (Install-Module AzureAD)

.INPUTS
    None

.OUTPUTS
    None

.EXAMPLE
    PS C:\> M365SH-Dashboard.ps1 -configXML ..\config\production.xml

.EXAMPLE
	Build all linked incident and advisory documents as local HTML files

    PS C:\> M365SH-Dashboard.ps1 -configXML ..\config\production.xml -RebuildDocs


.NOTES
    Author:  Jonathan Christie
    Email:   jonathan.christie (at) microsoft.com
    Date:    02 Dec 2021
    PSVer:   2.0/3.0/4.0/5.0
    Version: 3.0.1
    Updated:
    UpdNote:

    Wishlist:

    Completed:

    Outstanding:

#>

[CmdletBinding()]
param (
    [Parameter(Mandatory = $true)] [String]$configXML = "..\config\example.xml",
    [Parameter(Mandatory = $false)] [Switch]$RebuildDocs = $false
)

   
function Write-Log {
    param(
        [Parameter(Mandatory = $true)] [string]$info
    )
    # verify the Log is setup and if not create the file
    if ($script:loginitialized -eq $false) {
        $script:FileHeader >> $script:logfile
        $script:loginitialized = $True
    }
    $info = $(Get-Date).ToString() + ": " + $info
    $info >> $script:logfile
}

function EnsureAzureADModule() {
    # Query for installed Azure AD modules
    $AadModule = Get-Module -Name "AzureAD" -ListAvailable
    if ($null -eq $AadModule) {
        Write-Output "AzureAD PowerShell module not found, looking for AzureADPreview"
        $AadModule = Get-Module -Name "AzureADPreview" -ListAvailable
    }

    if ($null -eq $AadModule) {
        Write-Output
        Write-Output "AzureAD Powershell module not installed..." -f Red
        Write-Output "Install by running 'Install-Module AzureAD' or 'Install-Module AzureADPreview' from an elevated PowerShell prompt" -f Yellow
        Write-Output "Script can't continue..." -f Red
        Write-Output
        exit
    }

    if ($AadModule.count -gt 1) {
        $Latest_Version = ($AadModule | Select-Object version | Sort-Object)[-1]
        $aadModule = $AadModule | Where-Object { $_.version -eq $Latest_Version.version }
        # Checking if there are multiple versions of the same module found
        if ($AadModule.count -gt 1) {
            $aadModule = $AadModule | Select-Object -Unique
        }
        $adal = Join-Path $AadModule.ModuleBase "Microsoft.IdentityModel.Clients.ActiveDirectory.dll"
        $adalforms = Join-Path $AadModule.ModuleBase "Microsoft.IdentityModel.Clients.ActiveDirectory.Platform.dll"
    }
    else {
        $adal = Join-Path $AadModule.ModuleBase "Microsoft.IdentityModel.Clients.ActiveDirectory.dll"
        $adalforms = Join-Path $AadModule.ModuleBase "Microsoft.IdentityModel.Clients.ActiveDirectory.Platform.dll"
    }

    [System.Reflection.Assembly]::LoadFrom($adal) | Out-Null
    [System.Reflection.Assembly]::LoadFrom($adalforms) | Out-Null
}

function BuildHTML {
    Param (
        [Parameter(Mandatory = $true)] $Title,
        [Parameter(Mandatory = $true)] $contentOne,
        [Parameter(Mandatory = $true)] $contentTwo,
        [Parameter(Mandatory = $true)] $contentThree,
        [Parameter(Mandatory = $true)] $contentFour,
        [Parameter(Mandatory = $true)] $contentLast,
        [Parameter(Mandatory = $true)] $HTMLOutput
    )
    [array]$htmlHeader = @()
    [array]$htmlBody = @()
    [array]$htmlFooter = @()
    if ($contentTwo -like "") { $showTwo = $false } else { $showTwo = $true }
    if ($contentThree -like "") { $showThree = $false } else { $showThree = $true }
    if ($contentFour -like "") { $showFour = $false } else { $showFour = $true }
    if ($contentLast -like "") { $showLast = $false } else { $showLast = $true }

    $htmlHeader = @"
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="M365Health.css">
<style>
</style>
<title>$($rptTitle)</title>
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
<meta http-equiv="Pragma" content="no-cache" />
<meta http-equiv="Expires" content="0" />
</head>
"@

    $htmlBody = @"

<body>
    <p>Page refreshed: <span id="datetime"></span><span>&nbsp;&nbsp;Data refresh: $(Get-Date -Format 'dd MMM yyy HH:mm:ss') [$((Get-Timezone).id)]</span></p>
	<div class="tab">
    <button class="tablinks" onclick="openTab(event,'Overview')" id="defaultOpen">Overview</button>
"@
    if ($showTwo) {
        $htmlBody += @"
    <button class="tablinks" onclick="openTab(event,'Incidents')">Incidents</button>
"@
    }
    if ($showThree) {
        $htmlBody += @"
    <button class="tablinks" onclick="openTab(event,'Messages')">Messages</button>
"@
    }
    if ($showFour) {
        $htmlBody += @"
    <button class="tablinks" onclick="openTab(event,'Roadmap')">Roadmaps</button>
"@
    }

    if ($showLast) {
        $htmlBody += @"
    <button class="tablinks" onclick="openTab(event,'Log')">Log</button>
"@
    }

    $htmlBody += @"
</div>

<!-- Tab content -->
<div id="Overview" class="tabcontent">
    $($contentOne)
</div>
"@

    if ($showTwo) {
        $htmlBody += @"
<div id="Incidents" class="tabcontent">
    $($contentTwo)
</div>
"@
    }

    if ($showThree) {
        $htmlBody += @"
<div id="Messages" class="tabcontent">
    $($contentThree)
</div>
"@
    }

    if ($showFour) {
        $htmlBody += @"
<div id="Roadmap" class="tabcontent">
    $($contentFour)
</div>
"@
    }
    if ($showLast) {
        $htmlBody += @"
<div id="Log" class="tabcontent">
    $($contentLast)
</div>
"@
    }
    $htmlFooter = @"
<script>
var dt = new Date();
const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
document.getElementById("datetime").innerHTML = (("0"+dt.getDate()).slice(-2)) +"-"+ (("0"+(dt.getMonth()+1)).slice(-2)) +"-"+ (dt.getFullYear()) +" "+ (("0"+dt.getHours()).slice(-2)) +":"+ (("0"+dt.getMinutes()).slice(-2)) +":"+ (("0"+dt.getSeconds()).slice(-2)) +" ["+ timezone +"]";
</script>

<script>
function openTab(evt, tabName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }

    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active","");
    }
    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.className += " active";
}

document.getElementById("defaultOpen").click();
</script>
</body>
</html>
"@

    #Add in code to refresh page
    #Editing after file is generated increases the file size drastically
    $addJava = "<script language=""JavaScript"" type=""text/javascript"">"
    $addJava += "setTimeout(""location.href='$($HTMLOutput)'"",$($pageRefresh*60*1000));"
    $addjava += "</script>"

    $htmlReport = $htmlHeader + $addJava + $htmlBody + $htmlFooter
    $htmlReport | Out-File "$($pathHTML)\$($HTMLOutput)"
}


Import-Module "..\common\M365ServiceHealth.psm1"
#Get the EULA
$eula = ShowEulaIfNeeded SfMC-M365ServiceHealth 0
if ($eula -ne "Yes") {
    Write-Output "You must accept the EULA to proceed"
}
else {
    $swScript = [system.diagnostics.stopwatch]::StartNew()
    Write-Verbose "Changing Directory to $PSScriptRoot"
    Set-Location $PSScriptRoot

    if ([system.IO.path]::IsPathRooted($configXML) -eq $false) {
        #its not an absolute path. Find the absolute path
        $configXML = Resolve-Path $configXML
    }
    $config = LoadConfig $configXML

    #Configure local event log
    [string]$evtLogname = $config.EventLog
    [string]$evtSource = $config.MonitorEvtSource

    if ($config.UseEventlog -like 'true') {
        [boolean]$UseEventLog = $true
        #check source and log exists
        $CheckLog = [System.Diagnostics.EventLog]::Exists("$($evtLogname)")
        $CheckSource = [System.Diagnostics.EventLog]::SourceExists("$($evtSource)")
        if ((! $CheckLog) -or (! $CheckSource)) {
            New-EventLog -LogName $evtLogname -Source $evtSource
        }
    }
    else { [boolean]$UseEventLog = $false }

    #Declare variables
    [string]$tenantID = $config.TenantID
    [string]$appID = $config.AppID
    [string]$clientSecret = $config.AppSecret
    [string]$emailEnabled = $config.EmailEnabled
    [string]$SMTPUser = $config.EmailUser
    [string]$SMTPPassword = $config.EmailPassword
    [string]$SMTPKey = $config.EmailKey

    [string]$addLink = $config.DashboardAddLink
    [string]$rptName = $config.DashboardName
    [int]$pageRefresh = $config.DashboardRefresh
    [int]$IncidentDays = $config.DashboardHistory
    [int]$intRecentMess = $config.DashboardRecMsgs
    if ($config.DashboardKISS -like 'true') { [boolean]$showKISS = $true } else { [boolean]$showKISS = $false }
    if ($config.DashboardShowInc -like 'true') { [boolean]$showInc = $true } else { [boolean]$showInc = $false }
    if ($config.DashboardShowMsgs -like 'true') { [boolean]$showMsgs = $true } else { [boolean]$showMsgs = $false }
    if ($config.DashboardShowRdMap -like 'true') { [boolean]$showRdMap = $true } else { [boolean]$showRdMap = $false }
    if ($config.DashboardShowLog -like 'true') { [boolean]$showLog = $true } else { [boolean]$showLog = $false }
    
    #Dashboard cards
    [string[]]$dashCards = $config.DashboardCards.split(",")
    $dashCards = $dashCards.Replace('"', '')
    $dashCards = $dashCards.Trim()

    #Ignore the Services and Incidents
    [array]$ignStatus = $config.MonitorIgnoreSvc
    if ($ignStatus -ne "") {
        $ignStatus = $ignStatus.replace('"', '')
        $ignStatus = $ignStatus.Trim()
        $ignStatus = $ignStatus.split(",")
    }

    [array]$ignIncidents = $config.MonitorIgnoreInc
    if ($ignIncidents -ne "") {
        $ignIncidents = $ignIncidents.replace('"', '')
        $ignIncidents = $ignIncidents.split(",")
    }

    [string]$rptProfile = $config.TenantShortName
    [string]$rptTenantName = $config.TenantName

    [string]$pathLogs = $config.LogPath
    [string]$pathHTML = $config.HTMLPath
    [string]$pathWorking = $config.WorkingPath
    [string]$HTMLFile = $config.DashboardHTML
    [string]$emailDashAlertsTo = $config.DashboardAlertsTo

    [string]$htmlDiagnostics = $config.ToolboxHTML
    [string]$htmlClientDiagnostics = "ClientDiags.txt"

    [string]$proxyHost = $config.ProxyHost

    if ($config.RSS1Enabled -like 'true') {
        [boolean]$rss1Enabled = $true
    }
    [string]$rss1Name = $config.RSS1Name
    [string]$rss1Feed = $config.RSS1Feed
    [string]$rss1URL = $config.RSS1URL
    [int]$rss1Items = $config.RSS1Items

    if ($config.RSS2Enabled -like 'true') {
        [boolean]$rss2Enabled = $true
    }
    [string]$rss2Name = $config.RSS2Name
    [string]$rss2Feed = $config.RSS2Feed
    [string]$rss2URL = $config.RSS2URL
    [int]$rss2Items = $config.RSS2Items

    [string]$Blogs = $config.Blogs

    [boolean]$rptOutage = $false

    [string]$cssfile = "M365Health.css"

    if ($config.EmailEnabled -like 'true') { [boolean]$emailEnabled = $true } else { [boolean]$emailEnabled = $false }

    # Get Email credentials
    # Check for a username. No username, no need for credentials (internal mail host?)
    [PSCredential]$emailCreds = $null
    if ($emailEnabled -and $smtpuser -notlike '') {
        #Email credentials have been specified, so build the credentials.
        #See readme on how to build credentials files
        $EmailCreds = getCreds $SMTPUser $SMTPPassword $SMTPKey
    }


    #Check the various file paths, set default, create and make absolute reference if necessary
    $pathLogs = CheckDirectory $pathLogs
    $pathHTML = CheckDirectory $pathHTML
    $pathWorking = CheckDirectory $pathWorking
    $pathHTMLDocs = CheckDirectory "$($pathHTML)\Docs"
    $pathHTMLImg = CheckDirectory "$($pathHTML)\images"


    # setup the logfile
    # If logfile exists, the set flag to keep logfile
    $script:DailyLogFile = "$($pathLogs)\M365Dashboard-$($rptprofile)-$(Get-Date -format yyMMdd).log"
    $script:LogFile = "$($pathLogs)\tmpM365Dashboard-$($rptprofile)-$(Get-Date -format yyMMddHHmmss).log"
    $script:LogInitialized = $false
    $script:FileHeader = "*** Application Information ***"

    $evtMessage = "Config File: $($configXML)"
    Write-Log $evtMessage
    $evtMessage = "Log Path: $($pathLogs)"
    Write-Log $evtMessage
    $evtMessage = "HTML Output: $($pathHTML)"
    Write-Log $evtMessage

    #Create event logs if set
    if ($UseEventLog) {
        $evtCheck = Get-EventLog -List -ErrorAction SilentlyContinue | Where-Object { $_.LogDisplayName -eq $evtLogname }
        if (!($evtCheck)) {
            New-EventLog -LogName $evtLogname -Source $evtSource
            Write-ELog -useEventLog $useEventLog -LogName $evtLogname -Source $evtSource -Message "Event log created." -EventId 1 -EntryType Information
        }
    }

    #Proxy Configuration
    if ($config.ProxyEnabled -like 'true') {
        [boolean]$ProxyServer = $true
        $evtMessage = "Using proxy server $($proxyHost) for connectivity"
        Write-Log $evtMessage
    }
    else {
        [boolean]$ProxyServer = $false
        $evtMessage = "No proxy to be used."
        Write-Log $evtMessage
    }

    [string]$urlGraph = "https://graph.microsoft.com/.default"
    $authGheader = Get-BearerToken $tenantID $urlGraph $appID $clientSecret $proxyServer $proxyHost

    #Now remove any system default proxy in order to test no-proxy paths.
    $defaultproxy = [System.Net.WebProxy]::GetDefaultProxy()
    [System.Net.GlobalProxySelection]::Select = [System.Net.GlobalProxySelection]::GetEmptyWebProxy()


    #https://docs.microsoft.com/en-gb/azure/active-directory/users-groups-roles/licensing-service-plan-reference

    #	Returns the list of subscribed services
    [uri]$uriHealthOverview = "https://graph.microsoft.com/v1.0/admin/serviceAnnouncement/healthOverviews" 
    [uri]$uriHealthIssues = "https://graph.microsoft.com/v1.0/admin/serviceAnnouncement/issues"
    [uri]$uriHealthMessages = "https://graph.microsoft.com/v1.0/admin/serviceAnnouncement/messages"


    #Fetch the information from Office 365 Service Health API
    #Get Services: Get the list of subscribed services
    $uriError = ""

    #graph API Health Overview
    $shHealthOverview = $null
    $shIssues = $null
    $shMessages = $null

    try {
        [array]$shOverview = Get-GraphListResults $uriHealthOverview $authGHeader $proxyserver $proxyHost
        if ($null -eq $shOverview -or $shOverview.Count -eq 0) {
            $rptM365Info += "[$(Get-Date -f 'dd-MMM-yy HH:mm:ss')] <p class='error'>No Subscribed services returned - verify proxy and network connectivity</p><br/>"
        }
        else {
            $rptM365Info += "[$(Get-Date -f 'dd-MMM-yy HH:mm:ss')] <p class='info'>$($shOverview.count) subscribed services returned.</p><br/>"
        }
    }
    catch {
        $rptM365Info += "[$(Get-Date -f 'dd-MMM-yy HH:mm:ss')] <p class='error'>No Subscribed services returned - verify proxy and network connectivity</p><br/>"
        $uriError += "Error connecting to $($uriHealthOverview)<br/><br/>`r`n"
        $uriError += "Error details:<br/> $($Error[0] | Select-Object *)"
    }

    #Get Current Status: Get a real-time view of current and ongoing service incidents and maintenance events
    #Graph API - Get a list of all health issues
    try {
        [array]$shIssues = Get-GraphListResults $uriHealthIssues $authGHeader $proxyServer $proxyHost

        if ($null -eq $shIssues -or $shIssues.Count -eq 0) {
            $rptM365Info += "[$(Get-Date -f 'dd-MMM-yy HH:mm:ss')] <p class='error'>Cannot retrieve the current Service Health issues - verify proxy and network connectivity</p><br/>"
        }
        else {
            $shIssues = $shIssues | Where-Object { $_.service -notin $ignStatus }
            $rptM365Info += "[$(Get-Date -f 'dd-MMM-yy HH:mm:ss')] <p class='info'>$($shIssues.count) services and status returned.</p><br/>"
        }
    }
    catch {
        $rptM365Info += "[$(Get-Date -f 'dd-MMM-yy HH:mm:ss')] <p class='error'>Cannot retrieve the current Service Health issues - verify proxy and network connectivity</p><br/>"
        $uriError += "Error connecting to $($uriHealthIssues)<br/><br/>`r`n"
        $uriError += "Error details:<br/> $($Error[0] | Select-Object *)"
    }

    #Get Current Status: Get a real-time view of current and ongoing service incidents and maintenance events
    #Graph API - Get a list of all Message center messages
    try {
        [array]$shMessages = Get-GraphListResults $uriHealthMessages $authGHeader $proxyServer $proxyHost

        if ($null -eq $shMessages -or $shMessages.Count -eq 0) {
            $rptM365Info += "[$(Get-Date -f 'dd-MMM-yy HH:mm:ss')] <p class='error'>Cannot retrieve the current Service Health messages - verify proxy and network connectivity</p><br/>"
        }
        else {
            $shMessages = $shMessages | Where-Object { $_.service -notin $ignStatus }
            $rptM365Info += "[$(Get-Date -f 'dd-MMM-yy HH:mm:ss')] <p class='info'>$($shMessages.count) services and status returned.</p><br/>"
        }
    }
    catch {
        $rptM365Info += "[$(Get-Date -f 'dd-MMM-yy HH:mm:ss')] <p class='error'>Cannot retrieve the current Service Health messages - verify proxy and network connectivity</p><br/>"
        $uriError += "Error connecting to $($uriHealthIssues)<br/><br/>`r`n"
        $uriError += "Error details:<br/> $($Error[0] | Select-Object *)"
    }

    if ($showRdMap) {
        if ($rss1Enabled) {
            try {
                if ($proxyServer) {
                    $rss1Data = @((Invoke-WebRequest -Uri $rss1Feed -Proxy $proxyHost -ProxyUseDefaultCredentials -UseBasicParsing).content)
                }
                else {
                    $rss1Data = @((Invoke-WebRequest -Uri $rss1Feed -UseBasicParsing).content)
                }
                if ($null -eq $rss1Data -or $rss1Data.Count -eq 0) {
                    $rptM365Info += "[$(Get-Date -f 'dd-MMM-yy HH:mm:ss')] <p class='error'>No $($rss1Name) RSS Feed information - verify proxy and network connectivity</p><br/>"
                }
                else {
                    $rptM365Info += "[$(Get-Date -f 'dd-MMM-yy HH:mm:ss')] <p class='info'>RSS feed items retrieved for $($rss1Name).</p><br/>"
                }
            }
            catch {
                $rptM365Info += "[$(Get-Date -f 'dd-MMM-yy HH:mm:ss')] <p class='error'>No $($rss1Name) RSS Feed information - verify proxy and network connectivity</p><br/>"
                $uriError += "Error connecting to $($rss1URL)<br/><br/>`r`n"
                $uriError += "Error details:<br/> $($Error[0] | Select-Object *)"
            }
        }

        if ($rss2Enabled) {
            try {
                if ($proxyServer) {
                    $rss2Data = @((Invoke-WebRequest -Uri $rss2Feed -Proxy $proxyHost -ProxyUseDefaultCredentials -UseBasicParsing).content)
                }
                else {
                    $rss2Data = @((Invoke-WebRequest -Uri $rss2Feed -UseBasicParsing).content)
                }
                if ($null -eq $rss2Data -or $rss2Data.Count -eq 0) {
                    $rptM365Info += "[$(Get-Date -f 'dd-MMM-yy HH:mm:ss')] <p class='error'>No $($rss2Name) RSS Feed information - verify proxy and network connectivity</p><br/>"
                }
                else {
                    $rptM365Info += "[$(Get-Date -f 'dd-MMM-yy HH:mm:ss')] <p class='info'>RSS feed items retrieved for $($rss2Name).</p><br/>"
                }
            }
            catch {
                $rptM365Info += "[$(Get-Date -f 'dd-MMM-yy HH:mm:ss')] <p class='error'>No $($rss2Name) RSS Feed information - verify proxy and network connectivity</p><br/>"
                $uriError += "Error connecting to $($uriAzureUpdates)<br/><br/>`r`n"
                $uriError += "Error details:<br/> $($Error[0] | Select-Object *)"
            }
        }
    }
    if ($emailEnabled -and $uriError) {
        $emailSubject = "Error(s) retrieving URL(s)"
        SendEmail $uriError $EmailCreds $config "High" $emailSubject $emailDashAlertsTo
    }

    $rptM365Info += "<br/>"
    $rptM365Info += "Diagnostics can be found here: <a href=$($htmlDiagnostics) target=_blank>Diagnostics page</a><br />"
    if (test-path "$($pathHTML)\$($htmlClientDiagnostics)") {
        $rptM365Info += "Client Diagnostics can be download from here: <a href=$($htmlClientDiagnostics) target=_blank>Rename from .txt to .ps1</a><br />"
    }

    if ($addLink) { $rptM365Info += "<a href='$($addLink)' target=_blank> here </a></li></ul><br>" }

    #Get current messages
    [array]$advNew = @()
    [string]$advPath = ""
    [string]$advFileName = ""
    $allAdvisories = @($shMessages | Sort-Object lastModifiedDateTime -Descending)
    #Get previously downloaded messages
    $advFileName = "Advisories-$($rptProfile).csv"
    $advPath = "$($pathWorking)\$($advFileName)"
    if (Test-Path $advPath) {
        $advExisting = Import-Csv $advPath
    }
    $advNew = @($allAdvisories | Where-Object { ($_.id -notin $advExisting.id) })
    if ($advNew.count -gt 0) {
        Write-Log "Adding $($advNew.count) new advisories to local file"
        foreach ($message in $advNew) {
            # Build new exportable list
            $dtmStartTime = $null
            $dtmLastUpdatedTime = $null
            $dtmEndTime = $null
            $dtmActionByDateTime = $null

            if ($null -ne $message.StartDateTime) { $dtmStartTime = $(Get-Date $message.StartDateTime -f 'dd-MMM-yyyy HH:mm') } 
            if ($null -ne $message.LastModifiedDateTime) { $dtmLastUpdatedTime = $(Get-Date $message.LastModifiedDateTime -f 'dd-MMM-yyyy HH:mm') } 
            if ($null -ne $message.EndDateTime) { $dtmEndTime = $(Get-Date $message.EndDateTime -f 'dd-MMM-yyyy HH:mm') } 
            if ($null -ne $message.actionRequiredByDateTime) { $dtmActionByDateTime = $(Get-Date $message.actionRequiredByDateTime -f 'dd-MMM-yyyy HH:mm') } 

            $advTemp = New-Object PSObject
            $advTemp | Add-Member -MemberType NoteProperty -Name StartTime -Value $($dtmStartTime)
            $advTemp | Add-Member -MemberType NoteProperty -Name EndTime -Value $($dtmEndTime)
            $advTemp | Add-Member -MemberType NoteProperty -Name LastUpdatedTime -Value $($dtmLastUpdatedTime)
            $advTemp | Add-Member -MemberType NoteProperty -Name Title -Value $message.Title
            $advTemp | Add-Member -MemberType NoteProperty -Name ID -Value $message.ID
            $advTemp | Add-Member -MemberType NoteProperty -Name Category -Value $message.Category
            $advTemp | Add-Member -MemberType NoteProperty -Name Severity -Value $message.Severity
            $advTemp | Add-Member -MemberType NoteProperty -Name Tags -Value $message.tags
            $advTemp | Add-Member -MemberType NoteProperty -Name IsMajorChange -Value $message.IsMajorChange
            $advTemp | Add-Member -MemberType NoteProperty -Name ActionrequiredBy -Value $($dtmActionByDateTime)
            $advTemp | Add-Member -MemberType NoteProperty -Name Services -Value $message.Services
            $advTemp | Export-Csv -Append -Path "$($advPath)" -NoTypeInformation -Encoding UTF8
        }
    }
    Copy-Item "$($advPath)" -Destination "$($pathHTML)"


    #Start Building the Pages
    $divTwo = ""
    $divThree = ""
    $divFour = ""
    $divLast = ""

    #Build Div1
    #Build Summary Dashboard
    # 6 cards
    $rptSectionOneOne = "<div class='section'><div class='header'>Office 365 Dashboard Status</div>`n"
    $rptSectionOneOne += "<div class='content'>`n"
    $rptSectionOneOne += "<div class='dash-outer'><div class='dash-inner'>`n"
    $card = $null
    foreach ($card in $dashCards) {
        [array]$item = @()
        [array]$hist = @()
        [int]$advisories = 0
        $cardClass = $null
        $cardText = $null
        $item = $shOverview | Where-Object { $_.service -like $card }
        $hist = $shIssues | Where-Object { $_.service -like $card -and ($_.status -notlike 'False Positive') } | Sort-Object EndDateTime -Descending
        $advisories = ($shMessages | Where-Object { ($_.services -like $card) }).count
        if ($hist.count -gt 0) {
            $days = "{0:N0}" -f (New-TimeSpan -Start (Get-Date $hist[0].EndDateTime) -End $(Get-Date)).TotalDays
        }
        else {
            $days = "&gt;30"
        }
        try { $cardClass = Get-StatusDisplay $($item.status) "Class" }
        catch { Write-Log "No status available for $card - $($item.service)" }
        try { $cardText = cardbuilder $($item.service) $($Days) $($Hist.count) $advisories $cardClass }
        catch { Write-Log "Cant find $card in workload. Has name changed or workload replaced?" }
        $rptSectionOneOne += "$cardText`n"
    }
    $rptSectionOneOne += "</div></div>`n" #Close inner and outer divs

    #Get Current Status and Issues for non operational services
    [array]$CurrentStatusBad = $shOverview | Where-Object { $_.status -notlike 'ServiceOperational' }
    [array]$rptSummaryTable = @()
    $rptSummaryTable = "<br/><br/><div class='dash-outer'><div class='dash-inner'>`n"
    if ($CurrentStatusBad.count -ge 1) {
        $rptSummaryTable += "<div class='tableWrkld'>`r`n"
        $rptSummaryTable += "<div class='tableWrkld-title'>The following services are reporting service issues</div>`r`n"
        $rptSummaryTable += "<div class='tableWrkld-header'>`n`t<div class='tableWrkld-header-r'>Systems</div>`n`t<div class='tableWrkld-header-c'>Status</div>`n`t<div class='tableWrkld-header-l'>Status at $(Get-Date -Format 'HH:mm')</div>`n</div>`n"
        foreach ($item in $CurrentStatusBad) {
            $statusIcon = $null
            $statusDesc = $null
            $statusIcon = Get-StatusDisplay $($item.status) "Icon"
            if ($showKISS) { $statusDesc = Get-StatusDisplay $($item.status) "kissDescription" } else { $statusDesc = Get-StatusDisplay $($item.status) "Description" }
            $rptSummaryTable += "<div class='tableWrkld-row'>`n`t<div class='tableWrkld-cell-r'>$($item.service)</div>`n`t<div class='tableWrkld-cell-c'>$StatusIcon</div>`n`t<div class='tableWrkld-cell-l'>$statusDesc</div>`n</div>"
        }
    }
    else {
        $rptSummaryTable += "<div class='tableWrkld'>`r`n"
        if ($authErrMsg) { $rptSummaryTable += "<div class='tableWrkld-title'>$authErrMsg</div>`r`n" }
        else { $rptSummaryTable += "<div class='tableWrkld-title'>No current or recent issues to display</div>`r`n" }
    }
    #Close table Workld div
    $rptSummaryTable += "</div>`n"
    #Close div and content div
    $rptSummaryTable += "</div></div>`n"
    $rptSectionOneOne += $rptSummaryTable
    $rptSectionOneOne += "</div></div>`n" #Close content and section

    $divOne = $rptSectionOneOne
    if (!($showKISS)) {
        #Get current and recent incidents
        $rptSectionOneTwo = "<div class='section'><div class='header'>Active and Recent Incidents</div>`n"
        $rptSectionOneTwo += "<div class='content'>`n"

        [array]$openIssues = @()
        [array]$rptActiveTable = @()
        $openIssues = $shIssues | Where-Object { ($_.EndDateTime -eq $null) } | Sort-Object LastModifiedDateTime -Descending
        $rptActiveTable += "<div class='tableInc'>`n"
        $rptActiveTable += "<div class='tableInc-title'>Active Messages</div>`n"
        if ($openIssues.count -ge 1) {
            foreach ($item in $openIssues) {
                $rptOutage = $true
                $LastUpdated = $(Get-Date $item.lastModifiedDateTime -f 'dd-MMM-yyyy HH:mm')
                $statusDesc = Get-StatusDisplay $($item.status) "Description"
                $link = Get-IncidentInHTML $item $RebuildDocs $pathHTMLDocs
                if ($link) {
                    $ID = "<a href=$($link) target=_blank>[$($item.ID)] $($item.ImpactDescription)</a>"
                }
                else { $ID = "[$($item.ID)] $($item.ImpactDescription)" }
                $rptActiveTable += "<div class='tableInc-row'><div class='tableInc-cell-l'>$($item.service)</div>`r`n<div class='tableInc-cell-r' $($actionStyle)>$($item.highImpact)</div>`r`n<div class='tableInc-cell-r'>$statusDesc</div>`r`n<div class='tableInc-cell-r'>Last Update: $($LastUpdated)</div>`r`n<div class='tableInc-cell-l'>$($ID)</div>`r`n</div>`r`n"
            }
        }
        else {
            $rptActiveTable += "<div class='tableInc-header'><span class='tableInc-header-c'>No open incidents to display</span></div>`n"
        }
        $rptActiveTable += "</div><br/>`n"

        #Show recently closed messages
        #create a timespan for recently closed messages - 3 to include weekends
        $recentDate = (Get-Date).AddDays(-$IncidentDays)
        [array]$recentIssues = @()
        $recentIssues = $shIssues | Where-Object { ($_.EndDateTime -ne $null -and ((Get-Date $_.EndDateTime) -ge (Get-Date $recentdate))) } | Sort-Object LastModifiedDateTime -Descending
        if ($recentIssues.count -ge 1) {
            $rptActiveTable += "<div class='tableInc'>`n"
            $rptActiveTable += "<div class='tableInc-title'>Incidents closed in the last $($incidentdays*24) hours (since $(Get-Date $recentDate -f 'dd-MMM-yyyy HH:mm'))</div>`n"
            foreach ($item in $recentIssues) {
                $rptOutage = $true
                $EndTime = $(Get-Date $item.EnddateTime -f 'dd-MMM-yyyy HH:mm')
                $statusDesc = Get-StatusDisplay $($item.status) "shortDescription"
                $link = Get-IncidentInHTML $item $RebuildDocs $pathHTMLDocs
                if ($link) {
                    $ID = "<a href=$($link) target=_blank>[$($item.ID)] $($item.ImpactDescription)</a>"
                }
                else { $ID = "[$($item.ID)] $($item.ImpactDescription)" }
                $rptActiveTable += "<div class='tableInc-row'><div class='tableInc-cell-l'>$($item.service)</div>`r`n<div class='tableInc-cell-r' $($actionStyle)>$($item.highimpact)</div>`r`n<div class='tableInc-cell-r'>$statusDesc</div>`r`n<div class='tableInc-cell-r'>Closed: $($EndTime)</div>`r`n<div class='tableInc-cell-l'>$($ID)</div>`r`n</div>`r`n"
            }
            $rptActiveTable += "</div>`n"
        }
        else {
            $rptActiveTable += "<div class='tableInc'>`n"
            $rptActiveTable += "<div class='tableInc-header'><span class='tableInc-header-c'>No recent incidents to display</span></div>`n"
            $rptActiveTable += "</div>`n"
        }
        $rptSectionOneTwo += $rptActiveTable
        $rptSectionOneTwo += "</div></div>`r`n" #Close content and section
        $divOne += $rptSectionOneTwo

        #Get new messages in past X days (ie for change board to triage/discuss)

        if ($intRecentMess -ge 1) {
            $rptSectionOneThree = "<div class='section'><div class='header'>Updated messages in the past $($intRecentMess) days</div>`n"
            $rptSectionOneThree += "<div class='content'>`n"
            $dtmRecentMess = (get-date).AddDays(-$intRecentMess)
            #Messages
            [array]$MsgRecent = @()
            [array]$rptMsgRecentTable = @()
            $MsgRecent = $shMessages | Where-Object { (get-date $_.lastModifiedDateTime) -ge (get-date $dtmRecentMess) } | Sort-Object LastModifiedDateTime -Descending
            if ($MsgRecent.count -ge 1) {
                $rptMsgRecentTable += "<div class='tableInc'>`n"
                $rptMsgRecentTable += "<div class='tableInc-header'>`n`t<div class='tableInc-header-dt'>Feature</div>`n`t<div class='tableInc-header-dt'>Severity</div>`n`t<div class='tableInc-header-dt'>Category</div>`n`t<div class='tableInc-header-dt'>ID</div>`n`t<div class='tableInc-header-l'>Title</div>`n`t<div class='tableInc-header-dt'>Updated</div>`n`t<div class='tableInc-header-dt'>Action Rqd By</div>`n</div>`n"
                foreach ($item in $MsgRecent) {
                    if ($item.LastModifiedDateTime) { $LastUpdated = $(Get-Date $item.lastModifiedDateTime -f 'dd-MMM-yyyy HH:mm') }
                    $Workloads = @()
                    $itemCategory = $null
                    $Workloads = $item | Select-Object -ExpandProperty Services
                    if (!($Workloads)) { $Workloads = "General" }
                    $workloads = $workloads -join "</br>"
                    $itemCategory = Get-StatusDisplay $($item.category) "Category"
                    $rptMsgRecentTable += "<div class='tableInc-row'>`n`t"
                    $rptMsgRecentTable += "<div class='tableInc-cell-dt'>$($Workloads)</div>`n`t"
                    $rptMsgRecentTable += "<div class='tableInc-cell-dt'>$($item.Severity)</div>`n`t"
                    $rptMsgRecentTable += "<div class='tableInc-cell-dt'>$($itemCategory)</div>`n`t"
                    #Build advisory and get link
                    $link = Get-AdvisoryInHTML $item $RebuildDocs $pathHTMLDocs
                    $rptMsgRecentTable += "<div class='tableInc-cell-dt'>$($item.ID)</div>`n`t"
                    if ($link) { $rptMsgRecentTable += "<div class='tableInc-cell-l'><a href='$($link)' target='_blank'>$($item.title)</a></div>`n`t" }
                    else { $rptMsgRecentTable += "<div class='tableInc-cell-l'>$($item.title)</div>`n`t" }
                    $rptMsgRecentTable += "<div class='tableInc-cell-dt'>$($LastUpdated)</div>`n`t"
                    if ($item.ActionRequiredByDateTime) {
                        $ActionRequiredByDate = $(Get-Date $item.ActionRequiredByDateTime -f 'dd-MMM-yyyy HH:mm')
                        $action = (New-TimeSpan -Start $(Get-Date) -End (Get-Date $item.ActionRequiredByDateTime)).TotalDays
                        switch ($action) {
                            { $_ -ge 0 -and $_ -lt 7 } { $actionStyle = "style=border:none;font-weight:bold;color:red" }
                            { $_ -ge 7 -and $_ -lt 14 } { $actionStyle = "style=border:none;color:red" }
                            { $_ -ge 14 -and $_ -lt 21 } { $actionStyle = "style=border:none;color:blue" }
                            default { $actionStyle = "style=border:none;" }
                        }
                    }
                    $rptMsgRecentTable += "<div class='tableInc-cell-dt'>$($ActionRequiredByDate)</div>`n"
                    $rptMsgRecentTable += "</div>`n"
                }
            }
            else {
                $rptMsgRecentTable = "<div class='tableInc'>`n"
                $rptMsgRecentTable += "<div class='tableInc-title'>No Recent Messages</div>`n"
            }
            $rptMsgRecentTable += "</div>`n"
            $rptSectionOneThree += $rptMsgRecentTable
            $rptSectionOneThree += "</div></div>`n"
            $divOne += $rptSectionOneThree
        }
    }
    #Get All workload status
    [array]$rptWorkloadStatusTable = @()
    $rptSectionOneFour = "<div class='section'><div class='header'>Workload Status</div>`n"
    $rptSectionOneFour += "<div class='content'>`n"
    $shHealthOverview = $shOverview | Sort-Object service
    $rptWorkloadStatusTable = "<br/><div class='dash-outer'><div class='dash-inner'>`n"
    if ($shHealthOverview.count -ge 1) {
        $rptWorkloadStatusTable += "<div class='tableWrkld'>`r`n"
        $rptWorkloadStatusTable += "<div class='tableWrkld-title'>All workload status</div>`r`n"
        $rptWorkloadStatusTable += "<div class='tableWrkld-header'>`n`t<div class='tableWrkld-header-r'>Systems</div>`n`t<div class='tableWrkld-header-c'>Status</div>`n`t<div class='tableWrkld-header-l'>Status at $(Get-Date -Format 'HH:mm')</div>`n</div>`n"

        foreach ($item in $shHealthOverview) {
            $statusIcon = Get-StatusDisplay $($item.status) "Icon"
            if ($showKISS) { $statusDesc = Get-StatusDisplay $($item.status) "kissDescription" } else { $statusDesc = Get-StatusDisplay $($item.status) "Description" }
            $rptWorkloadStatusTable += "<div class='tableWrkld-row'>`n`t<div class='tableWrkld-cell-r'>$($item.service)</div>`n`t<div class='tableWrkld-cell-c'>$StatusIcon</div>`n`t<div class='tableWrkld-cell-l'>$($statusDesc)</div>`n</div>"
        }
    }
    else {
        $rptWorkloadStatusTable += "<div class='tableWrkld'>`r`n"
        $rptWorkloadStatusTable += "<div class='tableWrkld-title'>No current or recent issues to display</div>`r`n"
    }
    $rptWorkloadStatusTable += "</div></div></div>`n"
    $rptSectionOneFour += $rptWorkloadStatusTable
    $rptSectionOneFour += "</div></div>`r`n" #Close content and section
    $divOne += $rptSectionOneFour

    if ($showInc) {
        #Build Div2
        $rptSectionTwoOne = "<div class='section'><div class='header'>Service Health notes</div>`n"
        $rptSectionTwoOne += "<div class='content'>`n"
        $rptSectionTwoOne += "<b>Microsoft definitions of 'Incident' and 'Advisory'</b></br>`n"
        $rptSectionTwoOne += "An incident is a critical service issue, typically involving noticable user impact.</br>`n"
        $rptSectionTwoOne += "An advisory is a service issue that is typically limited in scope or impact.</br>`n"
        $rptSectionTwoOne += "</br>Microsoft Severity ranges are typically Sev 0 (Critical), Sev 1 (Error) and Sev2 (Warning)</br>`n"

        $rptSectionTwoOne += "</div></div>`n"
        $divTwo = $rptSectionTwoOne

        $rptSectionTwoTwo = "<div class='section'><div class='header'>Office 365 Open Incidents</div>`n"
        $rptSectionTwoTwo += "<div class='content'>`n"

        #Incident History
        #Get all open Incidents
        $rptIncidentTable = @()
        $item = $null

        if ($openIssues.count -ge 1) {
            $rptIncidentTable += "<div class='tableInc'>`n"
            $rptIncidentTable += "<div class='tableInc-title'>Open Incidents</div>`n"
            $rptIncidentTable += "<div class='tableInc-header'>`n`t<div class='tableInc-header-c'>Service</div>`n`t<div class='tableInc-header-c'>High Impact</div>`n`t<div class='tableInc-header-c'>Status</div>`n`t<div class='tableInc-header-c'>Description</div>`n`t<div class='tableInc-header-c'>Start Time</div>`n`t<div class='tableInc-header-c'>Last Updated</div>`n</div>`n"
    
    
            foreach ($item in $openIssues) {
                if ($item.startDateTime) { $StartTime = $(Get-Date $item.startDateTime -f 'dd-MMM-yyyy HH:mm') } else { $StartTime = "" }
                if ($item.lastModifiedDateTime) { $LastUpdated = $(Get-Date $item.lastModifiedDateTime -f 'dd-MMM-yyyy HH:mm') } else { $LastUpdated = "" }
                $statusDesc = Get-StatusDisplay $($item.status) "Description"
                $link = ""
                #Build link to detailed message
                $link = Get-IncidentInHTML $item $RebuildDocs $pathHTMLDocs
                if ($link) {
                    $ID = "<a href=$($link) target=_blank>$($item.ID) - $($item.ImpactDescription)</a>"
                }
                else { $ID = "$($item.ID) - $($item.ImpactDescription)" }
                $rptIncidentTable += "<div class='tableInc-row'>`n`t"
                $rptIncidentTable += "<div class='tableInc-cell-l'>$($item.service -join '<br>')</div>`n`t"
                $rptIncidentTable += "<div class='tableInc-cell-r' $($actionStyle)>$($item.highImpact)</div>`n`t"
                $rptIncidentTable += "<div class='tableInc-cell-l'>$($statusDesc)</div>`n`t"
                $rptIncidentTable += "<div class='tableInc-cell-l'>$($ID)</div>`n`t"
                $rptIncidentTable += "<div class='tableInc-cell-dt' $($tdStyle2)>$($StartTime)</div>`n`t"
                $rptIncidentTable += "<div class='tableInc-cell-dt' $($tdStyle2)>$($LastUpdated)</div>`n"
                $rptIncidentTable += "</div>`n"
            }
        }
        else {
            $rptIncidentTable = "<div class='tableInc'>`n"
            $rptIncidentTable += "<div class='tableInc-title'>No Open Incidents</div>`n"
        }
        $rptIncidentTable += "</div>`n"
        $rptSectionTwoTwo += $rptIncidentTable
        $rptSectionTwoTwo += "</div></div>`n"
        $divTwo += $rptSectionTwoTwo


        $rptSectionTwoThree = "<div class='section'><div class='header'>Office 365 Closed Incidents</div>`n"
        $rptSectionTwoThree += "<div class='content'>`n"

        #Get Incident History
        [array]$HistoryIncidents = @()
        $rptIncidentTable = @()

        $item = $null
        $HistoryIncidents = $shIssues | Where-Object { ($_.EndDateTime -ne $null) } | Sort-Object EndDateTime -Descending
        if ($HistoryIncidents.count -ge 1) {
            $rptIncidentTable += "<div class='tableInc'>`n"
            $rptIncidentTable += "<div class='tableInc-title'>Closed Incidents</div>`n"
            $rptIncidentTable += "<div class='tableInc-header'>`n`t<div class='tableInc-header-c'>Service</div>`n`t<div class='tableInc-header-c'>PIR/Status</div>`n`t<div class='tableInc-header-c'>Description</div>`n`t<div class='tableInc-header-c'>Start Time</div>`n`t<div class='tableInc-header-c'>End Time</div>`n`t<div class='tableInc-header-c'>Last Updated</div>`n</div>`n"
            foreach ($item in $HistoryIncidents) {
                if ($item.StartDateTime) { $StartTime = $(Get-Date $item.StartDateTime -f 'dd-MMM-yyyy HH:mm') } else { $StartTime = "" }
                if ($item.EndDateTime) { $EndTime = $(Get-Date $item.EndDateTime -f 'dd-MMM-yyyy HH:mm') } else { $EndTime = "" }
                if ($item.LastModifiedDateTime) { $LastUpdated = $(Get-Date $item.LastModifiedDateTime -f 'dd-MMM-yyyy HH:mm') } else { $LastUpdated = "" }
                $statusDesc = Get-StatusDisplay $($item.status) "shortDescription"
                if ($item.status -in ("ServiceRestored", "Resolved")) { $statusDesc = "" }
                if ($item.status -like "PostIncidentReviewPublished") {
                    $PIRlink = Get-IncidentPIR $pathHTMLDocs $item.id $authGHeader $proxyServer $proxyHost
                    $statusDesc = "<a href='$($pirlink)' target=_blank>Download PIR here</a>"
                }
                $link = ""
                #Build link to detailed message
                $link = Get-IncidentInHTML $item $RebuildDocs $pathHTMLDocs
                if ($link) {
                    $ID = "<a href=$($link) target=_blank>$($item.ID) - $($item.ImpactDescription)</a>"
                }
                else { $ID = "$($item.ID) - $($item.ImpactDescription)" }
                $rptIncidentTable += "<div class='tableInc-row'>`n`t"
                $rptIncidentTable += "<div class='tableInc-cell-l'>$($item.service -join '<br>')</div>`n`t"
                $rptIncidentTable += "<div class='tableInc-cell-l'>$($StatusDesc)</div>`n`t"
                $rptIncidentTable += "<div class='tableInc-cell-l'>$($ID)</div>`n`t"
                $rptIncidentTable += "<div class='tableInc-cell-dt' $($tdStyle2)>$($StartTime)</div>`n`t"
                $rptIncidentTable += "<div class='tableInc-cell-dt' $($tdStyle2)>$($EndTime)</div>`n`t"
                $rptIncidentTable += "<div class='tableInc-cell-dt' $($tdStyle2)>$($LastUpdated)</div>`n"
                $rptIncidentTable += "</div>`n"
            }
        }
        else {
            $rptIncidentTable += "<div class='tableInc'>`n"
            $rptIncidentTable += "<div class='tableInc-title'>No Closed Incidents</div>`n"
        }
        $rptIncidentTable += "</div>`n"
        $rptSectionTwoThree += $rptIncidentTable
        $rptSectionTwoThree += "</div></div>`n"

        $divTwo += $rptSectionTwoThree
    }
    if ($showMsgs) {
        #Build Div3

        $rptSectionThreeOne = "<div class='section'>"
        $rptSectionThreeOne += "<div class='tableinc-cell-r'>Download all items <a href='$($advFileName)' target='_blank'>here</a></div>"
        $rptSectionThreeOne += "<div class='header'>Prevent / Fix Issues</div>`n"
        $rptSectionThreeOne += "<div class='content'>`n"
        #Messages
        #Prevent or fix issues
        [array]$MessagesFix = @()
        [string]$rptBuildSection = $null

        $MessagesFix = $shMessages | Where-Object { ($_.category -like 'preventOrFixIssue') } | Sort-Object lastModifiedDateTime -Descending
        $rptBuildSection = "<div class='tableInc'>`n"

        if ($MessagesFix.count -ge 1) {
            #    $rptBuildSection += "<div class='tableInc-header'>`n`t<div class='tableInc-header-dt'>Service</div>`n`t<div class='tableInc-header-dt'>Tags</div>`n`t<div class='tableInc-header-dt'>Severity</div>`n`t<div class='tableInc-header-dt'>Major Change</div>`n`t<div class='tableInc-header-dt'>ID</div>`n`t<div class='tableInc-header-l'>Title</div>`n`t<div class='tableInc-header-dt'>Updated</div>`n<div class='tableInc-header-dt'>Action Rqd By</div>`n</div>`n"
            $rptBuildSection += "<div class='tableInc-header'>`n`t<div class='tableInc-header-dt'>Service</div>`n`t<div class='tableInc-header-dt'>Severity</div>`n`t<div class='tableInc-header-dt'>Major Change</div>`n`t<div class='tableInc-header-dt'>ID</div>`n`t<div class='tableInc-header-l'>Title</div>`n`t<div class='tableInc-header-dt'>Updated</div>`n<div class='tableInc-header-dt'>Action Rqd By</div>`n</div>`n"
            foreach ($item in $MessagesFix) {
                $ActionRequiredByDate = $null
                $LastUpdated = $null
                $addText = ""
                $pubWindow = $null
                if ($item.actionRequiredByDateTime) { $ActionRequiredByDate = $(Get-Date $item.actionRequiredByDateTime -f 'dd-MMM-yyyy HH:mm') }
                $LastUpdated = $(Get-Date $item.lastModifiedDateTime -f 'dd-MMM-yyyy HH:mm')

                #New text to alert that message is new (24hrs) or updated (7 days)
                $pubWindow = (New-TimeSpan -Start (Get-Date $item.lastModifiedDateTime) -End $(Get-Date)).TotalDays
                if ($pubWindow -le 7) { $addtext = "*Updated*" }
                $pubWindow = (New-TimeSpan -Start (Get-Date $item.startDateTime)  -End $(Get-Date)).TotalHours
                if ($pubWindow -le 48) { $addtext = "**New**" }

                $Workloads = @()
                $Workloads = $item | Select-Object -ExpandProperty services
                if (!($Workloads)) { $Workloads = "General" }
                $workloads = $workloads -join "</br>"
                $tags = @()
                $tags = $item | Select-Object -ExpandProperty tags
                if (!($tags)) { $tags = "General" }
                $tags = $tags -join "</br>"
                $rptBuildSection += "<div class='tableInc-row'>`n`t"
                $rptBuildSection += "<div class='tableInc-cell-dt'>$($Workloads)</div>`n`t"
                #        $rptBuildSection += "<div class='tableInc-cell-dt'>$($tags)</div>`n`t"
                $rptBuildSection += "<div class='tableInc-cell-dt'>$($item.Severity)</div>`n`t"
                $rptBuildSection += "<div class='tableInc-cell-dt'>$($item.isMajorChange)</div>`n`t"
                $link = Get-AdvisoryInHTML $item $RebuildDocs $pathHTMLDocs
                $rptBuildSection += "<div class='tableInc-cell-dt'>$($item.ID)&nbsp$($addText)</div>`n`t"
                if ($link) { $rptBuildSection += "<div class='tableInc-cell-l'><a href='$($link)' target='_blank'>$($item.title)</a></div>`n`t" }
                else { $rptBuildSection += "<div class='tableInc-cell-l'>$($item.title)</div>`n`t" }
                $rptBuildSection += "<div class='tableInc-cell-dt'>$($LastUpdated)</div>`n`t"
                $rptBuildSection += "<div class='tableInc-cell-dt'>$($ActionRequiredByDate)</div>`n"
                $rptBuildSection += "</div>`n"
            }
        }
        else {
            $rptBuildSection = "<div class='tableInc'>`n"
            $rptBuildSection += "<div class='tableInc-title'>No Plan for Change Messages</div>`n"
        }
        $rptBuildSection += "</div>`n"
        $rptSectionThreeOne += $rptBuildSection
        $rptSectionThreeOne += "</div></div>`n"
        $divThree = $rptSectionThreeOne

        $rptSectionThreeTwo = "<div class='section'><div class='header'>Plan for Change</div>`n"
        $rptSectionThreeTwo += "<div class='content'>`n"

        #Plan for change Message center messages
        [array]$MessagesPFC = @()
        [string]$addText = ""
        [string]$rptBuildSection = $null

        #Some PFC articles have no milestone.
        $rptBuildSection = "<div class='tableInc'>`n"

        $MessagesPFC = $shMessages | Where-Object { ($_.category -like 'planForChange') } | Sort-Object lastModifiedDateTime -Descending
        if ($MessagesPFC.count -ge 1) {
            $rptBuildSection += "<div class='tableInc-header'>`n`t<div class='tableInc-header-dt'>Service</div>`n`t<div class='tableInc-header-dt'>Severity</div>`n`t<div class='tableInc-header-dt'>Major Change</div>`n`t<div class='tableInc-header-dt'>ID</div>`n`t<div class='tableInc-header-l'>Title</div>`n`t<div class='tableInc-header-dt'>Updated</div>`n<div class='tableInc-header-dt'>Action Rqd By</div>`n</div>`n"
            foreach ($item in $MessagesPFC) {
                $ActionRequiredByDate = $null
                $LastUpdated = $null
                $addText = ""
                $pubWindow = $null
                if ($item.actionRequiredByDateTime) { $ActionRequiredByDate = $(Get-Date $item.actionRequiredByDateTime -f 'dd-MMM-yyyy HH:mm') }
                $LastUpdated = $(Get-Date $item.lastModifiedDateTime -f 'dd-MMM-yyyy HH:mm')

                #New text to alert that message is new (24hrs) or updated (7 days)
                $pubWindow = (New-TimeSpan -Start (Get-Date $item.lastModifiedDateTime) -End $(Get-Date)).TotalDays
                if ($pubWindow -le 7) { $addtext = "*Updated*" }
                $pubWindow = (New-TimeSpan -Start (Get-Date $item.startDateTime)  -End $(Get-Date)).TotalHours
                if ($pubWindow -le 48) { $addtext = "**New**" }

                $Workloads = @()
                $Workloads = $item | Select-Object -ExpandProperty services
                if (!($Workloads)) { $Workloads = "General" }
                $workloads = $workloads -join "</br>"
                $tags = @()
                $tags = $item | Select-Object -ExpandProperty tags
                if (!($tags)) { $tags = "General" }
                $tags = $tags -join "</br>"
                $rptBuildSection += "<div class='tableInc-row'>`n`t"
                $rptBuildSection += "<div class='tableInc-cell-dt'>$($Workloads)</div>`n`t"
                #        $rptBuildSection += "<div class='tableInc-cell-dt'>$($tags)</div>`n`t"
                $rptBuildSection += "<div class='tableInc-cell-dt'>$($item.Severity)</div>`n`t"
                $rptBuildSection += "<div class='tableInc-cell-dt'>$($item.isMajorChange)</div>`n`t"
                $link = Get-AdvisoryInHTML $item $RebuildDocs $pathHTMLDocs
                $rptBuildSection += "<div class='tableInc-cell-dt'>$($item.ID)&nbsp$($addText)</div>`n`t"
                if ($link) { $rptBuildSection += "<div class='tableInc-cell-l'><a href='$($link)' target='_blank'>$($item.title)</a></div>`n`t" }
                else { $rptBuildSection += "<div class='tableInc-cell-l'>$($item.title)</div>`n`t" }
                $rptBuildSection += "<div class='tableInc-cell-dt'>$($LastUpdated)</div>`n`t"
                $rptBuildSection += "<div class='tableInc-cell-dt'>$($ActionRequiredByDate)</div>`n"
                $rptBuildSection += "</div>`n"
            }
        }
        else {
            $rptBuildSection = "<div class='tableInc'>`n"
            $rptBuildSection += "<div class='tableInc-title'>No Plan for Change Messages</div>`n"
        }
        $rptBuildSection += "</div>`n"

        $rptSectionThreeTwo += $rptBuildSection
        $rptSectionThreeTwo += "</div></div>`n"
        $divThree += $rptSectionThreeTwo

        $rptSectionThreeThree = "<div class='section'><div class='header'>Stay Informed</div>`n"
        $rptSectionThreeThree += "<div class='content'>`n"

        #Remaining message center messages
        [string]$rptBuildSection = $null

        $messageStayInformed = $shMessages | Where-Object { ($_.category -notlike 'planForChange' -and $_.category -notlike 'preventOrFixIssue') } | Sort-Object lastModifiedDateTime -Descending
        $rptBuildSection = "<div class='tableInc'>`n"
        if ($messageStayInformed.count -ge 1) {
            $rptBuildSection += "<div class='tableInc-header'>`n`t<div class='tableInc-header-dt'>Service</div>`n`t<div class='tableInc-header-dt'>Severity</div>`n`t<div class='tableInc-header-dt'>Major Change</div>`n`t<div class='tableInc-header-dt'>ID</div>`n`t<div class='tableInc-header-l'>Title</div>`n`t<div class='tableInc-header-dt'>Updated</div>`n<div class='tableInc-header-dt'>Action Rqd By</div>`n</div>`n"
            foreach ($item in $messageStayInformed) {
                $ActionRequiredByDate = $null
                $LastUpdated = $null
                $addText = ""
                $pubWindow = $null
                if ($item.actionRequiredByDateTime) { $ActionRequiredByDate = $(Get-Date $item.actionRequiredByDateTime -f 'dd-MMM-yyyy HH:mm') }
                $LastUpdated = $(Get-Date $item.lastModifiedDateTime -f 'dd-MMM-yyyy HH:mm')

                #New text to alert that message is new (24hrs) or updated (7 days)
                $pubWindow = (New-TimeSpan -Start (Get-Date $item.lastModifiedDateTime) -End $(Get-Date)).TotalDays
                if ($pubWindow -le 7) { $addtext = "*Updated*" }
                $pubWindow = (New-TimeSpan -Start (Get-Date $item.startDateTime)  -End $(Get-Date)).TotalHours
                if ($pubWindow -le 48) { $addtext = "**New**" }

                $Workloads = @()
                $Workloads = $item | Select-Object -ExpandProperty services
                if (!($Workloads)) { $Workloads = "General" }
                $workloads = $workloads -join "</br>"
                $tags = @()
                $tags = $item | Select-Object -ExpandProperty tags
                if (!($tags)) { $tags = "General" }
                $tags = $tags -join "</br>"
                $rptBuildSection += "<div class='tableInc-row'>`n`t"
                $rptBuildSection += "<div class='tableInc-cell-dt'>$($Workloads)</div>`n`t"
                #        $rptBuildSection += "<div class='tableInc-cell-dt'>$($tags)</div>`n`t"
                $rptBuildSection += "<div class='tableInc-cell-dt'>$($item.Severity)</div>`n`t"
                $rptBuildSection += "<div class='tableInc-cell-dt'>$($item.isMajorChange)</div>`n`t"
                $link = Get-AdvisoryInHTML $item $RebuildDocs $pathHTMLDocs
                $rptBuildSection += "<div class='tableInc-cell-dt'>$($item.ID)&nbsp$($addText)</div>`n`t"
                if ($link) { $rptBuildSection += "<div class='tableInc-cell-l'><a href='$($link)' target='_blank'>$($item.title)</a></div>`n`t" }
                else { $rptBuildSection += "<div class='tableInc-cell-l'>$($item.title)</div>`n`t" }
                $rptBuildSection += "<div class='tableInc-cell-dt'>$($LastUpdated)</div>`n`t"
                $rptBuildSection += "<div class='tableInc-cell-dt'>$($ActionRequiredByDate)</div>`n"
                $rptBuildSection += "</div>`n"
            }
        }
        else {
            $rptBuildSection = "<div class='tableInc'>`n"
            $rptBuildSection += "<div class='tableInc-title'>No other Service Health messages</div>`n"
        }
        $rptBuildSection += "</div>`n"

        $rptSectionThreeThree += $rptBuildSection
        $rptSectionThreeThree += "</div></div>`n"
        $divThree += $rptSectionThreeThree
    }

    #Tab 5 - First RSS Feed
    if ($showRdMap) {
        $rptSectionFourOne = "<!-- First RSS Feed goes here-->"
        if ($rss1Enabled) {
            $rptSectionFourOne += "<div class='section'><div class='header'>$($rss1Name)</div>`n"
            $rptSectionFourOne += "<div class='content'>`n"
            $rptSectionFourOne += "Last $($rss1Items) items. Full roadmap can be viewed here: <a href='$($rss1URL)' target=_blank>$($rss1URL)</a><br/>`r`n"
            $rss1Data = $rss1Data.replace("ï»¿", "")
            [xml]$content = $rss1Data
            $feed = $content.rss.channel
            $feedMessages = @{ }
            $feedMessages = foreach ($msg in $feed.Item) {
                $description = $msg.description
                $description = $description -replace ("`n", '<br>')
                $description = $description -replace ([char]226, "'")
                $description = $description -replace ([char]128, "")
                $description = $description -replace ([char]153, "")
                $description = $description -replace ([char]162, "")
                $description = $description -replace ([char]194, "")
                $description = $description -replace ([char]195, "")
                $description = $description -replace ([char]8217, "'")
                $description = $description -replace ([char]8220, '"')
                $description = $description -replace ([char]8221, '"')
                $description = $description -replace ('\[', '<b><i>')
                $description = $description -replace ('\]', '</i></b>')

                [PSCustomObject]@{
                    'LastUpdated' = [datetime]$msg.updated
                    'Published'   = [datetime]$msg.pubDate
                    'Description' = $description
                    'Title'       = $msg.Title
                    'Category'    = $msg.Category
                    'Link'        = $msg.link
                }
            }

            $feedMessages = $feedmessages | Sort-Object published -Descending | Select-Object -First $rss1Items

            if ($feedMessages.count -ge 1) {
                $rptFeedTable += "<div class='tableFeed'>`n"
                $rptFeedTable += "<div class='tableFeed-title'>$($rss1Name)</div>`n"
                $rptFeedTable += "<div class='tableFeed-header'>`n`t<div class='tableFeed-header-c'>Tags</div>`n`t<div class='tableFeed-header-c'>Title</div>`n`t<div class='tableFeed-header-c'>Published</div>`n`t<div class='tableFeed-header-c'>Last Updated</div>`n</div>`n"
                foreach ($item in $feedMessages) {
                    if ($item.LastUpdated) { $LastUpdated = $(Get-Date $item.LastUpdated -f 'dd-MMM-yyyy HH:mm') } else { $StartTime = "" }
                    if ($item.Published) { $Published = $(Get-Date $item.Published -f 'dd-MMM-yyyy HH:mm') } else { $EndTime = "" }
                    $link = $item.Link
                    #Build link to detailed message
                    #$link = Get-IncidentInHTML $item $RebuildDocs $pathHTMLDocs
                    if ($item.link) {
                        $ID = "<a href=$($item.link) target=_blank>$($item.Title)</a>"
                    }
                    else { $ID = "$($item.Title)" }
                    $rptFeedTable += "<div class='tableFeed-row'>`n`t"
                    $rptFeedTable += "<div class='tableFeed-cell-cat'>$($item.Category -join ', ')</div>`n`t"
                    $rptFeedTable += "<div class='tableFeed-cell-desc'><p><div class='tableFeed-cell-title'>$($ID)</div></p>`n`t"
                    $rptFeedTable += "<div class='tableFeed-cell-desc'>$($item.description)</div></div>`n`t"
                    $rptFeedTable += "<div class='tableFeed-cell-dt' $($tdStyle2)>$($Published)</div>`n`t"
                    $rptFeedTable += "<div class='tableFeed-cell-dt' $($tdStyle2)>$($LastUpdated)</div>`n`t"
                    $rptFeedTable += "</div>`n"
                }
                #Close tablefeed
                $rptFeedTable += "</div>"
            }
            $rptSectionFourOne += $rptFeedTable
            $rptSectionFourOne += "</div></div>`n"
        }

        $divFour = $rptSectionFourOne

        $rptSectionFourTwo = "<!-- Second RSS Feed goes here-->"
        if ($rss2Enabled) {
            $rptSectionFourTwo += "<div class='section'><div class='header'>$($rss2Name)</div>`n"
            $rptSectionFourTwo += "<div class='content'>`n"

            $rptSectionFourTwo += "Last $($rss2Items) items. Full roadmap can be viewed here: <a href='$($rss2URL)' target=_blank>$($rss2URL)</a><br/>`r`n"
            $rss2Data = $rss2Data.replace("ï»¿", "")
            [xml]$content = $rss2Data
            $feed = $content.rss.channel
            $feedMessages = @{ }
            $feedMessages = foreach ($msg in $feed.Item) {
                $description = $msg.description
                $description = $description -replace ("`n", '<br>')
                $description = $description -replace ([char]226, "'")
                $description = $description -replace ([char]128, "")
                $description = $description -replace ([char]153, "")
                $description = $description -replace ([char]162, "")
                $description = $description -replace ([char]194, "")
                $description = $description -replace ([char]195, "")
                $description = $description -replace ([char]8217, "'")
                $description = $description -replace ([char]8220, '"')
                $description = $description -replace ([char]8221, '"')
                $description = $description -replace ('\[', '<b><i>')
                $description = $description -replace ('\]', '</i></b>')

                [PSCustomObject]@{
                    'Published'   = [datetime]$msg.pubDate
                    'Description' = $description
                    'Title'       = $msg.Title
                    'Category'    = $msg.Category
                    'Link'        = $msg.link
                }
            }

            $feedMessages = $feedmessages | Sort-Object published -Descending | Select-Object -First $rss2Items
            $rptFeedTable = $null
            if ($feedMessages.count -ge 1) {
                $rptFeedTable += "<div class='tableFeed'>`n"
                $rptFeedTable += "<div class='tableFeed-title'>$($rss2Name)</div>`n"
                $rptFeedTable += "<div class='tableFeed-header'>`n`t<div class='tableFeed-header-c'>Tags</div>`n`t<div class='tableFeed-header-c'>Title</div>`n`t<div class='tableFeed-header-c'>Published</div>`n`t</div>`n"
                foreach ($item in $feedMessages) {
                    if ($item.Published) { $Published = $(Get-Date $item.Published -f 'dd-MMM-yyyy HH:mm') } else { $EndTime = "" }
                    $link = $item.Link
                    #Build link to detailed message
                    #$link = Get-IncidentInHTML $item $RebuildDocs $pathHTMLDocs
                    if ($item.link) {
                        $ID = "<a href=$($item.link) target=_blank>$($item.Title)</a>"
                    }
                    else { $ID = "$($item.Title)" }
                    $rptFeedTable += "<div class='tableFeed-row'>`n`t"
                    $rptFeedTable += "<div class='tableFeed-cell-cat'>$($item.Category -join ' | ')</div>`n`t"
                    $rptFeedTable += "<div class='tableFeed-cell-desc'><p><div class='tableFeed-cell-title'>$($ID)</div></p>`n`t"
                    $rptFeedTable += "<div class='tableFeed-cell-desc'>$($item.description)</div></div>`n`t"
                    $rptFeedTable += "<div class='tableFeed-cell-dt' $($tdStyle2)>$($Published)</div>`n`t"
                    $rptFeedTable += "</div>`n"
                }
                #Close tablefeed
                $rptFeedTable += "</div>"
            }

            $rptSectionFourTwo += $rptFeedTable
            $rptSectionFourTwo += "</div></div>`n"
        }
        $divFour += $rptSectionFourTwo

        $rptSectionFourThree = "<div class='section'><div class='header'>Useful Blogs</div>`n"
        $rptSectionFourThree += "<div class='content'>`n"
        $rptSectionFourThree += "$($Blogs)"
        $rptSectionFourThree += "</div></div>`n"

        $divFour += $rptSectionFourThree
    }

    if ($showLog) {
        #Tab Last - Logs / Additional info
        $rptSectionLastOne = "<div class='section'><div class='header'>Information</div>`n"
        $rptSectionLastOne += "<div class='content'>`n"
        $rptSectionLastOne += $rptM365Info
        $rptSectionLastOne += "</div></div>`n"

        $divLast = $rptSectionLastOne

        $rptSectionLastTwo = "<div class='section'><div class='header'>Script Runtime</div>`n"
        $rptSectionLastTwo += "<div class='content'>`n"

        [string]$strTime = "$($swScript.Elapsed.Minutes)m:$($swScript.Elapsed.Seconds)s:$($swScript.Elapsed.Milliseconds)ms"
        $rptSectionLastTwo += "Elapsed runtime $strTime"
        $rptSectionLastTwo += "</div></div>`n"
        $divLast += $rptSectionLastTwo
    }

    $rptHTMLName = $HTMLFile.Replace(" ", "")
    $rptTitle = $rptTenantName + " " + $rptName
    if ($rptOutage) { $rptTitle += " Outage detected" }
    $evtMessage = "[$(Get-Date -f 'dd-MMM-yy HH:mm:ss')] Tenant: $($rptProfile) - Generating HTML to '$($pathHTML)\$($rptHTMLName)'`r`n"
    $evtLogMessage += $evtMessage
    Write-Verbose $evtMessage

    BuildHTML $rptTitle $divOne $divTwo $divThree $divFour $divLast $rptHTMLName
    #Check if .css file exists in HTML file destination
    if (!(Test-Path "$($pathHTML)\$($cssfile)")) {
        Write-Log "Copying M365Health.css to directory $($pathHTML)"
        Copy-Item "..\common\M365Health.css" -Destination "$($pathHTML)"
        #No CSS file so probably no images
        Copy-Item ".\images\*.jpg" -Destination "$($pathHTMLimg)"
    }

    $swScript.Stop()

    $evtMessage = "Tenant: $($rptProfile) - Script runtime $($swScript.Elapsed.Minutes)m:$($swScript.Elapsed.Seconds)s:$($swScript.Elapsed.Milliseconds)ms on $env:COMPUTERNAME`r`n"
    $evtMessage += "*** Processing finished ***`r`n"
    Write-Log $evtMessage
    #Re-instate default proxy
    [System.Net.GlobalProxySelection]::Select = $defaultProxy

    #Append to daily log file.
    Get-Content $script:logfile | Add-Content $script:Dailylogfile
    Remove-Item $script:logfile
}
Remove-Module M365ServiceHealth
