﻿<#
//***********************************************************************
//
// Copyright (c) 2018 Microsoft Corporation. All rights reserved.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
//
//**********************************************************************​
#>

<#
.SYNOPSIS
    Gets the Microsoft 365 Health Center messages and incidents
    Displays on several tabs with the summary providing a dashbord overview
    Keeping It SimpleS

.DESCRIPTION
    This script is designed to run on a scheduled basis.
    It requires and Azure AD Application for your tenant.
    The script will build an HTML page displaying information and links to tenant messages and articles.
    Several tenants configurations can be held.
    Microsoft 365 service health incidents generate email alerts as well as logging to the event log.
    Alternative links can be added (ie to an external dashboard) should data retrieval fail

    Requires Azure AD powershell module (Install-Module AzureAD)

.INPUTS
    None

.OUTPUTS
    None

.EXAMPLE
    PS C:\> M365SH-KISS.ps1 -configXML ..\config\production.xml


.NOTES
    Author:  Jonathan Christie
    Email:   jonathan.christie (at) microsoft.com
    Date:    02 Feb 2022
    PSVer:   2.0/3.0/4.0/5.0
    Version: 1.0.1
    Updated:
    UpdNote:

    Wishlist:

    Completed:

    Outstanding:

#>

[CmdletBinding()]
param (
    [Parameter(Mandatory = $true)] [String]$configXML = "..\config\example.xml"
)

   
function Write-Log {
    param(
        [Parameter(Mandatory = $true)] [string]$info
    )
    # verify the Log is setup and if not create the file
    if ($script:loginitialized -eq $false) {
        $script:FileHeader >> $script:logfile
        $script:loginitialized = $True
    }
    $info = $(Get-Date).ToString() + ": " + $info
    $info >> $script:logfile
}

function EnsureAzureADModule() {
    # Query for installed Azure AD modules
    $AadModule = Get-Module -Name "AzureAD" -ListAvailable
    if ($null -eq $AadModule) {
        Write-Output "AzureAD PowerShell module not found, looking for AzureADPreview"
        $AadModule = Get-Module -Name "AzureADPreview" -ListAvailable
    }

    if ($null -eq $AadModule) {
        Write-Output
        Write-Output "AzureAD Powershell module not installed..." -f Red
        Write-Output "Install by running 'Install-Module AzureAD' or 'Install-Module AzureADPreview' from an elevated PowerShell prompt" -f Yellow
        Write-Output "Script can't continue..." -f Red
        Write-Output
        exit
    }

    if ($AadModule.count -gt 1) {
        $Latest_Version = ($AadModule | Select-Object version | Sort-Object)[-1]
        $aadModule = $AadModule | Where-Object { $_.version -eq $Latest_Version.version }
        # Checking if there are multiple versions of the same module found
        if ($AadModule.count -gt 1) {
            $aadModule = $AadModule | Select-Object -Unique
        }
        $adal = Join-Path $AadModule.ModuleBase "Microsoft.IdentityModel.Clients.ActiveDirectory.dll"
        $adalforms = Join-Path $AadModule.ModuleBase "Microsoft.IdentityModel.Clients.ActiveDirectory.Platform.dll"
    }
    else {
        $adal = Join-Path $AadModule.ModuleBase "Microsoft.IdentityModel.Clients.ActiveDirectory.dll"
        $adalforms = Join-Path $AadModule.ModuleBase "Microsoft.IdentityModel.Clients.ActiveDirectory.Platform.dll"
    }

    [System.Reflection.Assembly]::LoadFrom($adal) | Out-Null
    [System.Reflection.Assembly]::LoadFrom($adalforms) | Out-Null
}

function BuildHTML {
    Param (
        [Parameter(Mandatory = $true)] $Title,
        [Parameter(Mandatory = $true)] $contentOne,
        [Parameter(Mandatory = $true)] $HTMLOutput
    )
    [array]$htmlHeader = @()
    [array]$htmlBody = @()
    [array]$htmlFooter = @()

    $htmlHeader = @"
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="M365KISS.css">
<style>
</style>
<title>$($Title)</title>
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
<meta http-equiv="Pragma" content="no-cache" />
<meta http-equiv="Expires" content="0" />
</head>
"@

    $htmlBody = @"

<body>
    <p>Page refreshed: <span id="datetime"></span><span>&nbsp;&nbsp;Data refresh: $(Get-Date -Format 'dd MMM yyy HH:mm:ss') [$((Get-Timezone).id)]</span></p>
"@

    $htmlBody += @"

    $($contentOne)
"@

    $htmlFooter = @"
<script>
var dt = new Date();
const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
document.getElementById("datetime").innerHTML = (("0"+dt.getDate()).slice(-2)) +"-"+ (("0"+(dt.getMonth()+1)).slice(-2)) +"-"+ (dt.getFullYear()) +" "+ (("0"+dt.getHours()).slice(-2)) +":"+ (("0"+dt.getMinutes()).slice(-2)) +":"+ (("0"+dt.getSeconds()).slice(-2)) +" ["+ timezone +"]";
</script>

<script>
function openTab(evt, tabName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }

    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active","");
    }
    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.className += " active";
}

document.getElementById("defaultOpen").click();
</script>
</body>
</html>
"@

    #Add in code to refresh page
    #Editing after file is generated increases the file size drastically
    $addJava = "<script language=""JavaScript"" type=""text/javascript"">"
    $addJava += "setTimeout(""location.href='$($HTMLOutput)'"",$($pageRefresh*60*1000));"
    $addjava += "</script>"

    $htmlReport = $htmlHeader + $addJava + $htmlBody + $htmlFooter
    $htmlReport | Out-File "$($pathHTML)\$($HTMLOutput)"
}


Import-Module "..\common\M365ServiceHealth.psm1"
#Get the EULA
$eula = ShowEulaIfNeeded SfMC-M365ServiceHealth 0
if ($eula -ne "Yes") {
    Write-Output "You must accept the EULA to proceed"
}
else {
    $swScript = [system.diagnostics.stopwatch]::StartNew()
    Write-Verbose "Changing Directory to $PSScriptRoot"
    Set-Location $PSScriptRoot

    if ([system.IO.path]::IsPathRooted($configXML) -eq $false) {
        #its not an absolute path. Find the absolute path
        $configXML = Resolve-Path $configXML
    }
    $config = LoadConfig $configXML

    #Configure local event log
    [string]$evtLogname = $config.EventLog
    [string]$evtSource = $config.MonitorEvtSource

    if ($config.UseEventlog -like 'true') {
        [boolean]$UseEventLog = $true
        #check source and log exists
        $CheckLog = [System.Diagnostics.EventLog]::Exists("$($evtLogname)")
        $CheckSource = [System.Diagnostics.EventLog]::SourceExists("$($evtSource)")
        if ((! $CheckLog) -or (! $CheckSource)) {
            New-EventLog -LogName $evtLogname -Source $evtSource
        }
    }
    else { [boolean]$UseEventLog = $false }

    #Declare variables
    [string]$tenantID = $config.TenantID
    [string]$appID = $config.AppID
    [string]$clientSecret = $config.AppSecret

    [string]$rptName = $config.KISSReportName
    [int]$pageRefresh = $config.KISSPageRefresh
    [string]$HTMLFile = $config.KISSHTML
    [string]$Logo = $config.KISSLogo
    
    #Dashboard cards
    [string[]]$dashCards = $config.KISSDashCards.split(",")
    $dashCards = $dashCards.Replace('"', '')
    $dashCards = $dashCards.Trim()

    #Ignore the Services and Incidents
    [array]$ignStatus = $config.MonitorIgnoreSvc
    if ($ignStatus -ne "") {
        $ignStatus = $ignStatus.replace('"', '')
        $ignStatus = $ignStatus.Trim()
        $ignStatus = $ignStatus.split(",")
    }

    [string]$rptProfile = $config.TenantShortName
    [string]$rptTenantName = $config.TenantName

    [string]$pathLogs = $config.LogPath
    [string]$pathHTML = $config.HTMLPath
    [string]$pathWorking = $config.WorkingPath

    [string]$proxyHost = $config.ProxyHost

    [boolean]$rptOutage = $false

    [string]$cssfile = "M365KISS.css"

    if ($config.EmailEnabled -like 'true') { [boolean]$emailEnabled = $true } else { [boolean]$emailEnabled = $false }

    #Check the various file paths, set default, create and make absolute reference if necessary
    $pathLogs = CheckDirectory $pathLogs
    $pathHTML = CheckDirectory $pathHTML
    $pathWorking = CheckDirectory $pathWorking


    # setup the logfile
    # If logfile exists, the set flag to keep logfile
    $logName="M365KISS"
    $script:DailyLogFile = "$($pathLogs)\$($logName)-$($rptprofile)-$(Get-Date -format yyMMdd).log"
    $script:LogFile = "$($pathLogs)\tmp$($logName)-$($rptprofile)-$(Get-Date -format yyMMddHHmmss).log"
    $script:LogInitialized = $false
    $script:FileHeader = "*** Application Information ***"

    $evtMessage = "Config File: $($configXML)"
    Write-Log $evtMessage
    $evtMessage = "Log Path: $($pathLogs)"
    Write-Log $evtMessage
    $evtMessage = "HTML Output: $($pathHTML)"
    Write-Log $evtMessage

    #Create event logs if set
    if ($UseEventLog) {
        $evtCheck = Get-EventLog -List -ErrorAction SilentlyContinue | Where-Object { $_.LogDisplayName -eq $evtLogname }
        if (!($evtCheck)) {
            New-EventLog -LogName $evtLogname -Source $evtSource
            Write-ELog -useEventLog $useEventLog -LogName $evtLogname -Source $evtSource -Message "Event log created." -EventId 1 -EntryType Information
        }
    }

    #Proxy Configuration
    if ($config.ProxyEnabled -like 'true') {
        [boolean]$ProxyServer = $true
        $evtMessage = "Using proxy server $($proxyHost) for connectivity"
        Write-Log $evtMessage
    }
    else {
        [boolean]$ProxyServer = $false
        $evtMessage = "No proxy to be used."
        Write-Log $evtMessage
    }

    [string]$urlGraph = "https://graph.microsoft.com/.default"
    $authGheader = Get-BearerToken $tenantID $urlGraph $appID $clientSecret $proxyServer $proxyHost

    #Now remove any system default proxy in order to test no-proxy paths.
    $defaultproxy = [System.Net.WebProxy]::GetDefaultProxy()
    [System.Net.GlobalProxySelection]::Select = [System.Net.GlobalProxySelection]::GetEmptyWebProxy()


    #https://docs.microsoft.com/en-gb/azure/active-directory/users-groups-roles/licensing-service-plan-reference

    #	Returns the list of subscribed services
    [uri]$uriHealthOverview = "https://graph.microsoft.com/v1.0/admin/serviceAnnouncement/healthOverviews" 
    [uri]$uriHealthIssues = "https://graph.microsoft.com/v1.0/admin/serviceAnnouncement/issues"

    #Fetch the information from Office 365 Service Health API
    #Get Services: Get the list of subscribed services
    $uriError = ""

    #graph API Health Overview
    $shIssues = $null
    $shMessages = $null

    try {
        [array]$shOverview = Get-GraphListResults $uriHealthOverview $authGHeader $proxyserver $proxyHost
        if ($null -eq $shOverview -or $shOverview.Count -eq 0) {
            $rptM365Info += "[$(Get-Date -f 'dd-MMM-yy HH:mm:ss')] <p class='error'>No Subscribed services returned - verify proxy and network connectivity</p><br/>"
        }
        else {
            $rptM365Info += "[$(Get-Date -f 'dd-MMM-yy HH:mm:ss')] <p class='info'>$($shOverview.count) subscribed services returned.</p><br/>"
        }
    }
    catch {
        $rptM365Info += "[$(Get-Date -f 'dd-MMM-yy HH:mm:ss')] <p class='error'>No Subscribed services returned - verify proxy and network connectivity</p><br/>"
        $uriError += "Error connecting to $($uriHealthOverview)<br/><br/>`r`n"
        $uriError += "Error details:<br/> $($Error[0] | Select-Object *)"
    }

    #Get Current Status: Get a real-time view of current and ongoing service incidents and maintenance events
    #Graph API - Get a list of all health issues
    try {
        [array]$shIssues = Get-GraphListResults $uriHealthIssues $authGHeader $proxyServer $proxyHost

        if ($null -eq $shIssues -or $shIssues.Count -eq 0) {
            $rptM365Info += "[$(Get-Date -f 'dd-MMM-yy HH:mm:ss')] <p class='error'>Cannot retrieve the current Service Health issues - verify proxy and network connectivity</p><br/>"
        }
        else {
            $shIssues = $shIssues | Where-Object { $_.service -notin $ignStatus }
            $rptM365Info += "[$(Get-Date -f 'dd-MMM-yy HH:mm:ss')] <p class='info'>$($shIssues.count) services and status returned.</p><br/>"
        }
    }
    catch {
        $rptM365Info += "[$(Get-Date -f 'dd-MMM-yy HH:mm:ss')] <p class='error'>Cannot retrieve the current Service Health issues - verify proxy and network connectivity</p><br/>"
        $uriError += "Error connecting to $($uriHealthIssues)<br/><br/>`r`n"
        $uriError += "Error details:<br/> $($Error[0] | Select-Object *)"
    }

    #Get Current Status: Get a real-time view of current and ongoing service incidents and maintenance events
    #Graph API - Get a list of all Message center messages
    try {
        [array]$shMessages = Get-GraphListResults $uriHealthMessages $authGHeader $proxyServer $proxyHost

        if ($null -eq $shMessages -or $shMessages.Count -eq 0) {
            $rptM365Info += "[$(Get-Date -f 'dd-MMM-yy HH:mm:ss')] <p class='error'>Cannot retrieve the current Service Health messages - verify proxy and network connectivity</p><br/>"
        }
        else {
            $shMessages = $shMessages | Where-Object { $_.service -notin $ignStatus }
            $rptM365Info += "[$(Get-Date -f 'dd-MMM-yy HH:mm:ss')] <p class='info'>$($shMessages.count) services and status returned.</p><br/>"
        }
    }
    catch {
        $rptM365Info += "[$(Get-Date -f 'dd-MMM-yy HH:mm:ss')] <p class='error'>Cannot retrieve the current Service Health messages - verify proxy and network connectivity</p><br/>"
        $uriError += "Error connecting to $($uriHealthIssues)<br/><br/>`r`n"
        $uriError += "Error details:<br/> $($Error[0] | Select-Object *)"
    }

    #Build Div1
    #Build Summary Dashboard
    # 6 cards
    $rptSectionOneOne = "<div class='section'><div class='name'>$rptName</div><div class='logo'><img src='$($logo)' alt='logo' style='width:150px;'></div>`n"
    $rptSectionOneOne += "<div class='content'>`n"
    $rptSectionOneOne += "<div class='dash-outer'><div class='dash-inner'>`n<br/><br/><br/>`n"
    $card = $null
    foreach ($card in $dashCards) {
        [array]$item = @()
        [array]$hist = @()
        [int]$advisories = 0
        $cardClass = $null
        $cardText = $null
        $item = $shOverview | Where-Object { $_.service -like $card }
        $hist = $shIssues | Where-Object { $_.service -like $card -and ($_.status -notlike 'False Positive') } | Sort-Object EndDateTime -Descending
        $advisories = ($shMessages | Where-Object { ($_.services -like $card) }).count
        if ($hist.count -gt 0) {
            $days = "{0:N0}" -f (New-TimeSpan -Start (Get-Date $hist[0].EndDateTime) -End $(Get-Date)).TotalDays
        }
        else {
            $days = "&gt;30"
        }
        try { $cardClass = Get-StatusDisplay $($item.status) "Class" }
        catch { Write-Log "No status available for $card - $($item.service)" }
        try { $cardText = cardbuilder $($item.service) $($Days) $($Hist.count) $advisories $cardClass }
        catch { Write-Log "Cant find $card in workload. Has name changed or workload replaced?" }
        $rptSectionOneOne += "$cardText`n"
    }
    $rptSectionOneOne += "</div></div>`n" #Close inner and outer divs

    #Get Current Status and Issues for non operational services
    [array]$CurrentStatusBad = $shOverview | Where-Object { $_.status -notlike 'ServiceOperational' }
    [array]$rptSummaryTable = @()
    $rptSummaryTable = "<br/><br/><div class='dash-outer'><div class='dash-inner'>`n"
    if ($CurrentStatusBad.count -ge 1) {
        $rptSummaryTable += "<div class='tableWrkld'>`r`n"
        $rptSummaryTable += "<div class='tableWrkld-title'>The following services are reporting service issues</div>`r`n"
        $rptSummaryTable += "<div class='tableWrkld-header'>`n`t<div class='tableWrkld-header-r'>Systems</div>`n`t<div class='tableWrkld-header-c'>Status</div>`n`t<div class='tableWrkld-header-l'>Status at $(Get-Date -Format 'HH:mm')</div>`n</div>`n"
        foreach ($item in $CurrentStatusBad) {
            $statusIcon = $null
            $statusDesc = $null
            $statusIcon = Get-StatusDisplay $($item.status) "Icon"
            if ($showKISS) {$statusDesc = Get-StatusDisplay $($item.status) "kissDescription"} else {$statusDesc = Get-StatusDisplay $($item.status) "Description"}
            $rptSummaryTable += "<div class='tableWrkld-row'>`n`t<div class='tableWrkld-cell-r'>$($item.service)</div>`n`t<div class='tableWrkld-cell-c'>$StatusIcon</div>`n`t<div class='tableWrkld-cell-l'>$statusDesc</div>`n</div>"
        }
    }
    else {
        $rptSummaryTable += "<div class='tableWrkld'>`r`n"
        if ($authErrMsg) { $rptSummaryTable += "<div class='tableWrkld-title'>$authErrMsg</div>`r`n" }
        else { $rptSummaryTable += "<div class='tableWrkld-title'>No current or recent issues to display</div>`r`n" }
    }
    #Close table Workld div
    $rptSummaryTable += "</div>`n"
    #Close div and content div
    $rptSummaryTable += "</div></div>`n<br/><br/>`n"
    $rptSectionOneOne += $rptSummaryTable
    $rptSectionOneOne += "</div></div>`n" #Close content and section

    $divOne = $rptSectionOneOne

    $rptHTMLName = $HTMLFile.Replace(" ", "")
    $rptTitle = $rptTenantName + " " + $rptName
    if ($rptOutage) { $rptTitle += " Outage detected" }
    $evtMessage = "[$(Get-Date -f 'dd-MMM-yy HH:mm:ss')] Tenant: $($rptProfile) - Generating HTML to '$($pathHTML)\$($rptHTMLName)'`r`n"
    $evtLogMessage += $evtMessage
    Write-Verbose $evtMessage

    BuildHTML $rptTitle $divOne $rptHTMLName
    #Check if .css file exists in HTML file destination
    if (!(Test-Path "$($pathHTML)\$($cssfile)")) {
        Write-Log "Copying $($cssfile) to directory $($pathHTML)"
        Copy-Item "..\common\$($cssfile)" -Destination "$($pathHTML)"
    }

    $swScript.Stop()

    $evtMessage = "Tenant: $($rptProfile) - Script runtime $($swScript.Elapsed.Minutes)m:$($swScript.Elapsed.Seconds)s:$($swScript.Elapsed.Milliseconds)ms on $env:COMPUTERNAME`r`n"
    $evtMessage += "*** Processing finished ***`r`n"
    Write-Log $evtMessage
    #Re-instate default proxy
    [System.Net.GlobalProxySelection]::Select = $defaultProxy

    #Append to daily log file.
    Get-Content $script:logfile | Add-Content $script:Dailylogfile
    Remove-Item $script:logfile
}
Remove-Module M365ServiceHealth
