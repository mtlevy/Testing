﻿<#
//***********************************************************************
//
// Copyright (c) 2018 Microsoft Corporation. All rights reserved.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
//
//**********************************************************************​
#>

<#
.SYNOPSIS
    Gets the Office 365 Health Center messages and incidents.
    Displays on several tabs with the summary providing a dashbord overview

.DESCRIPTION
    This script is designed to run on a scheduled basis.
    It requires and Azure AD Application for your tenant.
    The script will build an HTML page displaying information and links to tenant messages and articles.
    Several tenants configurations can be held.
    Office 365 service health incidents generate email alerts as well as logging to the event log.
    Alternative links can be added (ie to an external dashboard) should data retrieval fail

    Requires Azure AD powershell module (Install-Module AzureAD)

.INPUTS
    None

.OUTPUTS
    None

.EXAMPLE
    PS C:\> M365SH-Monitor.ps1 -configXML ..\config\production.xml


.NOTES
    Author:  Jonathan Christie
    Email:   jonathan.christie (at) microsoft.com
    Date:    02 Dec 2021
    PSVer:   2.0/3.0/4.0/5.0
    Version: 3.0.1
    Updated: Single page, monitor only for SysOps
    UpdNote:

    Wishlist:

    Completed:

    Outstanding:

#>
[CmdletBinding()]
param (
    [Parameter(Mandatory = $true)] [String]$configXML = "..\config\profile-test.xml"
)


function Write-Log {
    param(
        [Parameter(Mandatory = $true)] [string]$info
    )
    # verify the Log is setup and if not create the file
    if ($script:loginitialized -eq $false) {
        $script:FileHeader >> $script:logfile
        $script:loginitialized = $True
    }
    $info = $(Get-Date).ToString() + ": " + $info
    $info >> $script:logfile
}



Import-Module "..\common\M365ServiceHealth.psm1"
#Get the EULA
$eula = ShowEulaIfNeeded SfMC-M365ServiceHealth 0
if ($eula -ne "Yes") {
    Write-Output "You must accept the EULA to proceed"
}
else {
    $swScript = [system.diagnostics.stopwatch]::StartNew()
    Write-Verbose "Changing Directory to $PSScriptRoot"
    Set-Location $PSScriptRoot

    if ([system.IO.path]::IsPathRooted($configXML) -eq $false) {
        #its not an absolute path. Find the absolute path
        $configXML = Resolve-Path $configXML
    }
    $config = LoadConfig $configXML

    [string]$tenantID = $config.TenantID
    [string]$appID = $config.AppID
    [string]$clientSecret = $config.AppSecret
    [string]$rptProfile = $config.TenantShortName
    [string]$proxyHost = $config.ProxyHost
    [string]$emailEnabled = $config.EmailEnabled
    [string]$SMTPUser = $config.EmailUser
    [string]$SMTPPassword = $config.EmailPassword
    [string]$SMTPKey = $config.EmailKey
    [string]$pathLogs = $config.LogPath
    [string]$evtLogname = $config.EventLog
    [string]$hostURL = $config.HostURL
    #[string]$evtSource = $config.MonitorEvtSource
    [string]$evtSource = "Monitor"
    [boolean]$checklog = $false
    [boolean]$checksource = $false
    [string[]]$MonitorAlertsTo = $config.MonitorAlertsTo
    [string]$emailClosedBgd = "WhiteSmoke"
    [string]$pathWorking = $config.WorkingPath


    if ($config.EmailEnabled -like 'true') { [boolean]$emailEnabled = $true } else { [boolean]$emailEnabled = $false }
    if ($config.CNAMEEnabled -like 'true') { [boolean]$cnameEnabled = $true } else { [boolean]$cnameEnabled = $false }
    if ($config.ipMonEnabled -like 'true') { [boolean]$ipMonEnabled = $true } else { [boolean]$ipMonEnabled = $false }


    #Ignore the Services and Incidents
    [array]$ignStatus = $config.MonitorIgnoreSvc
    if ($ignStatus -ne "") {
        $ignStatus = $ignStatus.replace('"', '')
        $ignStatus = $ignStatus.split(",")
    }

    [array]$ignIncidents = $config.MonitorIgnoreInc
    if ($ignIncidents -ne "") {
        $ignIncidents = $ignIncidents.replace('"', '')
        $ignIncidents = $ignIncidents.split(",")
    }
    [string[]]$cnameAlertsTo = $config.CNAMEAlertsTo
    [string]$cnameFilename = $config.CNAMEFilename
    [string[]]$cnameURLs = $config.CNAMEUrls.split(",")
    $cnameURLs = $cnameURLs.Replace('"', '')
    $cnameURLs = $cnameURLs.Trim()

    [string[]]$cnameResolvers = $config.CNAMEResolvers.split(",")
    $cnameResolvers = $cnameResolvers.Replace('"', '')
    $cnameResolvers = $cnameResolvers.Trim()
    [string[]]$cnameResolverDesc = $config.CNAMEResolverDesc.split(",")
    $cnameResolverDesc = $cnameResolverDesc.Replace('"', '')
    $cnameResolverDesc = $cnameResolverDesc.Trim()

    if ($cnameresolvers[0] -eq "") {
        $cnameResolvers = @(Get-DnsClientServerAddress | Sort-Object interfaceindex | Select-Object -ExpandProperty serveraddresses | Where-Object { $_ -like '*.*' } | Select-Object -First 1)
        $cnameResolverDesc = @("Default")
    }

    if ($ipmonEnabled) {
        [string]$ipMonFilename = $config.ipMonFilename
        [string[]]$ipMonURLs = $config.ipMonUrls.split(",")
        $ipMonURLs = $ipMonURLs.Replace('"', '')
        $ipMonURLs = $ipMonURLs.Trim()

        [string[]]$ipMonResolvers = $config.ipMonResolvers.split(",")
        $ipMonResolvers = $ipMonResolvers.Replace('"', '')
        $ipMonResolvers = $ipMonResolvers.Trim()
        [string[]]$ipMonResolverDesc = $config.ipMonResolverDesc.split(",")
        $ipMonResolverDesc = $ipMonResolverDesc.Replace('"', '')
        $ipMonResolverDesc = $ipMonResolverDesc.Trim()

        if ($ipMonresolvers[0] -eq "") {
            $ipMonResolvers = @(Get-DnsClientServerAddress | Sort-Object interfaceindex | Select-Object -ExpandProperty serveraddresses | Where-Object { $_ -like '*.*' } | Select-Object -First 1)
            $ipMonResolverDesc = @("Default")
        }
    }
    #Configure local event log
    if ($config.UseEventlog -like 'true') {
        [boolean]$UseEventLog = $true
        #check source and log exists
        $checkLog = [System.Diagnostics.EventLog]::Exists("$($evtLogname)")
        $checkSource = [System.Diagnostics.EventLog]::SourceExists("$($evtSource)")
        if ((! $checkLog) -or (! $checkSource)) {
            New-EventLog -LogName $evtLogname -Source $evtSource
        }
    }
    else { [boolean]$UseEventLog = $false }

    # Get Email credentials
    # Check for a username. No username, no need for credentials (internal mail host?)
    [PSCredential]$emailCreds = $null
    if ($emailEnabled -and $smtpuser -notlike '') {
        #Email credentials have been specified, so build the credentials.
        #See readme on how to build credentials files
        $EmailCreds = getCreds $SMTPUser $SMTPPassword $SMTPKey
    }

    # Build logging variables
    #If no path has been specified, use the current script location
    $pathLogs = CheckDirectory $pathLogs
    $pathWorking = CheckDirectory $pathWorking


    # setup the logfile
    # If logfile exists, the set flag to keep logfile
    $script:DailyLogFile = "$($pathLogs)\M365Monitor-$($rptprofile)-$(Get-Date -format yyMMdd).log"
    $script:LogFile = "$($pathLogs)\tmpM365Monitor-$($rptprofile)-$(Get-Date -format yyMMddHHmmss).log"
    $script:LogInitialized = $false
    $script:FileHeader = "*** Application Information ***"

    $evtMessage = "Config File: $($configXML)"
    Write-Log $evtMessage
    $evtMessage = "Log Path: $($pathLogs)"
    Write-Log $evtMessage
    $evtMessage = "Working Path: $($pathWorking)"
    Write-Log $evtMessage

    #Create event logs if set
    [System.Diagnostics.EventLog]$evtCheck = ""
    if ($UseEventLog) {
        $evtCheck = Get-EventLog -List -ErrorAction SilentlyContinue | Where-Object { $_.LogDisplayName -eq $evtLogname }
        if (!($evtCheck)) {
            New-EventLog -LogName $evtLogname -Source $evtSource
            Write-ELog -useEventLog $useEventLog -LogName $evtLogname -Source $evtSource -Message "Event log created." -EventId 1 -EntryType Information
        }
    }

    #Proxy Configuration
    if ($config.ProxyEnabled -like 'true') {
        [boolean]$ProxyServer = $true
        $evtMessage = "Using proxy server $($proxyHost) for connectivity"
        Write-Log $evtMessage
    }
    else {
        [boolean]$ProxyServer = $false
        $evtMessage = "No proxy to be used."
        Write-Log $evtMessage
    }

    [string]$urlGraph = "https://graph.microsoft.com/.default"
    $authGraphHeader = Get-BearerToken $tenantID $urlGraph $appID $clientSecret $proxyServer $proxyHost

    if ($null -eq $authGraphHeader) {
        $evtMessage = "ERROR - No authentication result for Azure AD App"
        Write-ELog -useEventLog $useEventLog -LogName $evtLogname -Source $evtSource -Message "$($rptProfile) : $evtMessage" -EventId 10 -EntryType Error
        Write-Log $evtMessage
    }

    #Script specific
    [array]$newIncidents = @()
    #Keep a list of known issues in CSV. This is useful if the event log is cleared, or not used.
    [string]$knownIssues = "$($pathWorking)\knownIssues-$($rptprofile).csv"
    [array]$knownIssuesList = @()

    if (Test-Path "$($knownIssues)") { $knownIssuesList = Import-Csv "$($knownIssues)" }
    else {
        $evtMessage = "ERROR - Known issues list does not exist. Ignore on first run."
        Write-ELog -useEventLog $useEventLog -LogName $evtLogname -Source $evtSource -Message "$($rptProfile) : $evtMessage" -EventId 10 -EntryType Error
        Write-Log $evtMessage
    }

    if ($knownIssuesList -eq 0) {
        $evtMessage = "ERROR - Known issues list is empty. Ignore on first run."
        Write-ELog -useEventLog $useEventLog -LogName $evtLogname -Source $evtSource -Message "$($rptProfile) : $evtMessage" -EventId 10 -EntryType Error
        Write-Log $evtMessage
    }

    $allServiceIssues = @()

    [uri]$uriServiceIssues = "https://graph.microsoft.com/v1.0/admin/serviceAnnouncement/issues"
    $allServiceIssues = Get-GraphListResults $uriServiceIssues $authGraphHeader $proxyserver $proxyHost


    if (($null -eq $allServiceIssues) -or ($allServiceIssues.Count -eq 0)) {
        $evtMessage = "ERROR - Cannot retrieve the current status of services - verify proxy and network connectivity."
        Write-ELog -useEventLog $useEventLog -LogName $evtLogname -Source $evtSource -Message $evtMessage -EventId 11 -EntryType Error
        Write-Log $evtMessage

    }
    else {
        $allServiceIssues = $allServiceIssues | Where-Object { $_.Service -notin $ignIncidents }
        $evtMessage = "$($allServiceIssues.count) messages returned."
        Write-Log $evtMessage
    }

    $currentIncidents = @($allServiceIssues)
    $newIncidents = @($currentIncidents | Where-Object { ($_.id -notin $knownIssuesList.id) -and ($null -eq $_.enddatetime) })

    #Get all messages with no end date (open)
    #Get events and check event log
    #If not logged, create an entry and send an email

    $evtFind = $null

    if ($newIncidents.count -ge 1) {
        Write-Log "New incidents detected: $($newIncidents.count)"
        foreach ($item in $newIncidents) {
            if ($useEventLog) {
                #Check event log. If no entry (ID) then write entry
                $evtFind = Get-EventLog -LogName $evtLogname -Source $evtSource -Message "*: $($item.ID)*: $($rptProfile)*" -ErrorAction SilentlyContinue
            }
            #Check known issues list
            if ($null -eq $evtFind) {
                $emailPriority = ""
                $statusDesc = ""
                $statusDesc = Get-StatusDisplay $($item.status) "Description"

                Write-Log "Building and attempting to send email"
                $mailMessage = "<b>ID</b>`t`t: $($item.ID)<br/>"
                $mailMessage += "<b>Tenant</b>`t`t: $($rptProfile)<br/>"
                $mailMessage += "<b>Feature</b>`t`t: $($item.service)<br/>"
                $mailMessage += "<b>Status</b>`t`t: $($statusDesc)<br/>"
                $mailMessage += "<b>Classification</b>`t`t: $($item.Classification)<br/>"
                $mailMessage += "<b>Start Date</b>`t: $(Get-Date $item.StartDateTime -f 'dd-MMM-yyyy HH:mm')<br/>"
                $mailMessage += "<b>Last Updated</b>`t: $(Get-Date $item.LastModifiedDateTime -f 'dd-MMM-yyyy HH:mm')<br/>"
                $mailMessage += "<b>Incident Title</b>`t: $($item.title)<br/>"
                $mailMessage += "$($item.ImpactDescription)<br/><br/>"
                $emailPriority = "normal"
                if ($hostURL -ne '') { $mailMessage += "<a href=$($hostURL)/docs/$($item.id).html target=_blank>Full details will be logged here</a>" }
                $emailSubject = "New $($item.Classification): $($item.service) - $($item.Status) [$($item.ID)]"
                if ($MonitorAlertsTo -and $emailEnabled) { SendEmail $mailMessage $EmailCreds $config $emailPriority $emailSubject $MonitorAlertsTo }
                $evtMessage = $mailMessage.Replace("<br/>", "`r`n")
                $evtMessage = $evtMessage.Replace("<b>", "")
                $evtMessage = $evtMessage.Replace("</b>", "")
                $evtID = 0
                $evtErr = 'Error'
                Write-ELog -useEventLog $useEventLog -LogName $evtLogname -Source $evtSource -Message $evtMessage -EventId $evtID -EntryType $evtErr
                Write-Log $evtMessage
            }
        }
    }

    [array]$reportClosed = @()
    [array]$recentlyClosed = @()
    [array]$recentIncidents = @()

    #Previously known items (saved list) where there was not an end time
    $recentIncidents = $knownIssuesList | Where-Object { ($_.enddatetime -eq '') }
    #Items on current scan (online) where there was an end time
    $recentlyClosed = $currentIncidents | Where-Object { ($_.enddatetime -ne $null) }
    #Closed items are previously open items that now have an end time
    $reportClosed = $recentlyClosed | Where-Object { $_.id -in $recentIncidents.ID }
    #Some items may have been newly added AND closed
    $reportClosed += $currentIncidents | Where-Object { $_.id -notin $knownissueslist.ID -and $null -ne $_.enddatetime }

    Write-Log "Closed incidents detected: $($reportClosed.count)"
    #Check that closed isnt greater than 10. If it is, its likely to be a new install or issue with corrupt file
    if ($knownIssuesList.count -ge 1 -and $reportClosed.count -le 10) {
        foreach ($item in $reportClosed) {
            $statusDesc = ""
            $statusDesc = Get-StatusDisplay $($item.status) "Description"
            Write-Log "Building and attempting to send closure email"
            $mailMessage = "<b>Incident Closed</b>`t`t: <b>Closed</b><br/>"
            $mailMessage += "<b>Tenant</b>`t`t: $($rptProfile)<br/>"
            $mailMessage += "<b>ID</b>`t`t: $($item.ID)<br/>"
            $mailMessage += "<b>Feature</b>`t`t: $($item.service)<br/>"
            $mailMessage += "<b>Status</b>`t`t: $($statusDesc)<br/>"
            $mailMessage += "<b>Severity</b>`t`t: $($item.Severity)<br/>"
            $mailMessage += "<b>Start Time</b>`t: $(Get-Date $item.StartdateTime -f 'dd-MMM-yyyy HH:mm')<br/>"
            $mailMessage += "<b>Last Updated</b>`t: $(Get-Date $item.lastModifiedDateTime -f 'dd-MMM-yyyy HH:mm')<br/>"
            $mailMessage += "<b>End Time</b>`t: <b>$(Get-Date $item.endDateTime -f 'dd-MMM-yyyy HH:mm')</b><br/>"
            $mailMessage += "<b>Incident Title</b>`t: $($item.title)<br/>"
            $mailMessage += "$($item.ImpactDescription)<br/><br/>"
            #Add the last action from microsoft to the email only - not to the event log entry (text can be too long)
            $mailWithLastAction = $mailMessage + "<b>Final Update from Microsoft</b>`t:<br/>"
            $lastMessage = Get-htmlMessage ($item.messages.messagetext | Where-Object { $_ -like '*This is the final update*' -or $_ -like '*Final status:*' })
            $lastMessage = "<div style='background-color:$($emailClosedBgd)'>" + $lastMessage.replace("<br><br>", "<br/>") + "</div>"
            $mailWithLastAction += "$($lastMessage)<br/><br/>"
            if ($hostURL -ne '') { $mailMessage += "<a href=$($hostURL)/docs/$($item.id).html target=_blank>Full details will be logged here</a>" }
            $emailSubject = "Closed: $($item.WorkloadDisplayName) - $($item.Status) [$($item.ID)]"
            Write-Log "Sending email to $($MonitorAlertsTo)"
            if ($MonitorAlertsTo -and $emailEnabled) { SendEmail $mailWithLastAction $EmailCreds $config "Normal" $emailSubject $MonitorAlertsTo }
            $evtMessage = $mailMessage.Replace("<br/>", "`r`n")
            $evtMessage = $evtMessage.Replace("<b>", "")
            $evtMessage = $evtMessage.Replace("</b>", "")
            Write-ELog -useEventLog $useEventLog -LogName $evtLogname -Source $evtSource -Message $evtMessage -EventId 30 -EntryType Information
            Write-Log $evtMessage
        }
    }

    #Update the know lists if issues. they might not have increased, but end times may have been added.
    #If empty then skip to avoid overwriting
    if ($currentIncidents.count -gt 0) {
        $currentIncidents | Export-Csv "$($knownIssues)" -Encoding UTF8 -NoTypeInformation
    }

    #Check DNS entries while we're here
    if ($cnameEnabled) {
        foreach ($DNSServer in $cnameResolvers) {
            $dnsServerDesc = $cnameresolverdesc[[array]::indexof($cnameResolvers, $DNSServer)]
            [array]$exportNH = @()
            #Define the filename and location to store URL cname results
            $cnameKnownCSV = "$($pathWorking)\$cnameFilename-$($DNSServer)-$($rptProfile).csv"
            if (!(Test-Path $cnameKnownCSV)) {
                $headers = "monitor,namehost,domain,addedDate,lastDate"
                $headers | Add-Content $cnameKnownCSV -Encoding UTF8
            }

            #define the URLs which should be monitored
            #Fetch the list of previously known CNAMES
            $cnameKnown = Import-Csv "$($cnameKnownCSV)"
            if ($cnameKnown.count -ge 1) {
                #check if CSV has the lastDate column. if not, add it in
                if (!(($cnameKnown | Get-Member -MemberType NoteProperty | Select-Object -ExpandProperty name) -contains 'lastdate')) {
                    $cnameKnown | Add-Member -MemberType NoteProperty -Name lastDate -Value $null
                }
                if (!(($cnameKnown | Get-Member -MemberType NoteProperty | Select-Object -ExpandProperty name) -contains 'resolver')) {
                    $cnameKnown | Add-Member -MemberType NoteProperty -Name resolver -Value $null
                }
            }
            $addDateTime = Get-Date -f "dd-MMM-yy HH:mm"
            $alert = ""
            #for each entry in the monitored urls
            foreach ($entry in $cnameURLs) {
                [array]$newDomains = @()
                try { $cnames = @(Resolve-DnsName $($entry) -DnsOnly -Server $DNSServer | Where-Object querytype -like 'CNAME') }
                catch { $alert += "<b>Cannot resolve CNAMES for $($entry)</b><br/>$($error[0].exception)"; break; }
                #From the list own previous responses, get matching monitor records
                #update the lastDate for names which have been found
                $updateNH = $cnameknown | Where-Object { ($_.namehost -in $cnames.namehost) -and ($_.monitor -like $entry) }
                foreach ($knownNH in $updateNH) {
                    $knownNH.lastDate = $addDateTime
                }
                $exportNH += $updateNH
                #identify the new cnames returned
                $unknownNH = $cnames | Where-Object { ($_.namehost -notin $cnameknown.namehost) }
                foreach ($alias in $unknownNH) {
                    $nh = @($alias.nameHost.split("."))
                    $aliasDomain = $nh[-2] + "." + $nh[-1]
                    $addNew = New-Object PSObject
                    $addNew | Add-Member -MemberType NoteProperty -Name monitor -Value $entry
                    $addNew | Add-Member -MemberType NoteProperty -Name nameHost -Value $alias.NameHost
                    $addNew | Add-Member -MemberType NoteProperty -Name domain -Value $aliasDomain
                    $addNew | Add-Member -MemberType NoteProperty -Name addedDate -Value $addDateTime
                    $addNew | Add-Member -MemberType NoteProperty -Name lastdate -Value $addDateTime
                    $addNew | Add-Member -MemberType NoteProperty -Name resolver -Value $DNSServer

                    Write-Log "Adding $($alias.nameHost) to CSV"
                    $alert += "<b>{0}</b>: New name host found CNAME <b>{1}</b> via Resolver <b>{2} ({3})</b><br/>" -f $entry, $alias.nameHost, $DNSServer, $dnsServerDesc
                    $newDomains += @($addNew)
                }
                $exportNH += $newDomains
            }
            #export the lot of them to the original file
            #Add the items originally
            $notfound = $cnameknown | Where-Object { $exportNH -notcontains $_ }
            $exportNH += $notfound
            $exportNH | Sort-Object addedDate, lastDate | Export-Csv -Path "$($cnameKnownCSV)" -NoTypeInformation -Encoding UTF8

            #if alert email, then send
            if ($alert -ne "") {
                $newDomains = $newDomains | Select-Object -Unique
                $alert += "<br/>Check the following domains can be reached for resolution <b>$($newdomains -join(', '))</b><br/>"
                if ($emailEnabled) {
                    $emailSubject = "New CNAME records resolved"
                    SendEmail $alert $EmailCreds $config "High" $emailSubject $cnameAlertsTo $cnameKnownCSV
                }
            }
        }
    }

    #Check IPs entries while we're here
    if ($ipMonEnabled) {
        foreach ($DNSServer in $ipMonResolvers) {
            [array]$ipKnown = @()
            #Define the filename and location to store URL IPAddress results
            $ipKnownCSV = "$($pathWorking)\$($ipmonFilename)-$($DNSServer)-$($rptProfile).csv"
            if (!(Test-Path $ipKnownCSV)) {
                $headers = "monitor,name,IPAddress,addedDate,lastDate"
                $headers | Add-Content $ipKnownCSV -Encoding UTF8
            }

            #define the URLs which should be monitored
            #Fetch the list of previously known IPAddresses
            $ipKnown = @(Import-Csv "$($ipKnownCSV)")
            if ($ipKnown.count -ge 1) {
                #check if CSV has the lastDate column. if not, add it in
                if (!(($ipKnown | Get-Member -MemberType NoteProperty | Select-Object -ExpandProperty name) -contains 'lastdate')) {
                    $ipKnown | Add-Member -MemberType NoteProperty -Name lastDate -Value $null
                }
                if (!(($ipKnown | Get-Member -MemberType NoteProperty | Select-Object -ExpandProperty name) -contains 'resolver')) {
                    $ipKnown | Add-Member -MemberType NoteProperty -Name resolver -Value $null
                }
            }
            $addDateTime = Get-Date -f "dd-MMM-yy HH:mm"
            $alert = ""
            #for each entry in the monitored urls
            foreach ($entry in $ipMonURLs) {
                [array]$currentHosts = @()
                [array]$additions = @()
                [array]$newentry = @()
                try {
                    $resolved = Resolve-DnsName $($entry) -DnsOnly -Server $DNSServer -Type A
                    $resolved = @($resolved | Where-Object querytype -like 'A')
                }
                catch { $alert += "<b>Cannot resolve IPs for $($entry)</b><br/>$($error[0].exception)"; break; }
                #From the list own previous responses, get matching monitor records
                #update the lastDate for names which have been found
                $currentHosts = $ipknown | Where-Object { $_.monitor -like $entry }
                $resolved = @($resolved | Select-Object name, IPAddress)

                if ($null -ne $resolved) {
                    foreach ($item in $currentHosts) {
                        $existing = $null
                        $existing = $resolved | Where-Object { $_.name -like $item.name -and $_.ipAddress -like $item.ipAddress }
                        if ($null -ne $existing) {
                            #Update existing
                            $item.lastdate = $addDateTime
                        }
                    }
                }
                #What about new entries resolved?
                $newentry = @($currentHosts | Select-Object name, ipAddress)
                $newentry = @($resolved | Where-Object { !($newentry -match $_) })
                if ($newentry.count -gt 0) {
                    foreach ($item in $newentry) {
                        $addNew = New-Object PSObject
                        $addNew | Add-Member -MemberType NoteProperty -Name monitor -Value $entry
                        $addNew | Add-Member -MemberType NoteProperty -Name name -Value $item.name
                        $addNew | Add-Member -MemberType NoteProperty -Name ipAddress -Value $item.ipAddress
                        $addNew | Add-Member -MemberType NoteProperty -Name addedDate -Value $addDateTime
                        $addNew | Add-Member -MemberType NoteProperty -Name lastdate -Value $addDateTime
                        $addNew | Add-Member -MemberType NoteProperty -Name resolver -Value $DNSServer
                        $additions += @($addNew)
                    }
                }
                $ipKnown += $additions
            }

            #export the lot of them to the original file
            #Add the items originally
            #Write-Output "Exporting total of $($ipKnown.count) records"
            $ipKnown | Sort-Object addedDate, lastDate | Export-Csv -Path "$($ipKnownCSV)" -NoTypeInformation -Encoding UTF8
        }
    }

    $swScript.Stop()
    $evtMessage = "Script runtime $($swScript.Elapsed.Minutes)m:$($swScript.Elapsed.Seconds)s:$($swScript.Elapsed.Milliseconds)ms on $env:COMPUTERNAME`r`n"
    $evtMessage += "*** Processing finished ***`r`n"
    Write-Log $evtMessage

    #Append to daily log file.
    Get-Content $script:logfile | Add-Content $script:Dailylogfile
    Remove-Item $script:logfile
}
Remove-Module M365ServiceHealth
